import { useState } from "react";
import { cn } from "../../utils/cn";
import { formatCurrency, formatPercent } from "../../utils/format";

export interface DonutItem {
  label: string;
  value: number;
  color: string;
}

const SIZE = 220;
const STROKE = 30;

export function DonutChart({
  data,
  locale,
  centerLabel,
}: {
  data: DonutItem[];
  locale: string;
  centerLabel: string;
}) {
  const [hover, setHover] = useState<number | null>(null);
  const total = data.reduce((sum, d) => sum + d.value, 0);

  if (data.length === 0 || total === 0) {
    return <div className="flex h-56 items-center justify-center text-sm text-slate-500">—</div>;
  }

  const r = (SIZE - STROKE) / 2;
  const circumference = 2 * Math.PI * r;
  let offset = 0;
  const segments = data.map((d) => {
    const frac = d.value / total;
    const seg = { ...d, frac, dash: Math.max(frac * circumference - 3, 0.5), offset };
    offset += frac * circumference;
    return seg;
  });

  const active = hover !== null ? segments[hover] : null;

  return (
    <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-center">
      <div className="relative shrink-0">
        <svg
          width={SIZE}
          height={SIZE}
          viewBox={`0 0 ${SIZE} ${SIZE}`}
          className="-rotate-90 animate-fade-in"
        >
          <circle
            cx={SIZE / 2}
            cy={SIZE / 2}
            r={r}
            fill="none"
            strokeWidth={STROKE}
            className="stroke-slate-200 dark:stroke-navy-700"
          />
          {segments.map((s, i) => (
            <circle
              key={s.label}
              cx={SIZE / 2}
              cy={SIZE / 2}
              r={r}
              fill="none"
              stroke={s.color}
              strokeWidth={STROKE}
              strokeDasharray={`${s.dash} ${circumference - s.dash}`}
              strokeDashoffset={-s.offset}
              className="cursor-pointer transition-all duration-300"
              style={{ opacity: hover === null || hover === i ? 1 : 0.35 }}
              onMouseEnter={() => setHover(i)}
              onMouseLeave={() => setHover(null)}
            />
          ))}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center px-8 text-center">
          <span className="truncate text-lg font-bold sm:text-xl">
            {active ? formatPercent(active.frac, locale, 0) : formatCurrency(total, locale)}
          </span>
          <span className="mt-0.5 max-w-full truncate text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400">
            {active ? active.label : centerLabel}
          </span>
        </div>
      </div>
      <ul className="w-full min-w-0 space-y-1.5">
        {segments.map((s, i) => (
          <li
            key={s.label}
            onMouseEnter={() => setHover(i)}
            onMouseLeave={() => setHover(null)}
            className={cn(
              "flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 transition",
              hover === i && "bg-slate-100 dark:bg-navy-800"
            )}
          >
            <span className="flex min-w-0 items-center gap-2 text-sm">
              <span
                className="h-2.5 w-2.5 shrink-0 rounded-full"
                style={{ backgroundColor: s.color }}
              />
              <span className="truncate">{s.label}</span>
            </span>
            <span className="shrink-0 text-sm font-medium">
              {formatCurrency(s.value, locale)}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
