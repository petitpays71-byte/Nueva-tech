import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { Language } from "./types";

const en = {
  app: {
    name: "NUEVA AI STUDIO",
    company: "NUEVA TECHNOLOGY",
    tagline: "Create professional advertising content with AI",
  },
  nav: {
    studio: "Studio",
    analytics: "Analytics",
    history: "History",
  },
  common: {
    copy: "Copy",
    copied: "Copied!",
    generate: "Generate",
    regenerate: "Regenerate",
    generating: "Generating…",
    clear: "Clear",
    delete: "Delete",
    search: "Search",
    all: "All",
    optional: "optional",
    actions: "Actions",
    close: "Close",
    cancel: "Cancel",
    yes: "Yes",
  },
  header: {
    demoBadge: "Demo mode · no API key required",
    switchTheme: "Toggle color theme",
    language: "Language",
  },
  studio: {
    title: "AI Content Studio",
    subtitle:
      "Generate ad copy, video prompts, product descriptions and social media content — in French or English, right in your browser. Free, with no sign-up.",
    adText: {
      title: "Advertising Text",
      desc: "Headlines, body copy and calls-to-action for your ads.",
      product: "Product / service",
      productPh: "e.g. organic shea butter soap",
      audience: "Target audience",
      audiencePh: "e.g. young mothers in Dakar",
      defaultAudience: "your customers",
      tone: "Tone",
      platform: "Platform",
      length: "Length",
      benefit: "Key benefit",
      benefitPh: "e.g. 100% natural, handmade in Senegal",
      resultTitle: "Your ad text",
    },
    video: {
      title: "Video Prompts",
      desc: "Ready-to-use prompts for realistic AI advertising videos.",
      product: "Product / brand",
      productPh: "e.g. NUEVA energy drink",
      style: "Video style",
      duration: "Duration",
      aspect: "Format",
      scene: "Key scene (optional)",
      scenePh: "e.g. a runner crossing the finish line at sunrise",
      resultTitle: "Video prompt",
    },
    product: {
      title: "Product Descriptions",
      desc: "Persuasive descriptions for clothing, electronics and more.",
      name: "Product name",
      namePh: "e.g. “Aïcha” wax print dress",
      category: "Category",
      features: "Key features",
      featuresPh: "waterproof, USB-C fast charge, 2-year warranty",
      price: "Price (optional)",
      pricePh: "e.g. 12,500 FCFA",
      resultTitle: "Product description",
    },
    social: {
      title: "Social Content",
      desc: "Captions, hooks and hashtags for TikTok, Facebook and WhatsApp.",
      platform: "Platform",
      topic: "Product / topic",
      topicPh: "e.g. my new sneaker collection",
      goal: "Objective",
      resultTitle: "Social media content",
    },
    tones: {
      persuasive: "Persuasive",
      friendly: "Friendly",
      professional: "Professional",
      energetic: "Energetic",
      humorous: "Humorous",
    },
    adPlatforms: {
      facebook: "Facebook Ads",
      instagram: "Instagram Ads",
      tiktok: "TikTok Ads",
      whatsapp: "WhatsApp",
      google: "Google Ads",
    },
    lengths: {
      short: "Short (1–2 sentences)",
      medium: "Medium (3–4 sentences)",
      long: "Long (full paragraph)",
    },
    categories: {
      clothing: "Clothing & fashion",
      electronics: "Electronics",
      beauty: "Beauty & cosmetics",
      food: "Food & drinks",
      services: "Services",
      other: "Other",
    },
    socialPlatforms: {
      tiktok: "TikTok",
      facebook: "Facebook",
      whatsapp: "WhatsApp",
    },
    goals: {
      awareness: "Brand awareness",
      sales: "Drive sales",
      engagement: "Engagement",
      traffic: "Website traffic",
    },
    videoStyles: {
      cinematic: "Cinematic",
      ugc: "UGC (user-style)",
      motion: "Motion design",
      testimonial: "Testimonial",
      product360: "360° product showcase",
    },
    durations: {
      s15: "15 seconds",
      s30: "30 seconds",
      s60: "60 seconds",
    },
    aspects: {
      r916: "9:16 (vertical)",
      r11: "1:1 (square)",
      r169: "16:9 (landscape)",
    },
    errors: {
      emptyProduct: "Please enter a product or service.",
      emptyTopic: "Please describe your product or topic.",
      generic: "Something went wrong. Please try again.",
    },
  },
  history: {
    title: "Generation history",
    subtitle:
      "Everything you generate is saved locally on this device — it never leaves your browser.",
    empty: "Nothing saved yet. Generate something in the Studio!",
    filterByType: "Filter by type",
    searchPh: "Search in history…",
    clearAll: "Clear all",
    confirmClear: "Delete all saved content?",
    delete: "Delete",
    types: {
      adText: "Ad text",
      video: "Video prompt",
      product: "Product description",
      social: "Social content",
    },
  },
  analytics: {
    title: "Analytics Dashboard",
    subtitle: "A live overview of your advertising performance across Africa.",
    dateRange: "Period",
    last7: "Last 7 days",
    last30: "Last 30 days",
    last90: "Last 90 days",
    region: "Region",
    channel: "Channel",
    category: "Category",
    kpi: {
      revenue: "Revenue",
      impressions: "Impressions",
      clicks: "Clicks",
      conversions: "Conversions",
      ctr: "Click-through rate",
      roas: "ROAS",
      vsPrevious: "vs previous period",
    },
    charts: {
      revenueTrend: "Revenue trend",
      revenueTrendSub: "Revenue vs ad spend over time",
      byChannel: "Revenue by channel",
      byChannelSub: "Total revenue per acquisition channel",
      byCategory: "Revenue by category",
      byCategorySub: "Share of total revenue",
    },
    table: "Campaign performance",
    tableSub: "Sortable and filterable campaign data",
    columns: {
      campaign: "Campaign",
      category: "Category",
      region: "Region",
      channel: "Channel",
      impressions: "Impressions",
      clicks: "Clicks",
      ctr: "CTR",
      conversions: "Conv.",
      revenue: "Revenue",
      spend: "Spend",
      roas: "ROAS",
    },
    showing: "Showing {count} campaigns",
    pageInfo: "Page {page} of {pages}",
    empty: "No campaigns match these filters.",
    regions: {
      all: "All regions",
      west: "West Africa",
      east: "East Africa",
      north: "North Africa",
      south: "Southern Africa",
    },
    channels: {
      all: "All channels",
      tiktok: "TikTok",
      facebook: "Facebook",
      whatsapp: "WhatsApp",
      instagram: "Instagram",
    },
    categories: {
      all: "All categories",
      clothing: "Clothing",
      electronics: "Electronics",
      beauty: "Beauty",
      food: "Food & drinks",
      services: "Services",
      other: "Other",
    },
  },
  toast: {
    copied: "Copied to clipboard!",
    copyFailed: "Copy failed — please copy manually.",
    saved: "Saved to history",
    cleared: "History cleared",
    deleted: "Entry deleted",
    error: "Something went wrong. Please try again.",
  },
  footer: {
    made: "Built with ❤️ for African entrepreneurs",
    demo: "Demo mode — all AI generation runs locally in your browser.",
  },
};

const fr: typeof en = {
  app: {
    name: "NUEVA AI STUDIO",
    company: "NUEVA TECHNOLOGY",
    tagline: "Créez du contenu publicitaire professionnel avec l’IA",
  },
  nav: {
    studio: "Studio",
    analytics: "Analyses",
    history: "Historique",
  },
  common: {
    copy: "Copier",
    copied: "Copié !",
    generate: "Générer",
    regenerate: "Régénérer",
    generating: "Génération…",
    clear: "Effacer",
    delete: "Supprimer",
    search: "Rechercher",
    all: "Tout",
    optional: "facultatif",
    actions: "Actions",
    close: "Fermer",
    cancel: "Annuler",
    yes: "Oui",
  },
  header: {
    demoBadge: "Mode démo · aucune clé API requise",
    switchTheme: "Changer de thème",
    language: "Langue",
  },
  studio: {
    title: "Studio de contenu IA",
    subtitle:
      "Générez des textes publicitaires, des prompts vidéo, des descriptions produit et des contenus pour les réseaux sociaux — en français ou en anglais, directement dans votre navigateur. Gratuit et sans inscription.",
    adText: {
      title: "Texte publicitaire",
      desc: "Titres, accroches et appels à l’action pour vos publicités.",
      product: "Produit / service",
      productPh: "ex. savon au karité bio",
      audience: "Public cible",
      audiencePh: "ex. jeunes mamans à Dakar",
      defaultAudience: "vos clients",
      tone: "Ton",
      platform: "Plateforme",
      length: "Longueur",
      benefit: "Bénéfice clé",
      benefitPh: "ex. 100 % naturel, fabriqué au Sénégal",
      resultTitle: "Votre texte publicitaire",
    },
    video: {
      title: "Prompts vidéo",
      desc: "Des prompts prêts à l’emploi pour des vidéos publicitaires réalistes générées par IA.",
      product: "Produit / marque",
      productPh: "ex. boisson énergisante NUEVA",
      style: "Style vidéo",
      duration: "Durée",
      aspect: "Format",
      scene: "Scène clé (facultatif)",
      scenePh: "ex. un coureur franchissant la ligne d’arrivée au lever du soleil",
      resultTitle: "Prompt vidéo",
    },
    product: {
      title: "Descriptions produit",
      desc: "Des descriptions persuasives pour vêtements, électronique et plus.",
      name: "Nom du produit",
      namePh: "ex. robe en wax « Aïcha »",
      category: "Catégorie",
      features: "Caractéristiques clés",
      featuresPh: "étanche, charge rapide USB-C, garantie 2 ans",
      price: "Prix (facultatif)",
      pricePh: "ex. 12 500 FCFA",
      resultTitle: "Description produit",
    },
    social: {
      title: "Contenu réseaux sociaux",
      desc: "Légendes, accroches et hashtags pour TikTok, Facebook et WhatsApp.",
      platform: "Plateforme",
      topic: "Produit / sujet",
      topicPh: "ex. ma nouvelle collection de baskets",
      goal: "Objectif",
      resultTitle: "Contenu réseaux sociaux",
    },
    tones: {
      persuasive: "Persuasif",
      friendly: "Chaleureux",
      professional: "Professionnel",
      energetic: "Énergique",
      humorous: "Humoristique",
    },
    adPlatforms: {
      facebook: "Facebook Ads",
      instagram: "Instagram Ads",
      tiktok: "TikTok Ads",
      whatsapp: "WhatsApp",
      google: "Google Ads",
    },
    lengths: {
      short: "Court (1–2 phrases)",
      medium: "Moyen (3–4 phrases)",
      long: "Long (paragraphe complet)",
    },
    categories: {
      clothing: "Mode & habillement",
      electronics: "Électronique",
      beauty: "Beauté & cosmétiques",
      food: "Alimentation & boissons",
      services: "Services",
      other: "Autre",
    },
    socialPlatforms: {
      tiktok: "TikTok",
      facebook: "Facebook",
      whatsapp: "WhatsApp",
    },
    goals: {
      awareness: "Notoriété",
      sales: "Ventes",
      engagement: "Engagement",
      traffic: "Trafic web",
    },
    videoStyles: {
      cinematic: "Cinématique",
      ugc: "UGC (style utilisateur)",
      motion: "Motion design",
      testimonial: "Témoignage",
      product360: "Présentation 360°",
    },
    durations: {
      s15: "15 secondes",
      s30: "30 secondes",
      s60: "60 secondes",
    },
    aspects: {
      r916: "9:16 (vertical)",
      r11: "1:1 (carré)",
      r169: "16:9 (paysage)",
    },
    errors: {
      emptyProduct: "Veuillez saisir un produit ou un service.",
      emptyTopic: "Veuillez décrire votre produit ou sujet.",
      generic: "Une erreur est survenue. Veuillez réessayer.",
    },
  },
  history: {
    title: "Historique des générations",
    subtitle:
      "Tout ce que vous générez est enregistré localement sur cet appareil — rien ne quitte votre navigateur.",
    empty: "Rien d’enregistré pour le moment. Générez quelque chose dans le Studio !",
    filterByType: "Filtrer par type",
    searchPh: "Rechercher dans l’historique…",
    clearAll: "Tout effacer",
    confirmClear: "Supprimer tout le contenu enregistré ?",
    delete: "Supprimer",
    types: {
      adText: "Texte publicitaire",
      video: "Prompt vidéo",
      product: "Description produit",
      social: "Contenu social",
    },
  },
  analytics: {
    title: "Tableau de bord analytique",
    subtitle: "Vue d’ensemble en direct de vos performances publicitaires en Afrique.",
    dateRange: "Période",
    last7: "7 derniers jours",
    last30: "30 derniers jours",
    last90: "90 derniers jours",
    region: "Région",
    channel: "Canal",
    category: "Catégorie",
    kpi: {
      revenue: "Revenus",
      impressions: "Impressions",
      clicks: "Clics",
      conversions: "Conversions",
      ctr: "Taux de clics",
      roas: "ROAS",
      vsPrevious: "vs période précédente",
    },
    charts: {
      revenueTrend: "Tendance des revenus",
      revenueTrendSub: "Revenus vs dépenses publicitaires dans le temps",
      byChannel: "Revenus par canal",
      byChannelSub: "Revenus totaux par canal d’acquisition",
      byCategory: "Revenus par catégorie",
      byCategorySub: "Répartition du chiffre d’affaires",
    },
    table: "Performance des campagnes",
    tableSub: "Données de campagnes triables et filtrables",
    columns: {
      campaign: "Campagne",
      category: "Catégorie",
      region: "Région",
      channel: "Canal",
      impressions: "Impressions",
      clicks: "Clics",
      ctr: "CTR",
      conversions: "Conv.",
      revenue: "Revenus",
      spend: "Dépenses",
      roas: "ROAS",
    },
    showing: "Affichage de {count} campagnes",
    pageInfo: "Page {page} sur {pages}",
    empty: "Aucune campagne ne correspond à ces filtres.",
    regions: {
      all: "Toutes les régions",
      west: "Afrique de l’Ouest",
      east: "Afrique de l’Est",
      north: "Afrique du Nord",
      south: "Afrique australe",
    },
    channels: {
      all: "Tous les canaux",
      tiktok: "TikTok",
      facebook: "Facebook",
      whatsapp: "WhatsApp",
      instagram: "Instagram",
    },
    categories: {
      all: "Toutes les catégories",
      clothing: "Mode",
      electronics: "Électronique",
      beauty: "Beauté",
      food: "Alimentation",
      services: "Services",
      other: "Autre",
    },
  },
  toast: {
    copied: "Copié dans le presse-papiers !",
    copyFailed: "Échec de la copie — veuillez copier manuellement.",
    saved: "Enregistré dans l’historique",
    cleared: "Historique effacé",
    deleted: "Entrée supprimée",
    error: "Une erreur est survenue. Veuillez réessayer.",
  },
  footer: {
    made: "Conçu avec ❤️ pour les entrepreneurs africains",
    demo: "Mode démo — toute la génération IA se fait localement dans votre navigateur.",
  },
};

const translations: Record<Language, typeof en> = { en, fr };

function lookup(dict: unknown, path: string): string | null {
  let node = dict;
  for (const key of path.split(".")) {
    if (node && typeof node === "object" && key in node) {
      node = (node as Record<string, unknown>)[key];
    } else {
      return null;
    }
  }
  return typeof node === "string" ? node : null;
}

export function translate(
  lang: Language,
  path: string,
  vars?: Record<string, string | number>
): string {
  let text = lookup(translations[lang], path) ?? lookup(translations.en, path) ?? path;
  if (vars) {
    for (const [key, value] of Object.entries(vars)) {
      text = text.split(`{${key}}`).join(String(value));
    }
  }
  return text;
}

interface I18nContextValue {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (path: string, vars?: Record<string, string | number>) => string;
  locale: string;
}

const I18nContext = createContext<I18nContextValue | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Language>(() =>
    typeof localStorage !== "undefined" && localStorage.getItem("nueva_lang") === "en"
      ? "en"
      : "fr"
  );

  useEffect(() => {
    localStorage.setItem("nueva_lang", lang);
    document.documentElement.lang = lang;
  }, [lang]);

  const setLang = useCallback((next: Language) => setLangState(next), []);
  const t = useCallback(
    (path: string, vars?: Record<string, string | number>) => translate(lang, path, vars),
    [lang]
  );
  const value = useMemo(
    () => ({ lang, setLang, t, locale: lang === "fr" ? "fr-FR" : "en-US" }),
    [lang, setLang, t]
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}
