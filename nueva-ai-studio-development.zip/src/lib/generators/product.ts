import type { Lang, Values, Variant } from '../../types';
import { buildCtx, clean, colon, ctaLine, hashtag, pick, shorten, stripEnd, upper1, type Ctx } from './helpers';

interface CatData {
  label: string;
  intro: string[];
  benefits: string[];
  closing: string;
  keywords: string[];
}

const CATS: Record<Lang, Record<string, CatData>> = {
  en: {
    clothing: {
      label: 'Fashion',
      intro: ['Look sharp, feel comfortable.', 'Style that moves with you.'],
      benefits: ['Soft, breathable and made to last wash after wash.', 'A flattering fit designed for everyday confidence.'],
      closing: 'Perfect for work, weekends and special occasions.',
      keywords: ['fashion', 'outfit', 'African style', 'clothing'],
    },
    electronics: {
      label: 'Electronics',
      intro: ['Smart technology, made simple.', 'Power and performance you can rely on.'],
      benefits: ['Reliable performance for work, study and entertainment.', 'Built for busy days and demanding use.'],
      closing: 'A smart upgrade for your daily routine.',
      keywords: ['electronics', 'gadget', 'tech', 'smart device'],
    },
    beauty: {
      label: 'Beauty',
      intro: ['Glow with confidence.', 'Care that you can feel.'],
      benefits: ['Gentle on skin and rich in care.', 'Designed to nourish and leave you feeling soft and fresh.'],
      closing: 'Treat yourself to a daily ritual of self-care.',
      keywords: ['beauty', 'skincare', 'self-care', 'natural'],
    },
    food: {
      label: 'Food & drink',
      intro: ['Fresh flavour, made with care.', 'Taste the difference.'],
      benefits: ['Authentic taste prepared with quality ingredients.', 'Ready to enjoy and easy to share.'],
      closing: 'Perfect for family meals, gatherings and gifts.',
      keywords: ['food', 'homemade', 'tasty', 'local flavour'],
    },
    home: {
      label: 'Home & living',
      intro: ['Make your space feel like home.', 'Function meets style.'],
      benefits: ['Functional design with a touch of style.', 'Durable materials chosen for everyday use.'],
      closing: 'A thoughtful addition to any room.',
      keywords: ['home', 'decor', 'living', 'household'],
    },
    other: {
      label: 'Products',
      intro: ['Quality you can trust.', 'Made to make life easier.'],
      benefits: ['Carefully made with attention to detail.', 'Great value for everyday use.'],
      closing: 'A smart choice you will be happy to recommend.',
      keywords: ['quality', 'bestseller', 'great value', 'shop local'],
    },
  },
  fr: {
    clothing: {
      label: 'Mode',
      intro: ['Du style et du confort.', 'Un style qui vous suit partout.'],
      benefits: ['Doux, respirant et conçu pour durer lavage après lavage.', 'Une coupe flatteuse pour gagner en confiance chaque jour.'],
      closing: 'Parfait pour le travail, le week-end et les grandes occasions.',
      keywords: ['mode', 'tenue', 'style africain', 'vêtements'],
    },
    electronics: {
      label: 'Électronique',
      intro: ['La technologie, tout simplement.', 'Puissance et performance sur lesquelles compter.'],
      benefits: ['Des performances fiables pour le travail, les études et les loisirs.', 'Conçu pour les journées bien remplies et un usage intensif.'],
      closing: 'Une mise à niveau intelligente pour votre quotidien.',
      keywords: ['électronique', 'gadget', 'high-tech', 'appareil connecté'],
    },
    beauty: {
      label: 'Beauté',
      intro: ['Rayonnez en toute confiance.', 'Un soin qui se ressent.'],
      benefits: ['Doux pour la peau et riche en soins.', 'Conçu pour nourrir et laisser une sensation de douceur et de fraîcheur.'],
      closing: 'Offrez-vous un rituel de bien-être au quotidien.',
      keywords: ['beauté', 'soin', 'bien-être', 'naturel'],
    },
    food: {
      label: 'Alimentation',
      intro: ['Des saveurs fraîches, préparées avec soin.', 'Goûtez la différence.'],
      benefits: ['Un goût authentique préparé avec des ingrédients de qualité.', 'Prêt à savourer et facile à partager.'],
      closing: 'Idéal pour les repas en famille, les réunions et les cadeaux.',
      keywords: ['cuisine', 'fait maison', 'délicieux', 'saveurs locales'],
    },
    home: {
      label: 'Maison',
      intro: ['Faites de votre espace un vrai chez-vous.', 'Quand l’utile rencontre le beau.'],
      benefits: ['Un design fonctionnel avec une touche de style.', 'Des matériaux durables choisis pour l’usage quotidien.'],
      closing: 'Un ajout réfléchi pour chaque pièce.',
      keywords: ['maison', 'déco', 'intérieur', 'équipement'],
    },
    other: {
      label: 'Produits',
      intro: ['La qualité en toute confiance.', 'Conçu pour vous simplifier la vie.'],
      benefits: ['Fabriqué avec soin et souci du détail.', 'Un excellent rapport qualité-prix au quotidien.'],
      closing: 'Un choix malin que vous recommanderez avec plaisir.',
      keywords: ['qualité', 'best-seller', 'bon plan', 'made in Africa'],
    },
  },
};

function detailLines(v: Values, fr: boolean): string[] {
  const out: string[] = [];
  const add = (en: string, frs: string, val?: string) => {
    const s = clean(val);
    if (s) out.push(`${fr ? frs : en}${fr ? ' : ' : ': '}${s}`);
  };
  switch (v.category) {
    case 'clothing':
      add('Fabric', 'Tissu', v.material);
      add('Sizes & colours', 'Tailles & couleurs', v.sizes);
      break;
    case 'electronics':
      add('Key specs', 'Caractéristiques', v.specs);
      add('Warranty', 'Garantie', v.warranty);
      break;
    case 'beauty':
    case 'food':
      add('Ingredients', 'Ingrédients', v.ingredients);
      break;
    default:
      add('Materials & dimensions', 'Matériaux & dimensions', v.material);
  }
  const price = clean(v.price);
  if (price) out.push(fr ? `Prix : ${price}` : `Price: ${price}`);
  return out;
}

function parseFeatures(raw: string | undefined): string[] {
  return (raw ?? '')
    .split(/[\n;]+|,(?![^(]*\))/)
    .map((s) => stripEnd(clean(s)))
    .filter(Boolean)
    .slice(0, 8);
}

function keywordsLine(c: Ctx, cat: CatData): string {
  const base = [c.name, ...cat.keywords, c.city, c.country].filter(Boolean);
  const tags = [...c.tags, ...cat.keywords.map(hashtag)].filter(Boolean);
  return `${base.join(', ')}\n${Array.from(new Set(tags)).slice(0, 8).join(' ')}`;
}

export function generateProduct(v: Values, lang: Lang): Variant[] {
  const c = buildCtx(v, lang);
  const fr = c.fr;
  const sep = colon(c);
  const cat = CATS[lang][v.category] ?? CATS[lang].other;
  const features = parseFeatures(v.features);
  const bullets = (features.length ? features : cat.benefits.map(stripEnd)).map((f) => `• ${upper1(f)}`).join('\n');
  const details = detailLines(v, fr);
  const cta = ctaLine({ ...c, goal: 'sales' });
  const intro = pick(cat.intro);

  const L = fr
    ? { title: 'Titre du produit (SEO)', short: 'Description courte', full: 'Description complète', features: 'Points forts', specs: 'Détails & caractéristiques', kw: 'Mots-clés & hashtags', story: 'Description narrative' }
    : { title: 'Product title (SEO)', short: 'Short description', full: 'Full description', features: 'Key features', specs: 'Details & specifications', kw: 'Keywords & hashtags', story: 'Story-style description' };

  /* ---- Version 1: marketplace / SEO ---- */
  const title1 = `${c.name} – ${upper1(shorten(c.desc, 60))} | ${cat.label}`;
  const short1 = `${intro} ${c.name}${sep} ${c.desc}.`;
  const full1 = [
    `${c.e(0)} ${c.name}${sep} ${c.desc}.`,
    cat.benefits.join(' '),
    fr ? `Pensé pour ${c.audience} ${c.where}.` : `Made for ${c.audience} ${c.where}.`,
    cat.closing,
    cta,
  ].join('\n\n');

  const v1: Variant = {
    title: fr ? 'Style marketplace (SEO)' : 'Marketplace style (SEO)',
    sections: [
      { label: L.title, text: title1 },
      { label: L.short, text: short1 },
      { label: L.full, text: full1 },
      { label: L.features, text: bullets },
      ...(details.length ? [{ label: L.specs, text: details.join('\n') }] : []),
      { label: L.kw, text: keywordsLine(c, cat) },
    ],
  };

  /* ---- Version 2: storytelling ---- */
  const title2 = `${c.name} — ${intro}`;
  const story = [
    fr
      ? `${c.e(1)} ${intro} Faites connaissance avec ${c.name}${sep} ${c.desc}.`
      : `${c.e(1)} ${intro} Meet ${c.name}${sep} ${c.desc}.`,
    fr
      ? `Créé pour ${c.audience} ${c.where} qui en attendent plus de ce qu’ils achètent. ${cat.benefits[0]}`
      : `Created for ${c.audience} ${c.where} who expect more from what they buy. ${cat.benefits[0]}`,
    `${cat.benefits[1]} ${cat.closing}`,
    cta,
  ].join('\n\n');

  const v2: Variant = {
    title: fr ? 'Style narratif' : 'Storytelling style',
    sections: [
      { label: L.title, text: title2 },
      { label: L.story, text: story },
      { label: L.features, text: bullets },
      ...(details.length ? [{ label: L.specs, text: details.join('\n') }] : []),
      { label: L.kw, text: keywordsLine(c, cat) },
    ],
  };

  return [v1, v2];
}
