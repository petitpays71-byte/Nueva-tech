import { useId, useRef, useState, type KeyboardEvent } from 'react';
import { ChartTooltip } from './ChartTooltip';
import { niceScale, useTweenedArray, useWidth } from './chartUtils';

export interface BarDatum {
  key: string;
  label: string;
  full: string;
  value: number;
}

interface Props {
  data: BarDatum[];
  selectedKey?: string | null;
  onSelect?: (key: string) => void;
  format: (v: number) => string;
  formatAxis: (v: number) => string;
  shareLabel: string;
  height?: number;
  colorTop?: string;
  colorBottom?: string;
  ariaLabel: string;
}

const M = { t: 16, r: 8, b: 28, l: 50 };

function topRounded(x: number, y: number, w: number, h: number, r: number): string {
  const rr = Math.max(0, Math.min(r, h, w / 2));
  return `M ${x} ${y + h} L ${x} ${y + rr} Q ${x} ${y} ${x + rr} ${y} L ${x + w - rr} ${y} Q ${x + w} ${y} ${x + w} ${y + rr} L ${x + w} ${y + h} Z`;
}

export function BarChart({ data, selectedKey, onSelect, format, formatAxis, shareLabel, height = 260, colorTop = '#22d3ee', colorBottom = '#2f7bff', ariaLabel }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const width = useWidth(wrapRef);
  const gid = `bc${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  const [hover, setHover] = useState<number | null>(null);

  const values = data.map((d) => d.value);
  const total = values.reduce((s, v) => s + v, 0);
  const scale = niceScale(Math.max(1, ...values));
  const tv = useTweenedArray(values, { fromZero: true });
  const tmax = Math.max(1e-6, useTweenedArray([scale.max])[0]);

  const n = data.length;
  const iw = Math.max(10, width - M.l - M.r);
  const ih = height - M.t - M.b;
  const band = iw / Math.max(1, n);
  const bw = Math.min(44, band * 0.58);
  const yAt = (v: number) => M.t + ih - Math.min(1.02, Math.max(0, v / tmax)) * ih;

  const onKey = (e: KeyboardEvent, key: string) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      onSelect?.(key);
    }
  };

  const hd = hover !== null ? data[hover] : null;

  return (
    <div ref={wrapRef} className="relative w-full select-none" style={{ height }} onPointerLeave={() => setHover(null)}>
      {width > 0 && (
        <svg width={width} height={height} role="img" aria-label={ariaLabel} className="block overflow-visible">
          <defs>
            <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={colorTop} />
              <stop offset="100%" stopColor={colorBottom} />
            </linearGradient>
          </defs>

          {Array.from({ length: scale.divisions + 1 }, (_, k) => {
            const v = (tmax * k) / scale.divisions;
            const y = yAt(v);
            return (
              <g key={k}>
                <line x1={M.l} x2={width - M.r} y1={y} y2={y} strokeDasharray={k === 0 ? undefined : '3 5'} style={{ stroke: 'var(--c-line)' }} />
                <text x={M.l - 8} y={y + 3.5} textAnchor="end" fontSize="10.5" style={{ fill: 'var(--c-muted)' }}>
                  {formatAxis(v)}
                </text>
              </g>
            );
          })}

          {data.map((d, i) => {
            const cx = M.l + band * i + band / 2;
            const x = cx - bw / 2;
            const y = yAt(tv[i]);
            const h = Math.max(0, M.t + ih - y);
            const selected = selectedKey && selectedKey !== 'all' ? selectedKey === d.key : null;
            const opacity = selected === false ? 0.28 : hover !== null && hover !== i ? 0.6 : 1;
            return (
              <g
                key={d.key}
                role="button"
                tabIndex={0}
                aria-label={`${d.full}: ${format(d.value)}`}
                aria-pressed={selected === true}
                onKeyDown={(e) => onKey(e, d.key)}
                onClick={() => onSelect?.(d.key)}
                onPointerEnter={() => setHover(i)}
                onPointerMove={() => setHover(i)}
                onFocus={() => setHover(i)}
                onBlur={() => setHover(null)}
                style={{ cursor: onSelect ? 'pointer' : 'default', outline: 'none' }}
              >
                {/* generous invisible hit area */}
                <rect x={cx - band / 2} y={M.t} width={band} height={ih + M.b} fill="transparent" />
                {hover === i && <rect x={cx - band / 2 + 2} y={M.t} width={band - 4} height={ih} rx="8" fill={colorBottom} opacity="0.08" />}
                <path d={topRounded(x, y, bw, h, 7)} fill={`url(#${gid})`} opacity={opacity} style={{ transition: 'opacity .2s ease', filter: hover === i || selected ? `drop-shadow(0 0 8px ${colorBottom}88)` : undefined }} />
                <text x={cx} y={height - 9} textAnchor="middle" fontSize="10.5" fontWeight={selected || hover === i ? 700 : 500} style={{ fill: selected || hover === i ? 'var(--c-ink)' : 'var(--c-muted)', transition: 'fill .2s' }}>
                  {d.label}
                </text>
              </g>
            );
          })}
        </svg>
      )}

      {hd && hover !== null && (
        <ChartTooltip x={M.l + band * hover + band / 2} y={yAt(tv[hover] ?? 0)} containerWidth={width}>
          <div className="mb-1 font-semibold text-ink">{hd.full}</div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-muted">{shareLabel}</span>
            <span className="font-semibold text-muted tabular-nums">{total ? Math.round((hd.value / total) * 100) : 0}%</span>
          </div>
          <div className="mt-0.5 text-right text-sm font-bold text-ink tabular-nums">{format(hd.value)}</div>
        </ChartTooltip>
      )}
    </div>
  );
}
