import type { Language } from "../types";

export type HistoryType = "adText" | "video" | "product" | "social";

export interface HistoryEntry {
  id: string;
  type: HistoryType;
  title: string;
  content: string;
  language: Language;
  createdAt: number;
}

export const HISTORY_EVENT = "nueva-history-updated";

const STORAGE_KEY = "nueva_history_v1";
const MAX_ENTRIES = 200;

function safeParse(raw: string | null): HistoryEntry[] {
  if (!raw) return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as HistoryEntry[]) : [];
  } catch {
    return [];
  }
}

export function loadHistory(): HistoryEntry[] {
  if (typeof localStorage === "undefined") return [];
  return safeParse(localStorage.getItem(STORAGE_KEY));
}

function persist(entries: HistoryEntry[]): void {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries.slice(0, MAX_ENTRIES)));
  } catch {
    // storage full or unavailable — ignore
  }
}

function createId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `h-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export function addHistoryEntry(entry: Omit<HistoryEntry, "id" | "createdAt">): HistoryEntry {
  const full: HistoryEntry = { ...entry, id: createId(), createdAt: Date.now() };
  persist([full, ...loadHistory()]);
  return full;
}

export function removeHistoryEntry(id: string): void {
  persist(loadHistory().filter((entry) => entry.id !== id));
}

export function clearHistory(): void {
  persist([]);
}
