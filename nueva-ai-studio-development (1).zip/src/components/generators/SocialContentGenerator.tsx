import { useState } from "react";
import { useI18n } from "../../i18n";
import { useGenerator } from "../../hooks/useGenerator";
import { generateSocialContent } from "../../utils/demo";
import type { SocialGoal, SocialPlatform } from "../../types";
import {
  Button,
  Field,
  GeneratorCard,
  GeneratorResult,
  Select,
  TextInput,
} from "../ui";
import { Icon } from "../Icon";

const PLATFORMS: SocialPlatform[] = ["tiktok", "facebook", "whatsapp"];
const GOALS: SocialGoal[] = ["awareness", "sales", "engagement", "traffic"];

export function SocialContentGenerator() {
  const { t, lang } = useI18n();
  const [platform, setPlatform] = useState<SocialPlatform>("tiktok");
  const [topic, setTopic] = useState("");
  const [goal, setGoal] = useState<SocialGoal>("sales");
  const gen = useGenerator(lang, "social", t("studio.social.title"));

  const handleGenerate = () => {
    if (!topic.trim()) {
      gen.setError("studio.errors.emptyTopic");
      return;
    }
    gen.generate(
      JSON.stringify([platform, topic, goal, lang]),
      () =>
        generateSocialContent({
          platform,
          topic: topic.trim(),
          goal,
          language: lang,
          labels: { platform: t(`studio.socialPlatforms.${platform}`) },
        })
    );
  };

  return (
    <GeneratorCard icon="share" title={t("studio.social.title")} desc={t("studio.social.desc")}>
      <div className="space-y-3">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Select
            label={t("studio.social.platform")}
            value={platform}
            onChange={(v) => setPlatform(v as SocialPlatform)}
            options={PLATFORMS.map((k) => ({ value: k, label: t(`studio.socialPlatforms.${k}`) }))}
          />
          <Select
            label={t("studio.social.goal")}
            value={goal}
            onChange={(v) => setGoal(v as SocialGoal)}
            options={GOALS.map((k) => ({ value: k, label: t(`studio.goals.${k}`) }))}
          />
        </div>
        <Field label={t("studio.social.topic")}>
          <TextInput
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder={t("studio.social.topicPh")}
          />
        </Field>
      </div>
      <div className="mt-auto space-y-2 pt-4">
        <Button onClick={handleGenerate} loading={gen.loading} className="w-full">
          <Icon name="sparkles" className="h-4 w-4" />
          {gen.result ? t("common.regenerate") : t("common.generate")}
        </Button>
        {gen.error && (
          <p className="flex items-center gap-1.5 text-sm text-rose-500">
            <Icon name="alert" className="h-4 w-4 shrink-0" />
            {t(gen.error)}
          </p>
        )}
        <GeneratorResult
          title={t("studio.social.resultTitle")}
          result={gen.result}
          loading={gen.loading}
          onRegenerate={handleGenerate}
        />
      </div>
    </GeneratorCard>
  );
}
