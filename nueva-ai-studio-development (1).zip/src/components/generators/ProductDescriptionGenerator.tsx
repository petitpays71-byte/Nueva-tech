import { useState } from "react";
import { useI18n } from "../../i18n";
import { useGenerator } from "../../hooks/useGenerator";
import { generateProductDescription } from "../../utils/demo";
import type { Category } from "../../types";
import {
  Button,
  Field,
  GeneratorCard,
  GeneratorResult,
  Select,
  Textarea,
  TextInput,
} from "../ui";
import { Icon } from "../Icon";

const CATEGORIES: Category[] = ["clothing", "electronics", "beauty", "food", "services", "other"];

export function ProductDescriptionGenerator() {
  const { t, lang } = useI18n();
  const [name, setName] = useState("");
  const [category, setCategory] = useState<Category>("clothing");
  const [features, setFeatures] = useState("");
  const [price, setPrice] = useState("");
  const gen = useGenerator(lang, "product", t("studio.product.title"));

  const handleGenerate = () => {
    if (!name.trim()) {
      gen.setError("studio.errors.emptyProduct");
      return;
    }
    gen.generate(
      JSON.stringify([name, category, features, price, lang]),
      () =>
        generateProductDescription({
          name: name.trim(),
          category,
          features: features.trim(),
          price: price.trim(),
          language: lang,
          labels: { category: t(`studio.categories.${category}`) },
        })
    );
  };

  return (
    <GeneratorCard
      icon="package"
      title={t("studio.product.title")}
      desc={t("studio.product.desc")}
    >
      <div className="space-y-3">
        <Field label={t("studio.product.name")}>
          <TextInput
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t("studio.product.namePh")}
          />
        </Field>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Select
            label={t("studio.product.category")}
            value={category}
            onChange={(v) => setCategory(v as Category)}
            options={CATEGORIES.map((k) => ({ value: k, label: t(`studio.categories.${k}`) }))}
          />
          <Field label={`${t("studio.product.price")}`}>
            <TextInput
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder={t("studio.product.pricePh")}
            />
          </Field>
        </div>
        <Field label={`${t("studio.product.features")} (${t("common.optional")})`}>
          <Textarea
            value={features}
            onChange={(e) => setFeatures(e.target.value)}
            placeholder={t("studio.product.featuresPh")}
            rows={3}
          />
        </Field>
      </div>
      <div className="mt-auto space-y-2 pt-4">
        <Button onClick={handleGenerate} loading={gen.loading} className="w-full">
          <Icon name="sparkles" className="h-4 w-4" />
          {gen.result ? t("common.regenerate") : t("common.generate")}
        </Button>
        {gen.error && (
          <p className="flex items-center gap-1.5 text-sm text-rose-500">
            <Icon name="alert" className="h-4 w-4 shrink-0" />
            {t(gen.error)}
          </p>
        )}
        <GeneratorResult
          title={t("studio.product.resultTitle")}
          result={gen.result}
          loading={gen.loading}
          onRegenerate={handleGenerate}
        />
      </div>
    </GeneratorCard>
  );
}
