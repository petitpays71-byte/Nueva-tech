import type { ContentType, L10n, MarketId, PlatformId, Row, StatusId } from '../../types';
import { dayOfWeek, todayDay } from '../format';

/** Product names used to label the sample content rows (bilingual). */
export const PRODUCT_NAMES: L10n[] = [
  { en: 'Wax print dresses', fr: 'Robes en wax' },
  { en: 'Bluetooth speaker', fr: 'Enceinte Bluetooth' },
  { en: 'Shea butter cream', fr: 'Crème au karité' },
  { en: 'Solar power bank', fr: 'Batterie solaire' },
  { en: 'Ankara shirts', fr: 'Chemises Ankara' },
  { en: 'Leather sandals', fr: 'Sandales en cuir' },
  { en: 'Hair care kit', fr: 'Kit soin cheveux' },
  { en: 'Jollof catering', fr: 'Traiteur Jollof' },
  { en: 'Smartphone cases', fr: 'Coques de téléphone' },
  { en: 'Braided baskets', fr: 'Paniers tressés' },
  { en: 'Hibiscus juice', fr: 'Jus de bissap' },
  { en: 'LED solar lamps', fr: 'Lampes solaires LED' },
  { en: 'Beaded jewelry', fr: 'Bijoux en perles' },
  { en: 'Kids school bags', fr: 'Sacs d’école enfants' },
  { en: 'Kente scarves', fr: 'Foulards Kente' },
  { en: 'Wireless earbuds', fr: 'Écouteurs sans fil' },
];

export const DATA_DAYS = 420;

/** Small deterministic PRNG so the sample data is stable between reloads. */
function mulberry32(seed: number) {
  let a = seed | 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function weighted<T extends string>(rnd: () => number, entries: [T, number][]): T {
  const total = entries.reduce((s, [, w]) => s + w, 0);
  let r = rnd() * total;
  for (const [k, w] of entries) {
    r -= w;
    if (r <= 0) return k;
  }
  return entries[entries.length - 1][0];
}

const PLATFORM_BASE: Record<PlatformId, number> = { tiktok: 9200, facebook: 5400, whatsapp: 2100 };
const PLATFORM_CTR: Record<PlatformId, number> = { tiktok: 0.036, facebook: 0.027, whatsapp: 0.1 };
const TYPE_REACH: Record<ContentType, number> = { ads: 1, video: 1.55, product: 0.7, social: 1.2 };
const TYPE_CVR: Record<ContentType, number> = { ads: 0.045, video: 0.035, product: 0.062, social: 0.03 };
const MARKET_MUL: Record<MarketId, number> = { ng: 1.35, za: 1.15, ke: 1.05, sn: 0.95, ci: 0.95, gh: 0.9, cm: 0.8, ma: 0.85 };
const MARKET_AOV: Record<MarketId, number> = { ng: 0.9, za: 1.4, ke: 1.0, sn: 0.95, ci: 1.0, gh: 0.95, cm: 0.9, ma: 1.25 };

/** Builds ~14 months of realistic daily content-performance rows ending today. */
export function buildDataset(): Row[] {
  const today = todayDay();
  const start = today - DATA_DAYS + 1;
  const rows: Row[] = [];

  for (let d = start; d <= today; d++) {
    const rnd = mulberry32(d * 9973 + 17);
    const i = d - start;
    const growth = 0.6 + 0.85 * (i / (DATA_DAYS - 1));
    const week = [0.7, 1.0, 1.1, 1.15, 1.1, 0.95, 0.7][dayOfWeek(d)];
    const season = 1 + 0.16 * Math.sin((d / 31) * Math.PI);
    const count = Math.max(1, Math.round(0.8 + rnd() * 1.6 + 1.4 * growth * week));

    for (let k = 0; k < count; k++) {
      const type = weighted<ContentType>(rnd, [['ads', 0.3], ['video', 0.18], ['product', 0.27], ['social', 0.25]]);
      const platform =
        type === 'social'
          ? weighted<PlatformId>(rnd, [['tiktok', 0.42], ['facebook', 0.33], ['whatsapp', 0.25]])
          : weighted<PlatformId>(rnd, [['facebook', 0.4], ['tiktok', 0.3], ['whatsapp', 0.3]]);
      const market = weighted<MarketId>(rnd, [['sn', 0.16], ['ci', 0.15], ['ng', 0.22], ['gh', 0.11], ['ke', 0.13], ['cm', 0.08], ['za', 0.09], ['ma', 0.06]]);

      const viral = rnd() < 0.06 ? 2.6 : 1;
      const impressions = Math.round(PLATFORM_BASE[platform] * TYPE_REACH[type] * MARKET_MUL[market] * growth * season * (0.5 + rnd() * 1.1) * viral);
      const clicks = Math.round(impressions * PLATFORM_CTR[platform] * (0.7 + rnd() * 0.7));
      const cvr = TYPE_CVR[type] * (0.7 + rnd() * 0.8) * (platform === 'whatsapp' ? 1.4 : 1);
      const conversions = Math.round(clicks * cvr);
      const revenue = Math.round(conversions * (10 + rnd() * 38) * MARKET_AOV[market]);

      const age = today - d;
      const status: StatusId = age < 14 ? (rnd() < 0.82 ? 'live' : 'paused') : rnd() < 0.93 ? 'completed' : 'paused';

      rows.push({
        id: `NC-${(d * 8 + k).toString(36).toUpperCase()}`,
        day: d,
        product: Math.floor(rnd() * PRODUCT_NAMES.length),
        type,
        platform,
        market,
        status,
        impressions,
        clicks,
        conversions,
        revenue,
      });
    }
  }
  return rows;
}

export const DATA_START = () => todayDay() - DATA_DAYS + 1;
