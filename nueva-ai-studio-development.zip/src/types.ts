export type Lang = 'en' | 'fr';
export type Theme = 'dark' | 'light';

/** Localised string pair used by static configuration (fields, options…). */
export type L10n = { en: string; fr: string };

export type ToolId = 'ads' | 'video' | 'product' | 'social';
export type RouteId = 'dashboard' | ToolId | 'history' | 'settings';

export type Values = Record<string, string>;

export interface Section {
  label: string;
  text: string;
}

export interface Variant {
  title: string;
  sections: Section[];
}

export type GenerationMode = 'demo' | 'ai';

export interface HistoryItem {
  id: string;
  tool: ToolId;
  createdAt: number;
  lang: Lang;
  mode: GenerationMode;
  summary: string;
  inputs: Values;
  variants: Variant[];
  favorite: boolean;
}

export interface AppSettings {
  proxyUrl: string;
}

/* ---------------- Analytics ---------------- */
export type ContentType = 'ads' | 'video' | 'product' | 'social';
export type PlatformId = 'tiktok' | 'facebook' | 'whatsapp';
export type MarketId = 'sn' | 'ci' | 'ng' | 'gh' | 'ke' | 'cm' | 'za' | 'ma';
export type StatusId = 'live' | 'completed' | 'paused';
export type MetricId = 'generated' | 'reach' | 'clicks' | 'conversions' | 'revenue';

export interface Row {
  id: string;
  /** days since unix epoch (UTC date components of the local day) */
  day: number;
  product: number;
  type: ContentType;
  platform: PlatformId;
  market: MarketId;
  status: StatusId;
  impressions: number;
  clicks: number;
  conversions: number;
  revenue: number;
}

export type PresetId = '7' | '30' | '90' | '180' | 'custom';

export interface Filters {
  preset: PresetId;
  from: number;
  to: number;
  type: ContentType | 'all';
  market: MarketId | 'all';
  platform: PlatformId | 'all';
}
