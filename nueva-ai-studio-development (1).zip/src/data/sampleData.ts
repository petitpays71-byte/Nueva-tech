import type { Category, Channel, Region } from "../types";

export interface DailyMetric {
  date: string; // YYYY-MM-DD
  region: Region;
  channel: Channel;
  category: Category;
  impressions: number;
  clicks: number;
  conversions: number;
  revenue: number; // XOF
  spend: number; // XOF
}

export interface Campaign {
  id: string;
  name: string;
  category: Category;
  region: Region;
  channel: Channel;
  startDate: string;
  impressions: number;
  clicks: number;
  conversions: number;
  revenue: number;
  spend: number;
}

/* Deterministic PRNG so the dataset is stable between reloads. */
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rand = mulberry32(20260214);

const REGIONS: Region[] = ["west", "north", "east", "south"];
const CHANNELS: Channel[] = ["tiktok", "facebook", "instagram", "whatsapp"];
const CATEGORIES: Category[] = ["clothing", "electronics", "beauty", "food", "services", "other"];

const regionBase: Record<Region, number> = { west: 1.0, north: 0.75, east: 0.6, south: 0.5 };
const channelReach: Record<Channel, number> = { tiktok: 1.4, facebook: 1.1, instagram: 0.9, whatsapp: 0.55 };
const channelCtr: Record<Channel, number> = { tiktok: 0.021, facebook: 0.016, instagram: 0.019, whatsapp: 0.06 };
const channelConv: Record<Channel, number> = { tiktok: 0.018, facebook: 0.024, instagram: 0.021, whatsapp: 0.07 };
const categoryValue: Record<Category, number> = {
  electronics: 1.5,
  clothing: 1.0,
  beauty: 0.9,
  food: 0.7,
  services: 1.2,
  other: 0.8,
};

function isoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

const DAYS_OF_HISTORY = 120;
let dailyCache: DailyMetric[] | null = null;

/**
 * Realistic-looking daily metrics for the last 120 days, broken down by
 * region × channel × category, with growth, weekly seasonality and noise.
 */
export function getDailyMetrics(): DailyMetric[] {
  if (dailyCache) return dailyCache;
  const rows: DailyMetric[] = [];
  const today = new Date();
  for (let i = DAYS_OF_HISTORY - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const date = isoDate(d);
    const dow = d.getDay();
    const weekendBoost = dow === 0 || dow === 6 ? 1.25 : 1;
    const growth = 1 + (DAYS_OF_HISTORY - i) * 0.004; // gentle growth toward today
    const season = 1 + 0.15 * Math.sin(i / 6);
    for (const region of REGIONS) {
      for (const channel of CHANNELS) {
        for (const category of CATEGORIES) {
          const base = 4000 * regionBase[region] * channelReach[channel] * categoryValue[category];
          const noise = 0.7 + rand() * 0.6;
          const impressions = Math.round(base * growth * weekendBoost * noise * season);
          const clicks = Math.round(impressions * channelCtr[channel] * (0.75 + rand() * 0.5));
          const conversions = Math.round(clicks * channelConv[channel] * (0.7 + rand() * 0.6));
          const aov = 8000 + rand() * 22000; // average order value in XOF
          const revenue = Math.round(conversions * aov * (0.8 + rand() * 0.4));
          const spend = Math.round(revenue / (2.4 + rand() * 1.6)); // ROAS between ~2.4 and 4
          rows.push({ date, region, channel, category, impressions, clicks, conversions, revenue, spend });
        }
      }
    }
  }
  dailyCache = rows;
  return rows;
}

const CAMPAIGN_NAMES: Record<Category, string[]> = {
  clothing: ["Wax Vibes", "Urban Fit", "Kente Wave", "Denim Story", "Sahel Style"],
  electronics: ["TechFlash", "SoundStorm", "PowerUp", "GadgetHub", "VoltEdge"],
  beauty: ["Glow Ritual", "Shea Secret", "Silk Skin", "Kalahari Glow"],
  food: ["Taste Trail", "Spice Route", "FreshBox", "Pepper & Co"],
  services: ["ClickService", "ProLink", "TaskHive"],
  other: ["MegaDeal", "Flash Sale", "Bundle King"],
};

const CHANNEL_LABEL: Record<Channel, string> = {
  tiktok: "TikTok",
  facebook: "Facebook",
  whatsapp: "WhatsApp",
  instagram: "Instagram",
};

let campaignCache: Campaign[] | null = null;

/** A realistic campaign list with metrics consistent with the daily data. */
export function getCampaigns(): Campaign[] {
  if (campaignCache) return campaignCache;
  const rows: Campaign[] = [];
  let n = 0;
  for (const category of CATEGORIES) {
    for (const region of REGIONS) {
      for (const channel of CHANNELS) {
        if (rand() < 0.35) continue; // not every combination has a live campaign
        const base = CAMPAIGN_NAMES[category][Math.floor(rand() * CAMPAIGN_NAMES[category].length)];
        const name = `${base} · ${CHANNEL_LABEL[channel]}`;
        const impressions = Math.round((20000 + rand() * 380000) * regionBase[region]);
        const clicks = Math.round(impressions * channelCtr[channel] * (0.7 + rand() * 0.6));
        const conversions = Math.round(clicks * channelConv[channel] * (0.7 + rand() * 0.6));
        const revenue = Math.round(conversions * (9000 + rand() * 20000));
        const spend = Math.round(revenue / (2.1 + rand() * 2.4));
        const start = new Date();
        start.setDate(start.getDate() - Math.floor(rand() * 88));
        rows.push({
          id: `camp-${n++}`,
          name,
          category,
          region,
          channel,
          startDate: isoDate(start),
          impressions,
          clicks,
          conversions,
          revenue,
          spend,
        });
      }
    }
  }
  campaignCache = rows;
  return rows;
}
