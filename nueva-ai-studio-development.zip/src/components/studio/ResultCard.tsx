import { Sparkles } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import type { Variant } from '../../types';
import { CopyButton } from '../ui/CopyButton';

export function variantToText(v: Variant): string {
  return [v.title, ...v.sections.map((s) => `${s.label}\n${s.text}`)].join('\n\n');
}

export function ResultCard({ variant, index, animate = true }: { variant: Variant; index: number; animate?: boolean }) {
  const { t } = useApp();
  return (
    <article className={`card overflow-hidden ${animate ? 'animate-fade-up' : ''}`} style={animate ? { animationDelay: `${index * 90}ms` } : undefined}>
      <header className="flex flex-wrap items-center justify-between gap-2 border-b border-line bg-surface2/60 px-4 py-3">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-brand/15 text-brand">
            <Sparkles size={14} />
          </span>
          <div className="min-w-0">
            <div className="text-[10px] font-semibold tracking-wider text-muted uppercase">{t('gen.variant', { n: index + 1 })}</div>
            <div className="truncate text-sm font-bold text-ink">{variant.title}</div>
          </div>
        </div>
        <CopyButton text={variantToText(variant)} label={t('common.copyAll')} variant="primary" />
      </header>

      <div className="divide-y divide-line/70">
        {variant.sections.map((s, i) => (
          <section key={i} className="px-4 py-3.5">
            <div className="mb-1.5 flex items-center justify-between gap-2">
              <h4 className="text-[11px] font-bold tracking-wider text-brand uppercase">{s.label}</h4>
              <CopyButton text={s.text} />
            </div>
            <p className="text-sm leading-relaxed break-words whitespace-pre-wrap text-ink/90">{s.text}</p>
            <div className="mt-1.5 text-[10px] font-medium text-muted">{t('gen.charCount', { n: s.text.length })}</div>
          </section>
        ))}
      </div>
    </article>
  );
}
