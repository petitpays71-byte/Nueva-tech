import { Megaphone, ShoppingBag, Share2, Video, type LucideIcon } from 'lucide-react';
import type { L10n, Lang, ToolId, Values } from '../types';
import { MARKETS } from './markets';

export interface Option {
  value: string;
  label: L10n;
}

export interface FieldDef {
  key: string;
  type: 'text' | 'textarea' | 'select';
  label: L10n;
  placeholder?: L10n;
  required?: boolean;
  options?: Option[];
  /** 1 = half width on ≥ sm screens, 2 = full width (default) */
  span?: 1 | 2;
  rows?: number;
  maxLength?: number;
  showIf?: (v: Values) => boolean;
}

export interface ToolDef {
  id: ToolId;
  icon: LucideIcon;
  fields: FieldDef[];
  defaults: Values;
  examples: Record<Lang, Values>;
}

/* ---------------- shared option lists ---------------- */
const MARKET_OPTIONS: Option[] = [
  ...MARKETS.map((m) => ({ value: m.id, label: m.name })),
  { value: 'africa', label: { en: 'Pan-African / other', fr: 'Panafricain / autre' } },
];

const TONE_OPTIONS: Option[] = [
  { value: 'professional', label: { en: 'Professional', fr: 'Professionnel' } },
  { value: 'friendly', label: { en: 'Friendly', fr: 'Convivial' } },
  { value: 'bold', label: { en: 'Bold & energetic', fr: 'Audacieux & énergique' } },
  { value: 'luxury', label: { en: 'Premium & elegant', fr: 'Premium & élégant' } },
  { value: 'fun', label: { en: 'Fun & playful', fr: 'Fun & ludique' } },
  { value: 'inspiring', label: { en: 'Inspiring', fr: 'Inspirant' } },
];

const GOAL_OPTIONS: Option[] = [
  { value: 'sales', label: { en: 'Get sales / orders', fr: 'Obtenir des ventes / commandes' } },
  { value: 'awareness', label: { en: 'Build awareness', fr: 'Gagner en notoriété' } },
  { value: 'leads', label: { en: 'Collect leads / quotes', fr: 'Collecter des contacts / devis' } },
];

const OUT_LANG_OPTIONS: Option[] = [
  { value: 'fr', label: { en: 'French', fr: 'Français' } },
  { value: 'en', label: { en: 'English', fr: 'Anglais' } },
];

/* ---------------- reusable fields ---------------- */
const nameField = (label: L10n, placeholder: L10n): FieldDef => ({
  key: 'name',
  type: 'text',
  label,
  placeholder,
  required: true,
  maxLength: 80,
});

const descField = (label: L10n, placeholder: L10n): FieldDef => ({
  key: 'desc',
  type: 'textarea',
  label,
  placeholder,
  required: true,
  rows: 3,
  maxLength: 400,
});

const audienceField: FieldDef = {
  key: 'audience',
  type: 'text',
  label: { en: 'Target audience', fr: 'Public cible' },
  placeholder: { en: 'e.g. women 22–40, students, small shops', fr: 'ex. femmes 22–40 ans, étudiants, petites boutiques' },
  maxLength: 80,
};

const offerField: FieldDef = {
  key: 'offer',
  type: 'text',
  label: { en: 'Offer / promotion', fr: 'Offre / promotion' },
  placeholder: { en: 'e.g. -20% this week, free delivery', fr: 'ex. -20 % cette semaine, livraison gratuite' },
  maxLength: 80,
  span: 1,
};

const contactField: FieldDef = {
  key: 'contact',
  type: 'text',
  label: { en: 'WhatsApp / phone', fr: 'WhatsApp / téléphone' },
  placeholder: { en: '+221 77 000 00 00', fr: '+221 77 000 00 00' },
  maxLength: 40,
  span: 1,
};

const marketField: FieldDef = {
  key: 'market',
  type: 'select',
  label: { en: 'Market', fr: 'Marché' },
  options: MARKET_OPTIONS,
  span: 1,
};

const toneField: FieldDef = {
  key: 'tone',
  type: 'select',
  label: { en: 'Tone of voice', fr: 'Ton' },
  options: TONE_OPTIONS,
  span: 1,
};

const goalField: FieldDef = {
  key: 'goal',
  type: 'select',
  label: { en: 'Goal', fr: 'Objectif' },
  options: GOAL_OPTIONS,
  span: 1,
};

const outLangField = (label: L10n): FieldDef => ({
  key: 'outLang',
  type: 'select',
  label,
  options: OUT_LANG_OPTIONS,
  span: 1,
});

const isCat = (...cats: string[]) => (v: Values) => cats.includes(v.category);

/* ---------------- tools ---------------- */
export const TOOLS: Record<ToolId, ToolDef> = {
  ads: {
    id: 'ads',
    icon: Megaphone,
    defaults: { market: 'sn', tone: 'friendly', goal: 'sales' },
    fields: [
      nameField({ en: 'Brand or product name', fr: 'Nom de la marque ou du produit' }, { en: 'e.g. Awa Wax Studio', fr: 'ex. Awa Wax Studio' }),
      descField(
        { en: 'What do you sell?', fr: 'Que vendez-vous ?' },
        { en: 'e.g. handmade wax-print dresses for modern women', fr: 'ex. robes en wax faites main pour femmes modernes' },
      ),
      offerField,
      contactField,
      audienceField,
      marketField,
      goalField,
      toneField,
      outLangField({ en: 'Output language', fr: 'Langue du texte' }),
    ],
    examples: {
      en: {
        name: 'Awa Wax Studio',
        desc: 'handmade wax-print dresses for modern women',
        offer: '-20% this week',
        contact: '+221 77 000 00 00',
        audience: 'women 22–40',
        market: 'sn',
        goal: 'sales',
        tone: 'friendly',
      },
      fr: {
        name: 'Awa Wax Studio',
        desc: 'robes en wax faites main pour femmes modernes',
        offer: '-20 % cette semaine',
        contact: '+221 77 000 00 00',
        audience: 'femmes de 22 à 40 ans',
        market: 'sn',
        goal: 'sales',
        tone: 'friendly',
      },
    },
  },

  video: {
    id: 'video',
    icon: Video,
    defaults: { market: 'ng', tone: 'bold', scene: 'street', style: 'cinematic', duration: '15', ratio: '9:16', mood: 'golden' },
    fields: [
      nameField({ en: 'Product or brand', fr: 'Produit ou marque' }, { en: 'e.g. Kofi Sound Mini', fr: 'ex. Kofi Sound Mini' }),
      descField(
        { en: 'Describe the product', fr: 'Décrivez le produit' },
        { en: 'e.g. portable Bluetooth speaker with 20h battery', fr: 'ex. enceinte Bluetooth portable avec 20 h d’autonomie' },
      ),
      {
        key: 'scene',
        type: 'select',
        label: { en: 'Scene / setting', fr: 'Décor / lieu' },
        span: 1,
        options: [
          { value: 'street', label: { en: 'Urban street', fr: 'Rue urbaine' } },
          { value: 'market', label: { en: 'Local market', fr: 'Marché local' } },
          { value: 'shop', label: { en: 'Modern shop', fr: 'Boutique moderne' } },
          { value: 'studio', label: { en: 'Clean studio', fr: 'Studio épuré' } },
          { value: 'home', label: { en: 'Home lifestyle', fr: 'Intérieur / maison' } },
          { value: 'workshop', label: { en: 'Workshop / craft', fr: 'Atelier / artisanat' } },
        ],
      },
      {
        key: 'style',
        type: 'select',
        label: { en: 'Visual style', fr: 'Style visuel' },
        span: 1,
        options: [
          { value: 'cinematic', label: { en: 'Cinematic realistic', fr: 'Cinéma réaliste' } },
          { value: 'ugc', label: { en: 'UGC smartphone', fr: 'UGC smartphone' } },
          { value: 'documentary', label: { en: 'Documentary', fr: 'Documentaire' } },
          { value: 'premium', label: { en: 'Premium product', fr: 'Produit premium' } },
        ],
      },
      {
        key: 'duration',
        type: 'select',
        label: { en: 'Duration', fr: 'Durée' },
        span: 1,
        options: [
          { value: '6', label: { en: '6 seconds', fr: '6 secondes' } },
          { value: '10', label: { en: '10 seconds', fr: '10 secondes' } },
          { value: '15', label: { en: '15 seconds', fr: '15 secondes' } },
          { value: '30', label: { en: '30 seconds', fr: '30 secondes' } },
        ],
      },
      {
        key: 'ratio',
        type: 'select',
        label: { en: 'Format', fr: 'Format' },
        span: 1,
        options: [
          { value: '9:16', label: { en: '9:16 vertical (TikTok, Reels)', fr: '9:16 vertical (TikTok, Reels)' } },
          { value: '16:9', label: { en: '16:9 landscape (YouTube)', fr: '16:9 paysage (YouTube)' } },
          { value: '1:1', label: { en: '1:1 square (Facebook)', fr: '1:1 carré (Facebook)' } },
        ],
      },
      {
        key: 'mood',
        type: 'select',
        label: { en: 'Lighting & mood', fr: 'Lumière & ambiance' },
        span: 1,
        options: [
          { value: 'golden', label: { en: 'Golden hour', fr: 'Heure dorée' } },
          { value: 'daylight', label: { en: 'Bright daylight', fr: 'Plein jour' } },
          { value: 'night', label: { en: 'Night city lights', fr: 'Lumières de nuit' } },
          { value: 'soft', label: { en: 'Soft studio light', fr: 'Lumière douce studio' } },
        ],
      },
      marketField,
      audienceField,
      { ...offerField, span: 1 },
      { ...contactField, span: 1 },
      goalField,
      toneField,
      outLangField({ en: 'Voice-over language', fr: 'Langue de la voix off' }),
    ],
    examples: {
      en: {
        name: 'Kofi Sound Mini',
        desc: 'portable Bluetooth speaker with 20-hour battery and deep bass',
        scene: 'street',
        style: 'cinematic',
        duration: '15',
        ratio: '9:16',
        mood: 'golden',
        market: 'ng',
        audience: 'young professionals and students',
        offer: 'Free delivery in Lagos',
        contact: '+234 800 000 0000',
        goal: 'sales',
        tone: 'bold',
      },
      fr: {
        name: 'Kofi Sound Mini',
        desc: 'enceinte Bluetooth portable avec 20 h d’autonomie et basses profondes',
        scene: 'street',
        style: 'cinematic',
        duration: '15',
        ratio: '9:16',
        mood: 'golden',
        market: 'ng',
        audience: 'jeunes actifs et étudiants',
        offer: 'Livraison gratuite à Lagos',
        contact: '+234 800 000 0000',
        goal: 'sales',
        tone: 'bold',
      },
    },
  },

  product: {
    id: 'product',
    icon: ShoppingBag,
    defaults: { category: 'clothing', market: 'ci', tone: 'professional' },
    fields: [
      {
        key: 'category',
        type: 'select',
        label: { en: 'Product category', fr: 'Catégorie de produit' },
        options: [
          { value: 'clothing', label: { en: 'Clothing & fashion', fr: 'Vêtements & mode' } },
          { value: 'electronics', label: { en: 'Electronics', fr: 'Électronique' } },
          { value: 'beauty', label: { en: 'Beauty & care', fr: 'Beauté & soins' } },
          { value: 'food', label: { en: 'Food & drink', fr: 'Alimentation & boissons' } },
          { value: 'home', label: { en: 'Home & living', fr: 'Maison & déco' } },
          { value: 'other', label: { en: 'Other products', fr: 'Autres produits' } },
        ],
      },
      nameField({ en: 'Product name', fr: 'Nom du produit' }, { en: 'e.g. Kente Fusion Shirt', fr: 'ex. Chemise Kente Fusion' }),
      descField(
        { en: 'Short description', fr: 'Description courte' },
        { en: 'e.g. slim-fit shirt in hand-woven cotton', fr: 'ex. chemise coupe ajustée en coton tissé main' },
      ),
      {
        key: 'features',
        type: 'textarea',
        label: { en: 'Key features (one per line)', fr: 'Points forts (un par ligne)' },
        placeholder: { en: 'Breathable cotton\nHand-stitched seams\nMachine washable', fr: 'Coton respirant\nCouture main\nLavable en machine' },
        rows: 4,
        maxLength: 500,
      },
      {
        key: 'material',
        type: 'text',
        label: { en: 'Fabric / materials', fr: 'Tissu / matériaux' },
        placeholder: { en: '100% cotton', fr: '100 % coton' },
        span: 1,
        showIf: isCat('clothing', 'home', 'other'),
      },
      {
        key: 'sizes',
        type: 'text',
        label: { en: 'Sizes & colours', fr: 'Tailles & couleurs' },
        placeholder: { en: 'S–XXL · blue, black, gold', fr: 'S–XXL · bleu, noir, doré' },
        span: 1,
        showIf: isCat('clothing'),
      },
      {
        key: 'specs',
        type: 'text',
        label: { en: 'Key specs', fr: 'Caractéristiques clés' },
        placeholder: { en: '20,000 mAh · 2 USB ports', fr: '20 000 mAh · 2 ports USB' },
        span: 1,
        showIf: isCat('electronics'),
      },
      {
        key: 'warranty',
        type: 'text',
        label: { en: 'Warranty', fr: 'Garantie' },
        placeholder: { en: '12 months', fr: '12 mois' },
        span: 1,
        showIf: isCat('electronics'),
      },
      {
        key: 'ingredients',
        type: 'text',
        label: { en: 'Ingredients / components', fr: 'Ingrédients / composants' },
        placeholder: { en: 'Shea butter, coconut oil…', fr: 'Beurre de karité, huile de coco…' },
        showIf: isCat('beauty', 'food'),
      },
      {
        key: 'price',
        type: 'text',
        label: { en: 'Price', fr: 'Prix' },
        placeholder: { en: 'e.g. 15,000 FCFA', fr: 'ex. 15 000 FCFA' },
        span: 1,
        maxLength: 40,
      },
      marketField,
      audienceField,
      toneField,
      outLangField({ en: 'Output language', fr: 'Langue du texte' }),
    ],
    examples: {
      en: {
        category: 'clothing',
        name: 'Kente Fusion Shirt',
        desc: 'slim-fit shirt in hand-woven cotton with Kente-inspired trim',
        features: 'Breathable hand-woven cotton\nHand-stitched seams\nMachine washable',
        material: '100% cotton',
        sizes: 'S–XXL · blue, black, gold',
        price: '15,000 FCFA',
        market: 'ci',
        audience: 'men 25–45',
        tone: 'professional',
      },
      fr: {
        category: 'clothing',
        name: 'Chemise Kente Fusion',
        desc: 'chemise coupe ajustée en coton tissé main avec bordure inspirée du Kente',
        features: 'Coton tissé main respirant\nCouture main\nLavable en machine',
        material: '100 % coton',
        sizes: 'S–XXL · bleu, noir, doré',
        price: '15 000 FCFA',
        market: 'ci',
        audience: 'hommes de 25 à 45 ans',
        tone: 'professional',
      },
    },
  },

  social: {
    id: 'social',
    icon: Share2,
    defaults: { platform: 'tiktok', market: 'ke', tone: 'fun', goal: 'sales' },
    fields: [
      {
        key: 'platform',
        type: 'select',
        label: { en: 'Platform', fr: 'Plateforme' },
        options: [
          { value: 'tiktok', label: { en: 'TikTok', fr: 'TikTok' } },
          { value: 'facebook', label: { en: 'Facebook', fr: 'Facebook' } },
          { value: 'whatsapp', label: { en: 'WhatsApp', fr: 'WhatsApp' } },
        ],
      },
      nameField({ en: 'Brand or product name', fr: 'Nom de la marque ou du produit' }, { en: 'e.g. Mama Njeri Spices', fr: 'ex. Épices Mama Njeri' }),
      descField(
        { en: 'What do you sell?', fr: 'Que vendez-vous ?' },
        { en: 'e.g. freshly ground pilau and curry spice blends', fr: 'ex. mélanges d’épices pilau et curry fraîchement moulus' },
      ),
      offerField,
      contactField,
      audienceField,
      marketField,
      goalField,
      toneField,
      outLangField({ en: 'Output language', fr: 'Langue du texte' }),
    ],
    examples: {
      en: {
        platform: 'tiktok',
        name: 'Mama Njeri Spices',
        desc: 'freshly ground pilau and curry spice blends',
        offer: 'Buy 2 get 1 free',
        contact: '+254 700 000 000',
        audience: 'home cooks and young families',
        market: 'ke',
        goal: 'sales',
        tone: 'fun',
      },
      fr: {
        platform: 'tiktok',
        name: 'Épices Mama Njeri',
        desc: 'mélanges d’épices pilau et curry fraîchement moulus',
        offer: '2 achetés, 1 offert',
        contact: '+254 700 000 000',
        audience: 'cuisiniers à la maison et jeunes familles',
        market: 'ke',
        goal: 'sales',
        tone: 'fun',
      },
    },
  },
};

export const TOOL_ORDER: ToolId[] = ['ads', 'video', 'product', 'social'];

export function defaultValues(tool: ToolId, lang: Lang): Values {
  return { ...TOOLS[tool].defaults, outLang: lang };
}
