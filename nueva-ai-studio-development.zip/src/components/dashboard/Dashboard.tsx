import { useMemo, useState, type ReactNode } from 'react';
import { ArrowRight, DollarSign, Eye, FileText, MousePointerClick, Sparkles, SearchX } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import type { ContentType, Filters, MarketId, MetricId, PlatformId } from '../../types';
import type { TKey } from '../../i18n/translations';
import { CONTENT_TYPES, MARKETS, PLATFORMS, PLATFORM_COLORS, TYPE_COLORS } from '../../lib/markets';
import { TOOLS, TOOL_ORDER } from '../../lib/tools';
import { DATA_DAYS, buildDataset } from '../../lib/analytics/data';
import { applyFilters, bucketSizeFor, ctrSeries, metricOfRow, metricOfTotals, pctChange, seriesFor, sumRows } from '../../lib/analytics/aggregate';
import { defaultFilters } from '../../lib/analytics/filters';
import { fmtCompact, fmtCurrency, fmtDay, fmtInt, fmtPercent, relativeTime, todayDay } from '../../lib/format';
import { LineChart } from '../charts/LineChart';
import { BarChart } from '../charts/BarChart';
import { DonutChart } from '../charts/DonutChart';
import { FilterBar } from './FilterBar';
import { KpiCard } from './KpiCard';
import { DataTable } from './DataTable';
import { CopyButton } from '../ui/CopyButton';
import { ModeBadge } from '../ui/ModeBadge';
import { cn } from '../../utils/cn';

const METRICS: { id: MetricId; label: TKey; color: string }[] = [
  { id: 'reach', label: 'metric.reach', color: '#2f7bff' },
  { id: 'clicks', label: 'metric.clicks', color: '#22d3ee' },
  { id: 'conversions', label: 'metric.conversions', color: '#8b7bff' },
  { id: 'revenue', label: 'metric.revenue', color: '#34d9a5' },
  { id: 'generated', label: 'metric.generatedShort', color: '#5aa2ff' },
];

function Panel({ title, subtitle, actions, className, children }: { title: string; subtitle?: string; actions?: ReactNode; className?: string; children: ReactNode }) {
  return (
    <section className={cn('card flex flex-col p-4 sm:p-5', className)}>
      <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-display text-base font-bold text-ink">{title}</h3>
          {subtitle && <p className="mt-0.5 text-xs text-muted">{subtitle}</p>}
        </div>
        {actions}
      </div>
      <div className="min-h-0 flex-1">{children}</div>
    </section>
  );
}

function EmptyChart({ height = 220 }: { height?: number }) {
  const { t } = useApp();
  return (
    <div className="grid place-items-center text-center" style={{ height }}>
      <div>
        <SearchX className="mx-auto mb-2 text-muted" size={28} />
        <div className="text-sm font-semibold text-ink">{t('chart.noData')}</div>
        <div className="mt-0.5 text-xs text-muted">{t('chart.noDataHint')}</div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ hero */
function Hero() {
  const { t, navigate } = useApp();
  return (
    <section className="relative overflow-hidden rounded-3xl border border-white/10 p-5 text-white sm:p-7 lg:p-8" style={{ background: 'linear-gradient(135deg,#071238 0%,#0b2a7c 52%,#1b66ff 130%)', boxShadow: '0 24px 60px -28px rgba(27,102,255,.65)' }}>
      <div className="pointer-events-none absolute -top-24 -right-16 h-72 w-72 rounded-full bg-cyan-400/25 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 left-1/3 h-64 w-64 rounded-full bg-blue-500/30 blur-3xl" />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.07]"
        style={{ backgroundImage: 'linear-gradient(#fff 1px,transparent 1px),linear-gradient(90deg,#fff 1px,transparent 1px)', backgroundSize: '36px 36px' }}
      />
      <div className="relative">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-white/10 px-2.5 py-1 text-[11px] font-semibold tracking-wide backdrop-blur">
            <Sparkles size={12} className="text-cyan-300" /> {t('app.by')}
          </span>
          <ModeBadge className="!bg-white/10 backdrop-blur" />
        </div>
        <h2 className="font-display max-w-2xl text-2xl leading-tight font-extrabold tracking-tight sm:text-3xl lg:text-4xl">{t('dash.heroTitle')}</h2>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-blue-100/85 sm:text-base">{t('dash.heroSub')}</p>

        <div className="mt-6 text-[11px] font-semibold tracking-wider text-blue-200/80 uppercase">{t('dash.quick')}</div>
        <div className="mt-2 grid grid-cols-2 gap-2.5 lg:grid-cols-4 lg:gap-3">
          {TOOL_ORDER.map((id) => {
            const Icon = TOOLS[id].icon;
            return (
              <button
                key={id}
                type="button"
                onClick={() => navigate(id)}
                className="group flex cursor-pointer flex-col items-start gap-2 rounded-2xl border border-white/15 bg-white/[0.07] p-3.5 text-left backdrop-blur transition hover:-translate-y-0.5 hover:border-cyan-300/60 hover:bg-white/[0.14] sm:p-4"
              >
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-white/15 text-cyan-200 transition group-hover:bg-cyan-300/25">
                  <Icon size={18} />
                </span>
                <span className="text-[13px] leading-snug font-bold sm:text-sm">{t(`nav.${id}` as TKey)}</span>
                <span className="hidden text-xs leading-relaxed text-blue-100/75 sm:block">{t(`tool.${id}.desc` as TKey)}</span>
                <ArrowRight size={15} className="mt-auto text-cyan-200 opacity-70 transition group-hover:translate-x-1 group-hover:opacity-100" />
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ---------------------------------------------------------------- recent */
function Recent() {
  const { t, lang, history, reuse, navigate } = useApp();
  const items = history.slice(0, 4);
  return (
    <Panel
      title={t('dash.recent')}
      subtitle={t('dash.generatedTotal', { n: history.length })}
      actions={
        <button type="button" className="btn btn-ghost btn-sm" onClick={() => navigate('history')}>
          {t('common.viewAll')} <ArrowRight size={13} />
        </button>
      }
    >
      {items.length === 0 ? (
        <div className="flex items-center gap-3 rounded-xl border border-dashed border-line p-4 text-sm text-muted">
          <FileText size={20} className="shrink-0" />
          {t('dash.recentEmpty')}
        </div>
      ) : (
        <ul className="grid gap-2.5 md:grid-cols-2">
          {items.map((item) => {
            const Icon = TOOLS[item.tool].icon;
            const first = item.variants[0]?.sections[0]?.text ?? '';
            return (
              <li key={item.id} className="flex items-center gap-3 rounded-xl border border-line bg-surface2/60 p-3">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand/12 text-brand">
                  <Icon size={18} />
                </span>
                <button type="button" onClick={() => reuse(item)} className="min-w-0 flex-1 cursor-pointer text-left">
                  <div className="truncate text-sm font-semibold text-ink">{item.summary}</div>
                  <div className="truncate text-xs text-muted">
                    {t(`nav.${item.tool}` as TKey)} · {relativeTime(item.createdAt, lang)}
                  </div>
                </button>
                <CopyButton text={first} />
              </li>
            );
          })}
        </ul>
      )}
    </Panel>
  );
}

/* ------------------------------------------------------------- dashboard */
export function Dashboard() {
  const { t, lang, history } = useApp();
  const rows = useMemo(() => buildDataset(), []);
  const today = useMemo(() => todayDay(), []);
  const dataStart = today - DATA_DAYS + 1;

  const [filters, setFilters] = useState<Filters>(() => defaultFilters(todayDay()));
  const [metric, setMetric] = useState<MetricId>('reach');

  const f = filters;
  const len = f.to - f.from + 1;
  const prevFrom = f.from - len;
  const prevTo = f.from - 1;
  const hasPrev = prevFrom >= dataStart;
  const size = bucketSizeFor(len);

  const cur = useMemo(() => applyFilters(rows, f), [rows, f]);
  const prev = useMemo(() => applyFilters(rows, f, { from: prevFrom, to: prevTo }), [rows, f, prevFrom, prevTo]);
  const tc = useMemo(() => sumRows(cur), [cur]);
  const tp = useMemo(() => sumRows(prev), [prev]);
  const trend = (a: number, b: number) => (hasPrev ? pctChange(a, b) : null);

  /* KPI sparklines */
  const sparks = useMemo(
    () => ({
      generated: seriesFor(cur, f.from, f.to, size, 'generated'),
      reach: seriesFor(cur, f.from, f.to, size, 'reach'),
      ctr: ctrSeries(cur, f.from, f.to, size),
      revenue: seriesFor(cur, f.from, f.to, size, 'revenue'),
    }),
    [cur, f.from, f.to, size],
  );

  /* line chart */
  const meta = METRICS.find((m) => m.id === metric) ?? METRICS[0];
  const metricName = t(meta.label);
  const fmtMetric = (v: number) => (metric === 'revenue' ? fmtCurrency(v, lang) : v >= 10000 ? fmtCompact(v, lang) : fmtInt(v, lang));
  const fmtMetricFull = (v: number) => (metric === 'revenue' ? fmtCurrency(v, lang, false) : fmtInt(v, lang));
  const fmtAxis = (v: number) => (metric === 'revenue' ? `$${fmtCompact(v, lang)}` : fmtCompact(v, lang));

  const lineData = useMemo(() => {
    const curS = seriesFor(cur, f.from, f.to, size, metric);
    const prevS = hasPrev ? seriesFor(prev, prevFrom, prevTo, size, metric) : null;
    return curS.map((value, i) => {
      const start = f.from + i * size;
      const end = Math.min(f.to, start + size - 1);
      return {
        label: fmtDay(start, lang),
        tip: size === 1 ? fmtDay(start, lang, true) : `${fmtDay(start, lang)} – ${fmtDay(end, lang)}`,
        value,
        prev: prevS ? prevS[i] : undefined,
      };
    });
  }, [cur, prev, f.from, f.to, size, metric, hasPrev, prevFrom, prevTo, lang]);

  /* cross-filtered segment charts (ignore their own dimension, highlight the selection) */
  const marketRows = useMemo(() => applyFilters(rows, f, { skip: 'market' }), [rows, f]);
  const typeRows = useMemo(() => applyFilters(rows, f, { skip: 'type' }), [rows, f]);
  const platformRows = useMemo(() => applyFilters(rows, f, { skip: 'platform' }), [rows, f]);

  const barData = useMemo(
    () =>
      MARKETS.map((m) => ({
        key: m.id,
        label: m.code,
        full: m.name[lang],
        value: marketRows.filter((r) => r.market === m.id).reduce((s, r) => s + metricOfRow(r, metric), 0),
      })),
    [marketRows, metric, lang],
  );

  const mixSegments = useMemo(
    () =>
      CONTENT_TYPES.map((c) => ({
        key: c,
        label: t(`type.${c}` as TKey),
        value: typeRows.filter((r) => r.type === c).length,
        color: TYPE_COLORS[c],
      })),
    [typeRows, t],
  );

  const platformSegments = useMemo(
    () =>
      PLATFORMS.map((p) => ({
        key: p,
        label: t(`p.${p}` as TKey),
        value: platformRows.filter((r) => r.platform === p).reduce((s, r) => s + metricOfRow(r, metric), 0),
        color: PLATFORM_COLORS[p],
      })),
    [platformRows, metric, t],
  );

  const mixTotal = mixSegments.reduce((s, x) => s + x.value, 0);
  const platformTotal = platformSegments.reduce((s, x) => s + x.value, 0);

  const kpis = [
    { icon: Sparkles, label: t('metric.generated'), value: tc.count, format: (v: number) => fmtInt(v, lang), trend: trend(tc.count, tp.count), spark: sparks.generated, color: '#2f7bff' },
    { icon: Eye, label: t('metric.reach'), value: tc.impressions, format: (v: number) => fmtCompact(v, lang), trend: trend(tc.impressions, tp.impressions), spark: sparks.reach, color: '#22d3ee' },
    { icon: MousePointerClick, label: t('metric.engagement'), value: tc.ctr, format: (v: number) => fmtPercent(v, lang, 2), trend: trend(tc.ctr, tp.ctr), spark: sparks.ctr, color: '#8b7bff' },
    { icon: DollarSign, label: t('metric.revenue'), value: tc.revenue, format: (v: number) => fmtCurrency(v, lang), trend: trend(tc.revenue, tp.revenue), spark: sparks.revenue, color: '#34d9a5' },
  ];

  const noData = cur.length === 0;
  const unitLabel = size === 1 ? t('chart.perDay') : size === 7 ? t('chart.perWeek') : t('chart.perMonth');
  const metricTotal = metricOfTotals(tc, metric);

  return (
    <div className="space-y-6">
      <Hero />
      {history.length > 0 && <Recent />}

      <div className="flex flex-wrap items-end justify-between gap-2 pt-2">
        <div>
          <h2 className="font-display text-xl font-bold tracking-tight text-ink sm:text-2xl">{t('dash.title')}</h2>
          <p className="mt-0.5 text-sm text-muted">{t('dash.subtitle')}</p>
        </div>
        <span title={t('dash.sampleNote')} className="inline-flex items-center gap-1.5 rounded-full border border-brand/40 bg-brand/10 px-3 py-1 text-xs font-semibold text-brand">
          <span className="h-1.5 w-1.5 rounded-full bg-brand" /> {t('dash.sample')}
        </span>
      </div>

      <FilterBar filters={filters} onChange={setFilters} today={today} dataStart={dataStart} />

      <div className="grid grid-cols-1 gap-3 min-[520px]:grid-cols-2 sm:gap-4 xl:grid-cols-4">
        {kpis.map((k) => (
          <KpiCard key={k.label} {...k} />
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-12">
        <Panel
          className="xl:col-span-8"
          title={t('chart.trend')}
          subtitle={`${t('chart.trendSub')} · ${unitLabel}`}
          actions={
            <div className="no-scrollbar -mx-1 flex max-w-full gap-1.5 overflow-x-auto px-1" role="group">
              {METRICS.map((m) => (
                <button key={m.id} type="button" className="chip" data-active={metric === m.id} onClick={() => setMetric(m.id)}>
                  {t(m.label)}
                </button>
              ))}
            </div>
          }
        >
          {noData ? (
            <EmptyChart height={290} />
          ) : (
            <>
              <div className="mb-2 flex flex-wrap items-baseline gap-x-3 gap-y-1">
                <span className="font-display text-2xl font-bold text-ink tabular-nums">{fmtMetricFull(metricTotal)}</span>
                <span className="text-xs font-medium text-muted">
                  {metricName} · {fmtDay(f.from, lang, true)} – {fmtDay(f.to, lang, true)}
                </span>
              </div>
              <LineChart
                data={lineData}
                color={meta.color}
                format={fmtMetricFull}
                formatAxis={fmtAxis}
                currentLabel={t('chart.current')}
                prevLabel={t('chart.prev')}
                ariaLabel={`${t('chart.trend')}: ${metricName}`}
              />
            </>
          )}
        </Panel>

        <Panel className="xl:col-span-4" title={t('chart.mix')} subtitle={t('chart.mixSub')}>
          <DonutChart
            segments={mixSegments}
            selectedKey={f.type}
            onSelect={(k) => setFilters({ ...f, type: f.type === k ? 'all' : (k as ContentType) })}
            format={(v) => `${fmtInt(v, lang)} ${t('chart.pieces')}`}
            centerLabel={t('chart.total')}
            centerValue={fmtInt(mixTotal, lang)}
            shareLabel={t('chart.share')}
            emptyLabel={t('chart.noData')}
            ariaLabel={t('chart.mix')}
          />
        </Panel>

        <Panel className="xl:col-span-8" title={`${t('chart.market')} · ${metricName}`} subtitle={t('chart.marketSub')}>
          <BarChart
            data={barData}
            selectedKey={f.market}
            onSelect={(k) => setFilters({ ...f, market: f.market === k ? 'all' : (k as MarketId) })}
            format={fmtMetricFull}
            formatAxis={fmtAxis}
            shareLabel={t('chart.share')}
            colorTop={meta.color}
            colorBottom="#1b66ff"
            ariaLabel={t('chart.market')}
          />
        </Panel>

        <Panel className="xl:col-span-4" title={`${t('chart.platform')} · ${metricName}`} subtitle={t('chart.platformSub')}>
          <DonutChart
            segments={platformSegments}
            selectedKey={f.platform}
            onSelect={(k) => setFilters({ ...f, platform: f.platform === k ? 'all' : (k as PlatformId) })}
            format={fmtMetricFull}
            centerLabel={metricName}
            centerValue={fmtMetric(platformTotal)}
            shareLabel={t('chart.share')}
            emptyLabel={t('chart.noData')}
            ariaLabel={t('chart.platform')}
          />
        </Panel>
      </div>

      <DataTable rows={cur} />
    </div>
  );
}
