import { useEffect, useRef, useState } from 'react';
import { Check, Copy } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { copyText } from '../../lib/clipboard';
import { cn } from '../../utils/cn';

interface Props {
  text: string;
  label?: string;
  className?: string;
  variant?: 'ghost' | 'primary';
}

export function CopyButton({ text, label, className, variant = 'ghost' }: Props) {
  const { t, notify } = useApp();
  const [done, setDone] = useState(false);
  const timer = useRef<number | undefined>(undefined);

  useEffect(() => () => window.clearTimeout(timer.current), []);

  const onClick = async () => {
    const ok = await copyText(text);
    if (ok) {
      setDone(true);
      window.clearTimeout(timer.current);
      timer.current = window.setTimeout(() => setDone(false), 1800);
    } else {
      notify(t('common.copyFailed'), 'error');
    }
  };

  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label ?? t('common.copy')}
      className={cn('btn btn-sm', variant === 'primary' ? 'btn-primary' : 'btn-ghost', done && 'border-emerald-500/60 text-emerald-500', className)}
    >
      {done ? <Check size={14} /> : <Copy size={14} />}
      <span>{done ? t('common.copied') : (label ?? t('common.copy'))}</span>
    </button>
  );
}
