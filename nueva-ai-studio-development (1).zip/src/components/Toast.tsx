import {
  createContext,
  useCallback,
  useContext,
  useState,
  type ReactNode,
} from "react";
import { cn } from "../utils/cn";
import { Icon } from "./Icon";

type ToastType = "success" | "error" | "info";

interface ToastItem {
  id: number;
  message: string;
  type: ToastType;
}

interface ToastContextValue {
  toast: (message: string, type?: ToastType) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

let counter = 0;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);

  const toast = useCallback((message: string, type: ToastType = "success") => {
    const id = ++counter;
    setItems((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setItems((prev) => prev.filter((item) => item.id !== id));
    }, 2600);
  }, []);

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div
        aria-live="polite"
        className="pointer-events-none fixed right-4 top-4 z-[100] flex w-[calc(100%-2rem)] max-w-sm flex-col gap-2"
      >
        {items.map((item) => (
          <div
            key={item.id}
            className={cn(
              "pointer-events-auto flex animate-fade-up items-center gap-2 rounded-xl border px-4 py-3 text-sm shadow-lg backdrop-blur-xl",
              item.type === "success" &&
                "border-emerald-400/40 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300",
              item.type === "error" &&
                "border-rose-400/40 bg-rose-500/15 text-rose-700 dark:text-rose-300",
              item.type === "info" &&
                "border-electric-400/40 bg-electric-500/15 text-sky-700 dark:text-sky-200"
            )}
          >
            <Icon
              name={item.type === "success" ? "check" : item.type === "error" ? "alert" : "info"}
              className="h-4 w-4 shrink-0"
            />
            <span>{item.message}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used within ToastProvider");
  return ctx;
}
