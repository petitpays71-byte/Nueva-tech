import type { ReactNode } from 'react';
import { History, LayoutDashboard, Megaphone, Moon, Settings, Share2, ShoppingBag, Sun, Video, type LucideIcon } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import type { RouteId } from '../../types';
import type { TKey } from '../../i18n/translations';
import { Logo } from '../ui/Logo';
import { ModeBadge } from '../ui/ModeBadge';
import { cn } from '../../utils/cn';

interface NavItem {
  id: RouteId;
  icon: LucideIcon;
  label: TKey;
  short: TKey;
}

const MAIN: NavItem[] = [{ id: 'dashboard', icon: LayoutDashboard, label: 'nav.dashboard', short: 'nav.s.dashboard' }];
const TOOLS: NavItem[] = [
  { id: 'ads', icon: Megaphone, label: 'nav.ads', short: 'nav.s.ads' },
  { id: 'video', icon: Video, label: 'nav.video', short: 'nav.s.video' },
  { id: 'product', icon: ShoppingBag, label: 'nav.product', short: 'nav.s.product' },
  { id: 'social', icon: Share2, label: 'nav.social', short: 'nav.s.social' },
];
const LIBRARY: NavItem[] = [
  { id: 'history', icon: History, label: 'nav.history', short: 'nav.s.history' },
  { id: 'settings', icon: Settings, label: 'nav.settings', short: 'nav.settings' },
];
const BOTTOM: NavItem[] = [...MAIN, ...TOOLS, LIBRARY[0]];

function LangToggle() {
  const { lang, setLang, t } = useApp();
  return (
    <div role="group" aria-label={t('common.language')} className="flex rounded-xl border border-line bg-surface2 p-0.5">
      {(['fr', 'en'] as const).map((l) => (
        <button
          key={l}
          type="button"
          onClick={() => setLang(l)}
          aria-pressed={lang === l}
          className={cn(
            'cursor-pointer rounded-[10px] px-2.5 py-1 text-xs font-bold uppercase transition',
            lang === l ? 'bg-brand text-white shadow' : 'text-muted hover:text-ink',
          )}
        >
          {l}
        </button>
      ))}
    </div>
  );
}

function ThemeToggle() {
  const { theme, toggleTheme, t } = useApp();
  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={t('common.theme')}
      title={t('common.theme')}
      className="grid h-9 w-9 cursor-pointer place-items-center rounded-xl border border-line bg-surface2 text-ink transition hover:border-brand/60 hover:text-brand"
    >
      {theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}
    </button>
  );
}

function SideLink({ item }: { item: NavItem }) {
  const { route, navigate, t } = useApp();
  const active = route === item.id;
  const Icon = item.icon;
  return (
    <button
      type="button"
      onClick={() => navigate(item.id)}
      aria-current={active ? 'page' : undefined}
      className={cn(
        'group relative flex w-full cursor-pointer items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm font-medium transition',
        active ? 'bg-brand/12 text-brand' : 'text-muted hover:bg-surface2 hover:text-ink',
      )}
    >
      {active && <span className="absolute top-2 bottom-2 left-0 w-[3px] rounded-r-full bg-brand" />}
      <Icon size={18} className="shrink-0" />
      <span className="truncate">{t(item.label)}</span>
    </button>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { route, t, navigate } = useApp();
  const current = [...MAIN, ...TOOLS, ...LIBRARY].find((n) => n.id === route);

  return (
    <div className="min-h-screen lg:pl-[272px]">
      {/* ---------- desktop sidebar ---------- */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[272px] flex-col gap-1 border-r border-line bg-surface/80 p-4 backdrop-blur-xl lg:flex">
        <button type="button" onClick={() => navigate('dashboard')} className="mb-5 flex cursor-pointer items-center gap-3 px-1 py-1 text-left">
          <Logo size={40} />
          <div className="leading-tight">
            <div className="font-display text-[15px] font-bold tracking-tight text-ink">{t('app.name')}</div>
            <div className="text-[11px] font-medium text-muted">{t('app.by')}</div>
          </div>
        </button>

        <div className="px-3 pb-1 text-[11px] font-semibold tracking-wider text-muted/80 uppercase">{t('nav.workspace')}</div>
        {MAIN.map((n) => (
          <SideLink key={n.id} item={n} />
        ))}
        <div className="mt-3 px-3 pb-1 text-[11px] font-semibold tracking-wider text-muted/80 uppercase">{t('nav.create')}</div>
        {TOOLS.map((n) => (
          <SideLink key={n.id} item={n} />
        ))}
        <div className="mt-3 px-3 pb-1 text-[11px] font-semibold tracking-wider text-muted/80 uppercase">{t('nav.history')}</div>
        {LIBRARY.map((n) => (
          <SideLink key={n.id} item={n} />
        ))}

        <div className="mt-auto rounded-2xl border border-line bg-surface2 p-3.5">
          <ModeBadge />
          <p className="mt-2 text-xs leading-relaxed text-muted">{t('app.tagline')}</p>
        </div>
      </aside>

      {/* ---------- top bar ---------- */}
      <header className="sticky top-0 z-30 border-b border-line bg-bg/80 backdrop-blur-xl">
        <div className="mx-auto flex h-14 max-w-[1440px] items-center gap-2 px-4 lg:h-16 lg:px-8">
          <button type="button" onClick={() => navigate('dashboard')} className="flex min-w-0 cursor-pointer items-center gap-2.5 lg:hidden">
            <Logo size={32} />
            <div className="min-w-0 text-left leading-tight">
              <div className="font-display truncate text-[13px] font-bold tracking-tight text-ink">{t('app.name')}</div>
              <div className="truncate text-[10px] font-medium text-muted">{t('app.by')}</div>
            </div>
          </button>
          <h1 className="font-display hidden text-lg font-bold tracking-tight text-ink lg:block">{current ? t(current.label) : ''}</h1>

          <div className="ml-auto flex items-center gap-2">
            <ModeBadge className="hidden sm:inline-flex lg:hidden" />
            <LangToggle />
            <ThemeToggle />
            <button
              type="button"
              onClick={() => navigate('settings')}
              aria-label={t('nav.settings')}
              className={cn(
                'grid h-9 w-9 cursor-pointer place-items-center rounded-xl border border-line bg-surface2 text-ink transition hover:border-brand/60 hover:text-brand lg:hidden',
                route === 'settings' && 'border-brand text-brand',
              )}
            >
              <Settings size={17} />
            </button>
          </div>
        </div>
      </header>

      {/* ---------- page ---------- */}
      <main className="mx-auto max-w-[1440px] px-4 pt-5 pb-28 lg:px-8 lg:pt-7 lg:pb-12">
        <div key={route} className="animate-fade-up">
          {children}
        </div>
      </main>

      {/* ---------- mobile bottom navigation ---------- */}
      <nav
        aria-label="Primary"
        className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-surface/90 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl lg:hidden"
      >
        <ul className="mx-auto grid max-w-xl grid-cols-6">
          {BOTTOM.map((n) => {
            const active = route === n.id;
            const Icon = n.icon;
            return (
              <li key={n.id}>
                <button
                  type="button"
                  onClick={() => navigate(n.id)}
                  aria-current={active ? 'page' : undefined}
                  className={cn('relative flex w-full cursor-pointer flex-col items-center gap-0.5 px-1 pt-2 pb-2 text-[10px] font-semibold transition', active ? 'text-brand' : 'text-muted')}
                >
                  {active && <span className="absolute top-0 h-[3px] w-8 rounded-b-full bg-brand" />}
                  <Icon size={20} strokeWidth={active ? 2.4 : 2} />
                  <span className="max-w-full truncate">{t(n.short)}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
