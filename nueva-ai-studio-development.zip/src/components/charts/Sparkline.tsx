import { useId } from 'react';
import { monotonePath, useTweenedArray } from './chartUtils';

export function Sparkline({ values, color = '#2f7bff', height = 38 }: { values: number[]; color?: string; height?: number }) {
  const gid = `sp${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  const tv = useTweenedArray(values, { fromZero: true });
  const n = tv.length;
  const W = 100;
  const H = 36;
  const min = n ? Math.min(...tv) : 0;
  const max = n ? Math.max(...tv) : 1;
  const span = max - min || 1;
  const pts = tv.map((v, i) => ({ x: n <= 1 ? W / 2 : (i * W) / (n - 1), y: H - 4 - ((v - min) / span) * (H - 10) }));
  const line = monotonePath(pts);
  const area = n > 1 ? `${line} L ${W} ${H} L 0 ${H} Z` : '';

  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="block w-full" style={{ height }} aria-hidden="true">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.35" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {area && <path d={area} fill={`url(#${gid})`} />}
      {n > 1 && <path d={line} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />}
    </svg>
  );
}
