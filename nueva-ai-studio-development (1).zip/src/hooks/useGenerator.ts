import { useCallback, useState } from "react";
import { simulate } from "../utils/demo";
import { addHistoryEntry, HISTORY_EVENT, type HistoryType } from "../utils/history";
import { useToast } from "../components/Toast";
import { useI18n } from "../i18n";
import type { Language } from "../types";

/**
 * Shared logic for every demo-mode generator: loading state, error state,
 * result state, simulated latency and automatic local-history saving.
 */
export function useGenerator(language: Language, type: HistoryType, title: string) {
  const { toast } = useToast();
  const { t } = useI18n();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);

  const generate = useCallback(
    async (input: string, produce: () => string) => {
      setLoading(true);
      setError(null);
      try {
        const content = await simulate(() => produce(), 950, input);
        setResult(content);
        addHistoryEntry({ type, title, content, language });
        window.dispatchEvent(new Event(HISTORY_EVENT));
        toast(t("toast.saved"));
      } catch {
        setError("studio.errors.generic");
      } finally {
        setLoading(false);
      }
    },
    [language, type, title, toast, t]
  );

  const clear = useCallback(() => {
    setResult(null);
    setError(null);
  }, []);

  return { loading, error, result, setError, setResult, generate, clear };
}
