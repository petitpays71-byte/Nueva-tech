import type { GenerationMode, Lang, ToolId, Values, Variant } from '../../types';
import { generateAds } from './ads';
import { generateProduct } from './product';
import { generateSocial } from './social';
import { generateVideo } from './video';

export type GenErrorCode = 'network' | 'timeout' | 'http' | 'bad' | 'local';

export class GenError extends Error {
  code: GenErrorCode;
  status?: number;
  constructor(code: GenErrorCode, status?: number) {
    super(code);
    this.code = code;
    this.status = status;
  }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const DEMO: Record<ToolId, (v: Values, lang: Lang) => Variant[]> = {
  ads: generateAds,
  video: generateVideo,
  product: generateProduct,
  social: generateSocial,
};

const TOOL_BRIEF: Record<ToolId, string> = {
  ads: 'Write 3 distinct advertising text variations. Each has: headline, ad text, call to action, short version.',
  video:
    'Write 2 realistic AI video prompts in English for a short advertising video. Each has: video prompt, shot list, voice-over script, on-screen text, negative prompt, recommended settings.',
  product: 'Write 2 product description variations. Each has: SEO title, short description, full description, key features, specifications, keywords.',
  social: 'Write 3 ready-to-post variations for the selected platform (TikTok, Facebook or WhatsApp) including hashtags where relevant.',
};

export function buildPrompt(tool: ToolId, values: Values, lang: Lang): string {
  const brief = Object.entries(values)
    .filter(([, v]) => v && v.trim())
    .map(([k, v]) => `- ${k}: ${v.trim()}`)
    .join('\n');
  return [
    'You are an expert marketing copywriter for African small businesses.',
    TOOL_BRIEF[tool],
    `Write in ${lang === 'fr' ? 'French' : 'English'}${tool === 'video' ? ' (video prompts stay in English)' : ''}.`,
    'Be authentic, concise and respectful of local culture. Never invent prices or claims.',
    'Brief:',
    brief,
  ].join('\n');
}

function parseResponse(data: unknown, lang: Lang): Variant[] {
  if (data && typeof data === 'object') {
    const d = data as Record<string, unknown>;
    if (Array.isArray(d.variants)) {
      const variants: Variant[] = [];
      d.variants.forEach((raw, i) => {
        const r = raw as { title?: unknown; sections?: unknown };
        if (!r || !Array.isArray(r.sections)) return;
        const sections = r.sections
          .map((s) => s as { label?: unknown; text?: unknown })
          .filter((s) => s && typeof s.text === 'string' && s.text.trim())
          .map((s) => ({ label: typeof s.label === 'string' ? s.label : lang === 'fr' ? 'Résultat' : 'Result', text: String(s.text) }));
        if (sections.length) variants.push({ title: typeof r.title === 'string' ? r.title : `AI ${i + 1}`, sections });
      });
      if (variants.length) return variants;
    }
    const text = [d.text, d.content, d.output, d.result].find((x) => typeof x === 'string' && (x as string).trim()) as string | undefined;
    if (text) return [{ title: 'AI', sections: [{ label: lang === 'fr' ? 'Résultat' : 'Result', text: text.trim() }] }];
  }
  throw new GenError('bad');
}

async function callProxy(url: string, body: unknown, timeoutMs = 30000): Promise<unknown> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  let res: Response;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });
  } catch (e) {
    if ((e as Error)?.name === 'AbortError') throw new GenError('timeout');
    throw new GenError('network');
  } finally {
    clearTimeout(timer);
  }
  if (!res.ok) throw new GenError('http', res.status);
  try {
    return await res.json();
  } catch {
    throw new GenError('bad');
  }
}

export interface GenerateOutput {
  variants: Variant[];
  mode: GenerationMode;
}

/**
 * Generates content. With a configured proxy URL the request is sent to the user's own
 * secure endpoint (no API key ever lives in the browser); otherwise the local demo engine runs.
 */
export async function generate(tool: ToolId, values: Values, proxyUrl: string, forceDemo = false): Promise<GenerateOutput> {
  const lang: Lang = values.outLang === 'fr' ? 'fr' : 'en';

  if (proxyUrl && !forceDemo) {
    const data = await callProxy(proxyUrl, {
      tool,
      language: lang,
      inputs: values,
      prompt: buildPrompt(tool, values, lang),
    });
    return { variants: parseResponse(data, lang), mode: 'ai' };
  }

  await sleep(650 + Math.random() * 850);
  try {
    const variants = DEMO[tool](values, lang);
    if (!variants.length) throw new Error('empty');
    return { variants, mode: 'demo' };
  } catch {
    throw new GenError('local');
  }
}

export async function testEndpoint(url: string): Promise<boolean> {
  try {
    await callProxy(url, { tool: 'ads', language: 'en', inputs: { name: 'Test', desc: 'connection test' }, prompt: 'ping', test: true }, 12000);
    return true;
  } catch (e) {
    // A reachable endpoint that answers in another JSON shape still proves connectivity.
    return e instanceof GenError && (e.code === 'bad' || (e.code === 'http' && (e.status ?? 500) < 500 && e.status !== 404));
  }
}
