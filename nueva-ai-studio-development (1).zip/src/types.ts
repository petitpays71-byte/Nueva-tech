export type Language = "en" | "fr";

export type Region = "west" | "east" | "north" | "south";
export type Channel = "tiktok" | "facebook" | "whatsapp" | "instagram";
export type Category = "clothing" | "electronics" | "beauty" | "food" | "services" | "other";

export type Tone = "persuasive" | "friendly" | "professional" | "energetic" | "humorous";
export type AdPlatform = "facebook" | "instagram" | "tiktok" | "whatsapp" | "google";
export type Length = "short" | "medium" | "long";
export type SocialPlatform = "tiktok" | "facebook" | "whatsapp";
export type SocialGoal = "awareness" | "sales" | "engagement" | "traffic";
export type VideoStyle = "cinematic" | "ugc" | "motion" | "testimonial" | "product360";
export type Duration = "s15" | "s30" | "s60";
export type Aspect = "r916" | "r11" | "r169";
