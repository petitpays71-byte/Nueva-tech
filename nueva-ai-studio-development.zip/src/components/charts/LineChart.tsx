import { useId, useRef, useState, type PointerEvent } from 'react';
import { ChartTooltip } from './ChartTooltip';
import { monotonePath, niceScale, useTweenedArray, useWidth } from './chartUtils';

export interface LineDatum {
  /** short x-axis label */
  label: string;
  /** long label for the tooltip */
  tip: string;
  value: number;
  prev?: number;
}

interface Props {
  data: LineDatum[];
  height?: number;
  color?: string;
  format: (v: number) => string;
  formatAxis: (v: number) => string;
  currentLabel: string;
  prevLabel: string;
  ariaLabel: string;
}

const M = { t: 14, r: 14, b: 28, l: 50 };

export function LineChart({ data, height = 290, color = '#2f7bff', format, formatAxis, currentLabel, prevLabel, ariaLabel }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const width = useWidth(wrapRef);
  const gid = `lc${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  const [hover, setHover] = useState<number | null>(null);

  const values = data.map((d) => d.value);
  const prevs = data.map((d) => d.prev ?? 0);
  const hasPrev = data.some((d) => d.prev !== undefined);
  const scale = niceScale(Math.max(1, ...values, ...(hasPrev ? prevs : [0])));

  const tv = useTweenedArray(values, { fromZero: true });
  const tp = useTweenedArray(prevs, { fromZero: true });
  const tmax = Math.max(1e-6, useTweenedArray([scale.max])[0]);

  const n = data.length;
  const iw = Math.max(10, width - M.l - M.r);
  const ih = height - M.t - M.b;
  const xAt = (i: number) => M.l + (n <= 1 ? iw / 2 : (i * iw) / (n - 1));
  const yAt = (v: number) => M.t + ih - Math.min(1.02, Math.max(0, v / tmax)) * ih;

  const pts = tv.map((v, i) => ({ x: xAt(i), y: yAt(v) }));
  const ppts = tp.map((v, i) => ({ x: xAt(i), y: yAt(v) }));
  const line = monotonePath(pts);
  const area = n > 1 ? `${line} L ${pts[n - 1].x.toFixed(2)} ${M.t + ih} L ${pts[0].x.toFixed(2)} ${M.t + ih} Z` : '';

  const maxLabels = Math.max(2, Math.floor(iw / 62));
  const labelStep = Math.max(1, Math.ceil(n / maxLabels));

  const onMove = (e: PointerEvent<HTMLDivElement>) => {
    if (!wrapRef.current || n === 0) return;
    const rect = wrapRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const idx = n <= 1 ? 0 : Math.round(((x - M.l) / iw) * (n - 1));
    setHover(Math.min(n - 1, Math.max(0, idx)));
  };

  const hd = hover !== null ? data[hover] : null;
  const delta = hd && hd.prev ? ((hd.value - hd.prev) / hd.prev) * 100 : null;

  return (
    <div
      ref={wrapRef}
      className="relative w-full select-none"
      style={{ height, touchAction: 'pan-y' }}
      onPointerMove={onMove}
      onPointerDown={onMove}
      onPointerLeave={() => setHover(null)}
    >
      {width > 0 && (
        <svg width={width} height={height} role="img" aria-label={ariaLabel} className="block overflow-visible">
          <defs>
            <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity="0.34" />
              <stop offset="100%" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>

          {/* grid + y axis */}
          {Array.from({ length: scale.divisions + 1 }, (_, k) => {
            const v = (tmax * k) / scale.divisions;
            const y = yAt(v);
            return (
              <g key={k}>
                <line x1={M.l} x2={width - M.r} y1={y} y2={y} strokeDasharray={k === 0 ? undefined : '3 5'} style={{ stroke: 'var(--c-line)' }} />
                <text x={M.l - 8} y={y + 3.5} textAnchor="end" fontSize="10.5" style={{ fill: 'var(--c-muted)' }}>
                  {formatAxis(v)}
                </text>
              </g>
            );
          })}

          {/* x axis labels */}
          {data.map((d, i) =>
            i % labelStep === 0 ? (
              <text key={i} x={xAt(i)} y={height - 8} textAnchor={i === 0 && n > 3 ? 'start' : 'middle'} fontSize="10.5" style={{ fill: 'var(--c-muted)' }}>
                {d.label}
              </text>
            ) : null,
          )}

          {/* previous period */}
          {hasPrev && n > 1 && (
            <path d={monotonePath(ppts)} fill="none" strokeWidth="1.75" strokeDasharray="5 5" strokeLinecap="round" style={{ stroke: 'var(--c-muted)', opacity: 0.7 }} />
          )}

          {/* area + line */}
          {area && <path d={area} fill={`url(#${gid})`} />}
          {n > 1 ? (
            <path d={line} fill="none" stroke={color} strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" style={{ filter: `drop-shadow(0 4px 8px ${color}66)` }} />
          ) : null}
          {n === 1 && <circle cx={pts[0].x} cy={pts[0].y} r="5" fill={color} />}

          {/* hover marker */}
          {hover !== null && pts[hover] && (
            <g>
              <line x1={pts[hover].x} x2={pts[hover].x} y1={M.t} y2={M.t + ih} strokeWidth="1.25" style={{ stroke: color, opacity: 0.55 }} />
              {hasPrev && ppts[hover] && <circle cx={ppts[hover].x} cy={ppts[hover].y} r="3.5" style={{ fill: 'var(--c-muted)' }} />}
              <circle cx={pts[hover].x} cy={pts[hover].y} r="9" fill={color} opacity="0.18" />
              <circle cx={pts[hover].x} cy={pts[hover].y} r="4.5" fill={color} strokeWidth="2" style={{ stroke: 'var(--c-surface)' }} />
            </g>
          )}
        </svg>
      )}

      {hd && hover !== null && pts[hover] && (
        <ChartTooltip x={pts[hover].x} y={pts[hover].y} containerWidth={width}>
          <div className="mb-1.5 font-semibold text-ink">{hd.tip}</div>
          <div className="flex items-center justify-between gap-4">
            <span className="flex items-center gap-1.5 text-muted">
              <span className="h-2 w-2 rounded-full" style={{ background: color }} />
              {currentLabel}
            </span>
            <span className="font-bold text-ink tabular-nums">{format(hd.value)}</span>
          </div>
          {hasPrev && (
            <div className="mt-1 flex items-center justify-between gap-4">
              <span className="flex items-center gap-1.5 text-muted">
                <span className="h-0.5 w-2 rounded-full bg-muted" />
                {prevLabel}
              </span>
              <span className="font-semibold text-muted tabular-nums">{format(hd.prev ?? 0)}</span>
            </div>
          )}
          {delta !== null && (
            <div className={`mt-1.5 text-right font-bold tabular-nums ${delta >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
              {delta >= 0 ? '▲' : '▼'} {Math.abs(delta).toFixed(1)}%
            </div>
          )}
        </ChartTooltip>
      )}
    </div>
  );
}
