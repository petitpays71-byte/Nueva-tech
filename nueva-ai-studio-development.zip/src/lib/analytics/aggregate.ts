import type { Filters, MetricId, Row } from '../../types';

export interface Totals {
  count: number;
  impressions: number;
  clicks: number;
  conversions: number;
  revenue: number;
  ctr: number;
}

export function sumRows(rows: Row[]): Totals {
  let impressions = 0;
  let clicks = 0;
  let conversions = 0;
  let revenue = 0;
  for (const r of rows) {
    impressions += r.impressions;
    clicks += r.clicks;
    conversions += r.conversions;
    revenue += r.revenue;
  }
  return { count: rows.length, impressions, clicks, conversions, revenue, ctr: impressions ? clicks / impressions : 0 };
}

interface FilterOpts {
  /** ignore one segment dimension (used by cross-filter charts) */
  skip?: 'type' | 'market' | 'platform';
  from?: number;
  to?: number;
}

export function applyFilters(rows: Row[], f: Filters, opts: FilterOpts = {}): Row[] {
  const from = opts.from ?? f.from;
  const to = opts.to ?? f.to;
  return rows.filter(
    (r) =>
      r.day >= from &&
      r.day <= to &&
      (opts.skip === 'type' || f.type === 'all' || r.type === f.type) &&
      (opts.skip === 'market' || f.market === 'all' || r.market === f.market) &&
      (opts.skip === 'platform' || f.platform === 'all' || r.platform === f.platform),
  );
}

export function metricOfRow(r: Row, m: MetricId): number {
  switch (m) {
    case 'generated':
      return 1;
    case 'reach':
      return r.impressions;
    case 'clicks':
      return r.clicks;
    case 'conversions':
      return r.conversions;
    case 'revenue':
      return r.revenue;
  }
}

export function metricOfTotals(t: Totals, m: MetricId): number {
  switch (m) {
    case 'generated':
      return t.count;
    case 'reach':
      return t.impressions;
    case 'clicks':
      return t.clicks;
    case 'conversions':
      return t.conversions;
    case 'revenue':
      return t.revenue;
  }
}

export function pctChange(cur: number, prev: number): number | null {
  if (!prev) return null;
  return ((cur - prev) / prev) * 100;
}

/** Bucket size in days for a given range length (daily → weekly → monthly). */
export function bucketSizeFor(days: number): 1 | 7 | 30 {
  if (days <= 31) return 1;
  if (days <= 140) return 7;
  return 30;
}

export function bucketCount(from: number, to: number, size: number): number {
  return Math.max(1, Math.ceil((to - from + 1) / size));
}

/** Sum of a metric per bucket, aligned to `from`. */
export function seriesFor(rows: Row[], from: number, to: number, size: number, metric: MetricId): number[] {
  const out = new Array<number>(bucketCount(from, to, size)).fill(0);
  for (const r of rows) {
    if (r.day < from || r.day > to) continue;
    out[Math.floor((r.day - from) / size)] += metricOfRow(r, metric);
  }
  return out;
}

export function ctrSeries(rows: Row[], from: number, to: number, size: number): number[] {
  const n = bucketCount(from, to, size);
  const imp = new Array<number>(n).fill(0);
  const clk = new Array<number>(n).fill(0);
  for (const r of rows) {
    if (r.day < from || r.day > to) continue;
    const i = Math.floor((r.day - from) / size);
    imp[i] += r.impressions;
    clk[i] += r.clicks;
  }
  return imp.map((v, i) => (v ? clk[i] / v : 0));
}
