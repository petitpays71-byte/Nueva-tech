import type { Filters } from '../../types';

export function defaultFilters(today: number): Filters {
  return { preset: '30', from: today - 29, to: today, type: 'all', market: 'all', platform: 'all' };
}

export function activeFilterCount(f: Filters): number {
  return [f.type, f.market, f.platform].filter((x) => x !== 'all').length + (f.preset !== '30' ? 1 : 0);
}
