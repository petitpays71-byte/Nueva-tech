import { CalendarDays, RotateCcw, SlidersHorizontal } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import type { ContentType, Filters, MarketId, PlatformId, PresetId } from '../../types';
import type { TKey } from '../../i18n/translations';
import { CONTENT_TYPES, MARKETS, PLATFORMS, TYPE_COLORS } from '../../lib/markets';
import { dayToISO, isoToDay } from '../../lib/format';
import { activeFilterCount, defaultFilters } from '../../lib/analytics/filters';
import { cn } from '../../utils/cn';

interface Props {
  filters: Filters;
  onChange: (f: Filters) => void;
  today: number;
  dataStart: number;
}

const PRESETS: { id: PresetId; key: TKey; days?: number }[] = [
  { id: '7', key: 'f.d7', days: 7 },
  { id: '30', key: 'f.d30', days: 30 },
  { id: '90', key: 'f.d90', days: 90 },
  { id: '180', key: 'f.d180', days: 180 },
  { id: 'custom', key: 'f.custom' },
];

export function FilterBar({ filters, onChange, today, dataStart }: Props) {
  const { t, lang } = useApp();
  const active = activeFilterCount(filters);

  const setPreset = (id: PresetId, days?: number) => {
    if (!days) return onChange({ ...filters, preset: 'custom' });
    onChange({ ...filters, preset: id, from: today - days + 1, to: today });
  };

  const setFrom = (iso: string) => {
    if (!iso) return;
    const d = Math.min(today, Math.max(dataStart, isoToDay(iso)));
    onChange({ ...filters, preset: 'custom', from: d, to: Math.max(d, filters.to) });
  };
  const setTo = (iso: string) => {
    if (!iso) return;
    const d = Math.min(today, Math.max(dataStart, isoToDay(iso)));
    onChange({ ...filters, preset: 'custom', to: d, from: Math.min(d, filters.from) });
  };

  return (
    <section className="card relative z-20 space-y-3 p-3 sm:p-4" aria-label={t('f.title')}>
      <div className="flex flex-col gap-3 xl:flex-row xl:items-end xl:justify-between">
        {/* date range */}
        <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
          <div>
            <span className="label flex items-center gap-1.5">
              <CalendarDays size={13} /> {t('f.range')}
            </span>
            <div role="group" className="flex rounded-xl border border-line bg-surface2 p-0.5">
              {PRESETS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  aria-pressed={filters.preset === p.id}
                  onClick={() => setPreset(p.id, p.days)}
                  className={cn(
                    'min-w-0 flex-1 cursor-pointer rounded-[10px] px-3 py-1.5 text-xs font-bold whitespace-nowrap transition sm:flex-none',
                    filters.preset === p.id ? 'bg-brand text-white shadow' : 'text-muted hover:text-ink',
                  )}
                >
                  {t(p.key)}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <label>
              <span className="label">{t('f.from')}</span>
              <input
                type="date"
                className="input !py-1.5 text-xs"
                value={dayToISO(filters.from)}
                min={dayToISO(dataStart)}
                max={dayToISO(today)}
                onChange={(e) => setFrom(e.target.value)}
              />
            </label>
            <label>
              <span className="label">{t('f.to')}</span>
              <input
                type="date"
                className="input !py-1.5 text-xs"
                value={dayToISO(filters.to)}
                min={dayToISO(dataStart)}
                max={dayToISO(today)}
                onChange={(e) => setTo(e.target.value)}
              />
            </label>
          </div>
        </div>

        {/* segments */}
        <div className="flex min-w-0 flex-col gap-2 sm:flex-row sm:items-end">
          <div className="min-w-0">
            <span className="label">{t('f.segment')}</span>
            <div className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-0.5">
              <button type="button" className="chip" data-active={filters.type === 'all'} onClick={() => onChange({ ...filters, type: 'all' })}>
                {t('common.all')}
              </button>
              {CONTENT_TYPES.map((c: ContentType) => (
                <button
                  key={c}
                  type="button"
                  className="chip"
                  data-active={filters.type === c}
                  onClick={() => onChange({ ...filters, type: filters.type === c ? 'all' : c })}
                >
                  <span className="h-2 w-2 rounded-full" style={{ background: TYPE_COLORS[c] }} />
                  {t(`type.${c}Short` as TKey)}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 sm:flex">
            <label className="min-w-0">
              <span className="label">{t('f.market')}</span>
              <select
                className="input !py-1.5 text-xs sm:w-40"
                value={filters.market}
                onChange={(e) => onChange({ ...filters, market: e.target.value as MarketId | 'all' })}
              >
                <option value="all">{t('f.allMarkets')}</option>
                {MARKETS.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name[lang]}
                  </option>
                ))}
              </select>
            </label>
            <label className="min-w-0">
              <span className="label">{t('f.platform')}</span>
              <select
                className="input !py-1.5 text-xs sm:w-36"
                value={filters.platform}
                onChange={(e) => onChange({ ...filters, platform: e.target.value as PlatformId | 'all' })}
              >
                <option value="all">{t('f.allPlatforms')}</option>
                {PLATFORMS.map((p) => (
                  <option key={p} value={p}>
                    {t(`p.${p}` as TKey)}
                  </option>
                ))}
              </select>
            </label>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 border-t border-line pt-2.5 text-xs text-muted">
        <span className="flex items-center gap-1.5 font-medium">
          <SlidersHorizontal size={13} />
          {active > 0 ? t('f.active', { n: active }) : t('f.title')}
        </span>
        <button type="button" className="btn btn-ghost btn-sm" disabled={active === 0} onClick={() => onChange(defaultFilters(today))}>
          <RotateCcw size={13} /> {t('f.reset')}
        </button>
      </div>
    </section>
  );
}
