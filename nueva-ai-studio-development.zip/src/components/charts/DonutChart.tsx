import { useEffect, useRef, useState, type PointerEvent } from 'react';
import { ChartTooltip } from './ChartTooltip';
import { cn } from '../../utils/cn';

export interface DonutSegment {
  key: string;
  label: string;
  value: number;
  color: string;
}

interface Props {
  segments: DonutSegment[];
  selectedKey?: string | null;
  onSelect?: (key: string) => void;
  format: (v: number) => string;
  centerLabel: string;
  centerValue: string;
  shareLabel: string;
  emptyLabel: string;
  ariaLabel: string;
}

const R = 70;
const C = 2 * Math.PI * R;
const GAP = 3;

export function DonutChart({ segments, selectedKey, onSelect, format, centerLabel, centerValue, shareLabel, emptyLabel, ariaLabel }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  const [hover, setHover] = useState<string | null>(null);
  const [tip, setTip] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    const id = requestAnimationFrame(() => setReady(true));
    return () => cancelAnimationFrame(id);
  }, []);

  const total = segments.reduce((s, x) => s + x.value, 0);
  const active = segments.find((s) => s.key === hover) ?? (selectedKey && selectedKey !== 'all' ? segments.find((s) => s.key === selectedKey) : undefined);
  const visibleCount = segments.filter((s) => s.value > 0).length;

  let acc = 0;
  const arcs = segments.map((s) => {
    const frac = total ? s.value / total : 0;
    const len = frac * C;
    const dash = visibleCount > 1 ? Math.max(0, len - GAP) : len;
    const offset = -acc * C;
    acc += frac;
    return { ...s, frac, dash, offset };
  });

  const onMove = (e: PointerEvent, key: string) => {
    const rect = wrapRef.current?.getBoundingClientRect();
    if (!rect) return;
    setHover(key);
    setTip({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };

  const hovered = segments.find((s) => s.key === hover);

  return (
    <div className="flex flex-col items-center gap-5 sm:flex-row xl:flex-col">
      <div ref={wrapRef} className="relative h-[190px] w-[190px] shrink-0" onPointerLeave={() => { setHover(null); setTip(null); }}>
        <svg viewBox="0 0 200 200" className="h-full w-full -rotate-90" role="img" aria-label={ariaLabel}>
          <circle cx="100" cy="100" r={R} fill="none" strokeWidth="22" style={{ stroke: 'var(--c-surface2)' }} />
          {total > 0 &&
            arcs.map((a) => {
              const isSel = selectedKey && selectedKey !== 'all' ? selectedKey === a.key : null;
              const isHover = hover === a.key;
              const dim = isSel === false ? 0.3 : hover && !isHover ? 0.55 : 1;
              return (
                <circle
                  key={a.key}
                  cx="100"
                  cy="100"
                  r={R}
                  fill="none"
                  stroke={a.color}
                  strokeWidth={isHover || isSel ? 28 : 22}
                  strokeDasharray={`${ready ? a.dash : 0} ${C}`}
                  strokeDashoffset={a.offset}
                  opacity={dim}
                  tabIndex={0}
                  role="button"
                  aria-label={`${a.label}: ${format(a.value)}`}
                  onClick={() => onSelect?.(a.key)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      onSelect?.(a.key);
                    }
                  }}
                  onPointerEnter={(e) => onMove(e, a.key)}
                  onPointerMove={(e) => onMove(e, a.key)}
                  onFocus={() => setHover(a.key)}
                  onBlur={() => setHover(null)}
                  style={{
                    transition: 'stroke-dasharray .8s cubic-bezier(.2,.8,.2,1), stroke-dashoffset .8s cubic-bezier(.2,.8,.2,1), stroke-width .2s ease, opacity .2s ease',
                    cursor: onSelect ? 'pointer' : 'default',
                    outline: 'none',
                    filter: isHover || isSel ? `drop-shadow(0 0 6px ${a.color}99)` : undefined,
                  }}
                />
              );
            })}
        </svg>

        <div className="pointer-events-none absolute inset-0 grid place-items-center text-center">
          {total === 0 ? (
            <div className="px-10 text-xs font-medium text-muted">{emptyLabel}</div>
          ) : active ? (
            <div className="px-8">
              <div className="truncate text-[11px] font-semibold text-muted">{active.label}</div>
              <div className="font-display text-2xl font-bold text-ink tabular-nums">{Math.round((active.value / total) * 100)}%</div>
              <div className="text-[11px] font-medium text-muted tabular-nums">{format(active.value)}</div>
            </div>
          ) : (
            <div>
              <div className="text-[11px] font-semibold tracking-wide text-muted uppercase">{centerLabel}</div>
              <div className="font-display text-2xl font-bold text-ink tabular-nums">{centerValue}</div>
            </div>
          )}
        </div>

        {hovered && tip && (
          <ChartTooltip x={tip.x} y={tip.y} containerWidth={190}>
            <div className="mb-1 flex items-center gap-1.5 font-semibold text-ink">
              <span className="h-2 w-2 rounded-full" style={{ background: hovered.color }} />
              {hovered.label}
            </div>
            <div className="flex items-center justify-between gap-4">
              <span className="text-muted">{shareLabel}</span>
              <span className="font-semibold text-muted tabular-nums">{total ? Math.round((hovered.value / total) * 100) : 0}%</span>
            </div>
            <div className="mt-0.5 text-right text-sm font-bold text-ink tabular-nums">{format(hovered.value)}</div>
          </ChartTooltip>
        )}
      </div>

      <ul className="w-full min-w-0 flex-1 space-y-1">
        {segments.map((s) => {
          const isSel = selectedKey === s.key;
          return (
            <li key={s.key}>
              <button
                type="button"
                onClick={() => onSelect?.(s.key)}
                onPointerEnter={() => setHover(s.key)}
                onPointerLeave={() => setHover(null)}
                aria-pressed={isSel}
                className={cn(
                  'flex w-full cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-left text-sm transition',
                  isSel ? 'bg-brand/12 ring-1 ring-brand/40' : 'hover:bg-surface2',
                )}
              >
                <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: s.color }} />
                <span className="min-w-0 flex-1 truncate font-medium text-ink">{s.label}</span>
                <span className="text-xs font-semibold text-muted tabular-nums">{total ? Math.round((s.value / total) * 100) : 0}%</span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
