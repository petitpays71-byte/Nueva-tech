import { useI18n } from "../i18n";
import { Badge } from "./ui";
import { Icon } from "./Icon";
import { AdTextGenerator } from "./generators/AdTextGenerator";
import { VideoPromptGenerator } from "./generators/VideoPromptGenerator";
import { ProductDescriptionGenerator } from "./generators/ProductDescriptionGenerator";
import { SocialContentGenerator } from "./generators/SocialContentGenerator";

export function StudioView() {
  const { t } = useI18n();
  return (
    <div className="space-y-6">
      <section className="card relative overflow-hidden p-6 sm:p-8">
        <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-electric-500/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -left-24 h-64 w-64 rounded-full bg-indigo-500/20 blur-3xl" />
        <div className="relative">
          <Badge tone="electric">
            <Icon name="info" className="h-3 w-3" />
            {t("header.demoBadge")}
          </Badge>
          <h1 className="mt-3 text-2xl font-extrabold tracking-tight sm:text-4xl">
            {t("studio.title")} <span className="text-gradient">✦</span>
          </h1>
          <p className="mt-2 max-w-2xl text-sm text-slate-600 dark:text-slate-300 sm:text-base">
            {t("studio.subtitle")}
          </p>
        </div>
      </section>
      <div className="grid gap-4 lg:grid-cols-2">
        <AdTextGenerator />
        <VideoPromptGenerator />
        <ProductDescriptionGenerator />
        <SocialContentGenerator />
      </div>
    </div>
  );
}
