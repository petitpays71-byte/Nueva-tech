import { useEffect, useMemo, useState } from "react";
import { useI18n } from "../i18n";
import { useToast } from "./Toast";
import { cn } from "../utils/cn";
import { formatDateTime } from "../utils/format";
import {
  HISTORY_EVENT,
  clearHistory,
  loadHistory,
  removeHistoryEntry,
  type HistoryEntry,
  type HistoryType,
} from "../utils/history";
import { Badge, Button, Card, CopyButton, Field, Select, inputClass } from "./ui";
import { Icon } from "./Icon";

const TYPE_ICONS: Record<HistoryType, string> = {
  adText: "megaphone",
  video: "video",
  product: "package",
  social: "share",
};

const TYPE_TONES: Record<HistoryType, "electric" | "amber" | "success" | "slate"> = {
  adText: "electric",
  video: "amber",
  product: "success",
  social: "slate",
};

const ALL_TYPES: HistoryType[] = ["adText", "video", "product", "social"];

export function HistoryPanel() {
  const { t, locale } = useI18n();
  const { toast } = useToast();
  const [entries, setEntries] = useState<HistoryEntry[]>(() => loadHistory());
  const [typeFilter, setTypeFilter] = useState<HistoryType | "all">("all");
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  useEffect(() => {
    const handler = () => setEntries(loadHistory());
    window.addEventListener(HISTORY_EVENT, handler);
    return () => window.removeEventListener(HISTORY_EVENT, handler);
  }, []);

  const filtered = useMemo(
    () =>
      entries.filter((e) => {
        if (typeFilter !== "all" && e.type !== typeFilter) return false;
        if (query.trim()) {
          const q = query.trim().toLowerCase();
          return `${e.title} ${e.content}`.toLowerCase().includes(q);
        }
        return true;
      }),
    [entries, typeFilter, query]
  );

  const handleDelete = (id: string) => {
    removeHistoryEntry(id);
    setEntries(loadHistory());
    window.dispatchEvent(new Event(HISTORY_EVENT));
    toast(t("toast.deleted"), "info");
  };

  const handleClear = () => {
    if (window.confirm(t("history.confirmClear"))) {
      clearHistory();
      setEntries([]);
      window.dispatchEvent(new Event(HISTORY_EVENT));
      toast(t("toast.cleared"), "info");
    }
  };

  const toggleExpanded = (id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const typeOptions = [
    { value: "all", label: t("common.all") },
    ...ALL_TYPES.map((k) => ({ value: k, label: t(`history.types.${k}`) })),
  ];

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{t("history.title")}</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{t("history.subtitle")}</p>
      </div>

      <Card className="p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <Select
            label={t("history.filterByType")}
            value={typeFilter}
            onChange={(v) => setTypeFilter(v as HistoryType | "all")}
            options={typeOptions}
            className="sm:w-56"
          />
          <Field label={t("common.search")} className="flex-1">
            <div className="relative">
              <Icon
                name="search"
                className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
              />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t("history.searchPh")}
                className={cn(inputClass, "pl-9")}
              />
            </div>
          </Field>
          {entries.length > 0 && (
            <Button variant="danger" onClick={handleClear}>
              <Icon name="trash" className="h-4 w-4" />
              {t("history.clearAll")}
            </Button>
          )}
        </div>
      </Card>

      {filtered.length === 0 ? (
        <Card className="flex flex-col items-center justify-center gap-3 p-10 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-electric-500/10 text-electric-500">
            <Icon name="clock" className="h-7 w-7" />
          </span>
          <p className="text-sm text-slate-500 dark:text-slate-400">{t("history.empty")}</p>
        </Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {filtered.map((e) => {
            const isOpen = expanded.has(e.id);
            return (
              <Card key={e.id} className="flex animate-fade-up flex-col p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-electric-500/10 text-electric-500">
                      <Icon name={TYPE_ICONS[e.type]} className="h-4 w-4" />
                    </span>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold">{e.title}</p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {formatDateTime(e.createdAt, locale)} · {e.language.toUpperCase()}
                      </p>
                    </div>
                  </div>
                  <div className="flex shrink-0 gap-1.5">
                    <CopyButton text={e.content} />
                    <button
                      type="button"
                      onClick={() => handleDelete(e.id)}
                      aria-label={t("history.delete")}
                      className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition hover:bg-rose-500/10 hover:text-rose-500"
                    >
                      <Icon name="trash" className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => toggleExpanded(e.id)}
                  className="mt-2 flex-1 text-left"
                >
                  <p
                    className={cn(
                      "whitespace-pre-wrap text-sm leading-relaxed text-slate-600 dark:text-slate-300",
                      !isOpen && "line-clamp-3"
                    )}
                  >
                    {e.content}
                  </p>
                </button>
                <div className="mt-2">
                  <Badge tone={TYPE_TONES[e.type]}>{t(`history.types.${e.type}`)}</Badge>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
