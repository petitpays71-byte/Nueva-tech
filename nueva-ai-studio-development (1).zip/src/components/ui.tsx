import { useState, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { copyText } from "../utils/clipboard";
import { useI18n } from "../i18n";
import { useToast } from "./Toast";
import { Icon } from "./Icon";

export const inputClass =
  "w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder-slate-400 transition focus:border-electric-400 focus:outline-none focus:ring-2 focus:ring-electric-400/30 dark:border-navy-700 dark:bg-navy-900 dark:text-slate-100 dark:placeholder-slate-500";

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("card p-4 sm:p-5", className)}>{children}</div>;
}

export function Field({
  label,
  children,
  className,
}: {
  label: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cn("block", className)}>
      <span className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-slate-500 dark:text-slate-400">
        {label}
      </span>
      {children}
    </label>
  );
}

export function TextInput({
  value,
  onChange,
  placeholder,
  className,
}: {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  className?: string;
}) {
  return (
    <input
      type="text"
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      className={cn(inputClass, className)}
    />
  );
}

export function Textarea({
  value,
  onChange,
  placeholder,
  rows = 3,
  className,
}: {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  placeholder?: string;
  rows?: number;
  className?: string;
}) {
  return (
    <textarea
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      rows={rows}
      className={cn(inputClass, "resize-y", className)}
    />
  );
}

const CHEVRON_BG =
  "bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2716%27 height=%2716%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%2364748b%27 stroke-width=%272%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27%3E%3Cpolyline points=%276 9 12 15 18 9%27/%3E%3C/svg%3E')] bg-[right_0.75rem_center] bg-no-repeat pr-9";

export function Select({
  label,
  value,
  onChange,
  options,
  className,
}: {
  label?: string;
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string }[];
  className?: string;
}) {
  return (
    <label className={cn("block", className)}>
      {label && (
        <span className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-slate-500 dark:text-slate-400">
          {label}
        </span>
      )}
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={cn(inputClass, "appearance-none", CHEVRON_BG)}
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}

export function Button({
  children,
  onClick,
  loading = false,
  variant = "primary",
  className,
  type = "button",
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  loading?: boolean;
  variant?: "primary" | "ghost" | "danger";
  className?: string;
  type?: "button" | "submit";
  disabled?: boolean;
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled || loading}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-60",
        variant === "primary" &&
          "bg-gradient-to-r from-electric-500 to-blue-600 text-white shadow-lg shadow-electric-500/25 hover:from-electric-400 hover:to-blue-500",
        variant === "ghost" &&
          "border border-slate-300 text-slate-700 hover:bg-slate-100 dark:border-navy-700 dark:text-slate-200 dark:hover:bg-navy-800",
        variant === "danger" &&
          "border border-rose-400/50 text-rose-500 hover:bg-rose-500/10",
        className
      )}
    >
      {loading && <Spinner />}
      {children}
    </button>
  );
}

export function Spinner({ className }: { className?: string }) {
  return (
    <span
      className={cn("h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white", className)}
      aria-hidden="true"
    />
  );
}

const BADGE_TONES = {
  electric: "border-electric-400/40 bg-electric-500/10 text-electric-600 dark:text-electric-300",
  success: "border-emerald-400/40 bg-emerald-500/10 text-emerald-600 dark:text-emerald-300",
  amber: "border-amber-400/40 bg-amber-500/10 text-amber-600 dark:text-amber-300",
  slate: "border-slate-400/40 bg-slate-500/10 text-slate-600 dark:text-slate-300",
  rose: "border-rose-400/40 bg-rose-500/10 text-rose-600 dark:text-rose-300",
} as const;

export function Badge({
  children,
  tone = "electric",
  className,
}: {
  children: ReactNode;
  tone?: keyof typeof BADGE_TONES;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-[11px] font-semibold",
        BADGE_TONES[tone],
        className
      )}
    >
      {children}
    </span>
  );
}

export function SegmentedControl({
  options,
  value,
  onChange,
  className,
  ariaLabel,
}: {
  options: { value: string; label: string }[];
  value: string;
  onChange: (value: string) => void;
  className?: string;
  ariaLabel?: string;
}) {
  return (
    <div
      role="group"
      aria-label={ariaLabel}
      className={cn(
        "inline-flex flex-wrap gap-1 rounded-xl border border-slate-300 bg-slate-100 p-1 dark:border-navy-700 dark:bg-navy-900",
        className
      )}
    >
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cn(
            "rounded-lg px-3 py-1.5 text-xs font-semibold transition sm:text-sm",
            value === o.value
              ? "bg-white text-electric-600 shadow dark:bg-electric-500 dark:text-white"
              : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function CopyButton({
  text,
  label,
  className,
}: {
  text: string;
  label?: string;
  className?: string;
}) {
  const { t } = useI18n();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const handle = async () => {
    const ok = await copyText(text);
    if (ok) {
      setCopied(true);
      toast(t("toast.copied"));
      setTimeout(() => setCopied(false), 1600);
    } else {
      toast(t("toast.copyFailed"), "error");
    }
  };

  return (
    <button
      type="button"
      onClick={handle}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs font-medium text-slate-600 transition hover:border-electric-400 hover:text-electric-500 dark:border-navy-700 dark:text-slate-300 dark:hover:border-electric-400",
        className
      )}
    >
      {copied ? (
        <Icon name="check" className="h-3.5 w-3.5 text-emerald-500" />
      ) : (
        <Icon name="copy" className="h-3.5 w-3.5" />
      )}
      {label ?? (copied ? t("common.copied") : t("common.copy"))}
    </button>
  );
}

export function GeneratorCard({
  icon,
  title,
  desc,
  children,
}: {
  icon: string;
  title: string;
  desc: string;
  children: ReactNode;
}) {
  return (
    <Card className="flex h-full flex-col">
      <div className="mb-4 flex items-start gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-electric-500/15 text-electric-500 dark:text-electric-300">
          <Icon name={icon} className="h-5 w-5" />
        </span>
        <div>
          <h3 className="font-semibold leading-tight">{title}</h3>
          <p className="mt-0.5 text-sm text-slate-500 dark:text-slate-400">{desc}</p>
        </div>
      </div>
      {children}
    </Card>
  );
}

export function GeneratorResult({
  title,
  result,
  loading,
  onRegenerate,
}: {
  title: string;
  result: string | null;
  loading: boolean;
  onRegenerate: () => void;
}) {
  const { t } = useI18n();

  if (loading) {
    return (
      <div className="mt-4 space-y-2" aria-live="polite">
        <div className="skeleton h-4 w-3/4" />
        <div className="skeleton h-4 w-full" />
        <div className="skeleton h-4 w-5/6" />
        <div className="skeleton h-4 w-2/3" />
        <p className="animate-pulse-soft text-xs font-medium text-electric-500">
          {t("common.generating")}
        </p>
      </div>
    );
  }

  if (!result) return null;

  return (
    <div className="mt-4 animate-fade-up rounded-xl border border-electric-400/30 bg-gradient-to-b from-electric-500/10 to-transparent p-4">
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="text-xs font-semibold uppercase tracking-wider text-electric-600 dark:text-electric-300">
          {title}
        </p>
        <div className="flex shrink-0 gap-1.5">
          <button
            type="button"
            onClick={onRegenerate}
            aria-label={t("common.regenerate")}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 transition hover:bg-electric-500/10 hover:text-electric-500 dark:text-slate-400"
          >
            <Icon name="refresh" className="h-4 w-4" />
          </button>
          <CopyButton text={result} />
        </div>
      </div>
      <p className="whitespace-pre-wrap text-sm leading-relaxed">{result}</p>
    </div>
  );
}
