import type { LucideIcon } from 'lucide-react';
import { Minus, TrendingDown, TrendingUp } from 'lucide-react';
import { Sparkline } from '../charts/Sparkline';
import { useTweenedNumber } from '../charts/chartUtils';
import { fmtSigned } from '../../lib/format';
import { useApp } from '../../context/AppContext';
import { cn } from '../../utils/cn';

interface Props {
  icon: LucideIcon;
  label: string;
  value: number;
  format: (v: number) => string;
  trend: number | null;
  spark: number[];
  color: string;
}

export function KpiCard({ icon: Icon, label, value, format, trend, spark, color }: Props) {
  const { t, lang } = useApp();
  const animated = useTweenedNumber(value, { fromZero: true, duration: 800 });
  const up = trend !== null && trend >= 0;

  return (
    <div className="card group relative overflow-hidden p-4 transition hover:-translate-y-0.5 hover:border-brand/40 sm:p-5">
      <div
        className="pointer-events-none absolute -top-10 -right-10 h-28 w-28 rounded-full opacity-20 blur-2xl transition group-hover:opacity-40"
        style={{ background: color }}
      />
      <div className="relative flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-2 text-xs font-semibold text-muted">
            <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg" style={{ background: `${color}22`, color }}>
              <Icon size={15} />
            </span>
            <span className="truncate">{label}</span>
          </div>
          <div className="font-display mt-3 truncate text-[26px] leading-none font-bold tracking-tight text-ink tabular-nums sm:text-3xl">{format(animated)}</div>
        </div>
        <div
          title={trend === null ? t('kpi.noPrev') : t('kpi.vsPrev')}
          className={cn(
            'flex shrink-0 items-center gap-1 rounded-full px-2 py-1 text-[11px] font-bold tabular-nums',
            trend === null ? 'bg-surface2 text-muted' : up ? 'bg-emerald-500/12 text-emerald-500' : 'bg-rose-500/12 text-rose-500',
          )}
        >
          {trend === null ? <Minus size={12} /> : up ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
          {trend === null ? '—' : fmtSigned(trend, lang)}
        </div>
      </div>
      <div className="relative mt-3">
        <Sparkline values={spark} color={color} />
      </div>
      <div className="relative mt-1.5 text-[11px] font-medium text-muted">{t('kpi.vsPrev')}</div>
    </div>
  );
}
