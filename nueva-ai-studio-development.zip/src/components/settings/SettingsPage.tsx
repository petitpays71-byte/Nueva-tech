import { useState, type ReactNode } from 'react';
import { CheckCircle2, Loader2, Moon, PlugZap, ShieldCheck, Sun, Trash2, XCircle, Database, Languages } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { testEndpoint } from '../../lib/generators';
import { ModeBadge } from '../ui/ModeBadge';
import { cn } from '../../utils/cn';

function Block({ icon, title, children }: { icon: ReactNode; title: string; children: ReactNode }) {
  return (
    <section className="card p-4 sm:p-5">
      <h3 className="font-display mb-3 flex items-center gap-2.5 text-base font-bold text-ink">
        <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand/12 text-brand">{icon}</span>
        {title}
      </h3>
      {children}
    </section>
  );
}

const isHttpUrl = (u: string) => {
  try {
    const x = new URL(u);
    return x.protocol === 'http:' || x.protocol === 'https:';
  } catch {
    return false;
  }
};

export function SettingsPage() {
  const { t, lang, setLang, theme, setTheme, settings, setSettings, notify, eraseAll, aiConfigured } = useApp();
  const [url, setUrl] = useState(settings.proxyUrl);
  const [error, setError] = useState('');
  const [test, setTest] = useState<'idle' | 'loading' | 'ok' | 'fail'>('idle');
  const [confirm, setConfirm] = useState(false);

  const save = () => {
    const v = url.trim();
    if (!v) {
      setSettings({ proxyUrl: '' });
      setError('');
      setTest('idle');
      notify(t('set.removed'), 'info');
      return;
    }
    if (!isHttpUrl(v)) {
      setError(t('set.invalidUrl'));
      return;
    }
    setError('');
    setSettings({ proxyUrl: v });
    notify(t('set.saved'));
  };

  const remove = () => {
    setUrl('');
    setSettings({ proxyUrl: '' });
    setError('');
    setTest('idle');
    notify(t('set.removed'), 'info');
  };

  const runTest = async () => {
    const v = url.trim();
    if (!isHttpUrl(v)) {
      setError(t('set.invalidUrl'));
      return;
    }
    setError('');
    setTest('loading');
    setTest((await testEndpoint(v)) ? 'ok' : 'fail');
  };

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <div>
        <h2 className="font-display text-xl font-bold tracking-tight text-ink sm:text-2xl">{t('set.title')}</h2>
        <p className="mt-1 text-sm text-muted">{t('set.subtitle')}</p>
      </div>

      <Block icon={<Languages size={17} />} title={t('set.appearance')}>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <span className="label">{t('set.language')}</span>
            <div className="flex rounded-xl border border-line bg-surface2 p-0.5">
              {(['fr', 'en'] as const).map((l) => (
                <button
                  key={l}
                  type="button"
                  onClick={() => setLang(l)}
                  aria-pressed={lang === l}
                  className={cn('flex-1 cursor-pointer rounded-[10px] px-3 py-2 text-sm font-semibold transition', lang === l ? 'bg-brand text-white shadow' : 'text-muted hover:text-ink')}
                >
                  {l === 'fr' ? 'Français' : 'English'}
                </button>
              ))}
            </div>
          </div>
          <div>
            <span className="label">{t('set.theme')}</span>
            <div className="flex rounded-xl border border-line bg-surface2 p-0.5">
              {(['dark', 'light'] as const).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setTheme(m)}
                  aria-pressed={theme === m}
                  className={cn(
                    'flex flex-1 cursor-pointer items-center justify-center gap-2 rounded-[10px] px-3 py-2 text-sm font-semibold transition',
                    theme === m ? 'bg-brand text-white shadow' : 'text-muted hover:text-ink',
                  )}
                >
                  {m === 'dark' ? <Moon size={15} /> : <Sun size={15} />}
                  {m === 'dark' ? t('set.dark') : t('set.light')}
                </button>
              ))}
            </div>
          </div>
        </div>
      </Block>

      <Block icon={<PlugZap size={17} />} title={t('set.ai')}>
        <div className="mb-3 flex flex-wrap items-center gap-2 text-sm text-muted">
          <span className="font-semibold text-ink">{t('set.status')}:</span>
          <ModeBadge onClick={() => undefined} />
        </div>
        <p className="mb-4 text-sm leading-relaxed text-muted">{t('set.aiBody')}</p>

        <label htmlFor="proxy-url" className="label">
          {t('set.endpoint')}
        </label>
        <input
          id="proxy-url"
          className="input"
          type="url"
          inputMode="url"
          value={url}
          placeholder={t('set.endpointPlaceholder')}
          aria-invalid={error ? true : undefined}
          onChange={(e) => {
            setUrl(e.target.value);
            setError('');
            setTest('idle');
          }}
        />
        {error && <p className="mt-1.5 text-xs font-medium text-rose-500">{error}</p>}

        <div className="mt-3 flex flex-wrap gap-2">
          <button type="button" className="btn btn-primary btn-sm" onClick={save}>
            {t('set.save')}
          </button>
          <button type="button" className="btn btn-ghost btn-sm" onClick={runTest} disabled={test === 'loading' || !url.trim()}>
            {test === 'loading' ? <Loader2 size={14} className="animate-spin" /> : <PlugZap size={14} />}
            {test === 'loading' ? t('set.testing') : t('set.test')}
          </button>
          {aiConfigured && settings.proxyUrl && (
            <button type="button" className="btn btn-ghost btn-sm" onClick={remove}>
              {t('set.remove')}
            </button>
          )}
        </div>

        {test === 'ok' && (
          <p className="mt-3 flex items-center gap-2 text-sm font-semibold text-emerald-500">
            <CheckCircle2 size={16} /> {t('set.testOk')}
          </p>
        )}
        {test === 'fail' && (
          <p className="mt-3 flex items-start gap-2 text-sm font-semibold text-rose-500">
            <XCircle size={16} className="mt-0.5 shrink-0" /> {t('set.testFail')}
          </p>
        )}

        <div className="mt-5 rounded-xl border border-line bg-surface2/70 p-3.5">
          <div className="mb-1.5 text-xs font-bold tracking-wide text-ink uppercase">{t('set.contract')}</div>
          <p className="text-xs leading-relaxed text-muted">{t('set.contractBody')}</p>
        </div>
      </Block>

      <Block icon={<ShieldCheck size={17} />} title={t('set.security')}>
        <p className="text-sm leading-relaxed text-muted">{t('set.securityBody')}</p>
      </Block>

      <Block icon={<Database size={17} />} title={t('set.data')}>
        <p className="mb-4 text-sm leading-relaxed text-muted">{t('set.dataBody')}</p>
        {confirm ? (
          <div className="flex flex-wrap items-center gap-2 rounded-xl border border-rose-500/40 bg-rose-500/10 p-2.5">
            <span className="text-sm font-semibold text-rose-500">{t('set.eraseConfirm')}</span>
            <button
              type="button"
              className="btn btn-danger btn-sm"
              onClick={() => {
                eraseAll();
                setUrl('');
                setConfirm(false);
                notify(t('set.erased'), 'info');
              }}
            >
              {t('set.erase')}
            </button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setConfirm(false)}>
              {t('common.cancel')}
            </button>
          </div>
        ) : (
          <button type="button" className="btn btn-danger btn-sm" onClick={() => setConfirm(true)}>
            <Trash2 size={14} /> {t('set.erase')}
          </button>
        )}
      </Block>
    </div>
  );
}
