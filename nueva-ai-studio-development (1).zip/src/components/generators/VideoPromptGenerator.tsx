import { useState } from "react";
import { useI18n } from "../../i18n";
import { useGenerator } from "../../hooks/useGenerator";
import { generateVideoPrompt } from "../../utils/demo";
import type { Aspect, Duration, VideoStyle } from "../../types";
import {
  Button,
  Field,
  GeneratorCard,
  GeneratorResult,
  Select,
  Textarea,
  TextInput,
} from "../ui";
import { Icon } from "../Icon";

const STYLES: VideoStyle[] = ["cinematic", "ugc", "motion", "testimonial", "product360"];
const DURATIONS: Duration[] = ["s15", "s30", "s60"];
const ASPECTS: Aspect[] = ["r916", "r11", "r169"];

export function VideoPromptGenerator() {
  const { t, lang } = useI18n();
  const [product, setProduct] = useState("");
  const [style, setStyle] = useState<VideoStyle>("cinematic");
  const [duration, setDuration] = useState<Duration>("s30");
  const [aspect, setAspect] = useState<Aspect>("r916");
  const [scene, setScene] = useState("");
  const gen = useGenerator(lang, "video", t("studio.video.title"));

  const handleGenerate = () => {
    if (!product.trim()) {
      gen.setError("studio.errors.emptyProduct");
      return;
    }
    gen.generate(
      JSON.stringify([product, style, duration, aspect, scene, lang]),
      () =>
        generateVideoPrompt({
          product: product.trim(),
          style,
          duration,
          aspect,
          scene: scene.trim(),
          language: lang,
          labels: {
            style: t(`studio.videoStyles.${style}`),
            duration: t(`studio.durations.${duration}`),
            aspect: t(`studio.aspects.${aspect}`),
          },
        })
    );
  };

  return (
    <GeneratorCard icon="video" title={t("studio.video.title")} desc={t("studio.video.desc")}>
      <div className="space-y-3">
        <Field label={t("studio.video.product")}>
          <TextInput
            value={product}
            onChange={(e) => setProduct(e.target.value)}
            placeholder={t("studio.video.productPh")}
          />
        </Field>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Select
            label={t("studio.video.style")}
            value={style}
            onChange={(v) => setStyle(v as VideoStyle)}
            options={STYLES.map((k) => ({ value: k, label: t(`studio.videoStyles.${k}`) }))}
          />
          <Select
            label={t("studio.video.duration")}
            value={duration}
            onChange={(v) => setDuration(v as Duration)}
            options={DURATIONS.map((k) => ({ value: k, label: t(`studio.durations.${k}`) }))}
          />
          <Select
            label={t("studio.video.aspect")}
            value={aspect}
            onChange={(v) => setAspect(v as Aspect)}
            options={ASPECTS.map((k) => ({ value: k, label: t(`studio.aspects.${k}`) }))}
          />
        </div>
        <Field label={`${t("studio.video.scene")} (${t("common.optional")})`}>
          <Textarea
            value={scene}
            onChange={(e) => setScene(e.target.value)}
            placeholder={t("studio.video.scenePh")}
            rows={2}
          />
        </Field>
      </div>
      <div className="mt-auto space-y-2 pt-4">
        <Button onClick={handleGenerate} loading={gen.loading} className="w-full">
          <Icon name="play" className="h-4 w-4" />
          {gen.result ? t("common.regenerate") : t("common.generate")}
        </Button>
        {gen.error && (
          <p className="flex items-center gap-1.5 text-sm text-rose-500">
            <Icon name="alert" className="h-4 w-4 shrink-0" />
            {t(gen.error)}
          </p>
        )}
        <GeneratorResult
          title={t("studio.video.resultTitle")}
          result={gen.result}
          loading={gen.loading}
          onRegenerate={handleGenerate}
        />
      </div>
    </GeneratorCard>
  );
}
