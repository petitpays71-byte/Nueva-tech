import { useApp } from '../../context/AppContext';
import { cn } from '../../utils/cn';

export function ModeBadge({ className, onClick }: { className?: string; onClick?: () => void }) {
  const { aiConfigured, t, navigate } = useApp();
  const color = aiConfigured ? 'text-emerald-500 border-emerald-500/40 bg-emerald-500/10' : 'text-amber-500 border-amber-500/40 bg-amber-500/10';
  const dot = aiConfigured ? 'bg-emerald-500' : 'bg-amber-500';
  return (
    <button
      type="button"
      onClick={onClick ?? (() => navigate('settings'))}
      title={aiConfigured ? t('mode.aiShort') : t('mode.demoShort')}
      className={cn('inline-flex cursor-pointer items-center gap-2 rounded-full border px-2.5 py-1 text-xs font-semibold', color, className)}
    >
      <span className="relative flex h-2 w-2">
        <span className={cn('absolute inset-0 rounded-full', dot)} style={{ animation: 'pulse-ring 1.8s ease-out infinite' }} />
        <span className={cn('relative h-2 w-2 rounded-full', dot)} />
      </span>
      {aiConfigured ? t('mode.ai') : t('mode.demo')}
    </button>
  );
}
