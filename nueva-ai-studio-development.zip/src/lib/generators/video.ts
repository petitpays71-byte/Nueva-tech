import type { Lang, Values, Variant } from '../../types';
import { buildCtx, ctaLine, offerLine, upper1, type Ctx } from './helpers';

const SCENES: Record<string, string> = {
  market: 'a vibrant open-air market in {city}, colourful stalls, natural bustle softly out of focus',
  shop: 'a modern boutique interior in {city}, clean shelves and warm accent lighting',
  studio: 'a minimalist studio with a seamless backdrop and a softly reflective surface',
  home: 'a bright contemporary home in {city}, natural window light and authentic lived-in details',
  street: 'a stylish urban street in {city}, real architecture, motorbikes and pedestrians out of focus',
  workshop: 'a small local workshop where skilled hands craft the product, authentic textures and tools',
};

const STYLES: Record<string, string> = {
  cinematic:
    'Cinematic commercial, photorealistic, shot on a 35mm anamorphic lens, natural film grain, shallow depth of field, rich colour grade with deep blues and warm skin tones',
  ugc: 'Authentic UGC-style footage, handheld smartphone look, natural lighting, slight camera shake, real-person energy, unpolished but crisp',
  documentary: 'Documentary realism, observational handheld camera, 50mm lens, natural light, true-to-life colours',
  premium: 'Premium product commercial, ultra-clean, macro detail shots, slow gimbal and slider moves, glossy highlights, crisp 4K look',
};

const MOODS: Record<string, string> = {
  golden: 'warm golden-hour backlight with soft lens flares',
  daylight: 'bright natural daylight with soft shadows',
  night: 'night-time city lights, neon reflections and cinematic contrast',
  soft: 'soft diffused studio lighting with gentle gradients',
};

const TONE_FEEL: Record<string, string> = {
  professional: 'confident, polished and trustworthy',
  friendly: 'warm, welcoming and joyful',
  bold: 'high-energy, punchy and dynamic',
  luxury: 'elegant, slow and aspirational',
  fun: 'playful, bright and full of smiles',
  inspiring: 'uplifting, ambitious and hopeful',
};

interface ShotCtx {
  scene: string;
  name: string;
  desc: string;
}

type ShotFn = (s: ShotCtx) => string;

const LIB_A: ShotFn[] = [
  (s) => `Wide establishing shot of ${s.scene}. Slow push-in as a relatable local character walks into frame holding ${s.name}.`,
  (s) => `Hero close-up of ${s.name} (${s.desc}). Slow macro slider move revealing texture, material and build quality.`,
  (s) => `Medium shot: the character uses ${s.name} naturally with a genuine smile, handheld follow with subtle movement.`,
  (s) => `Detail insert: hands interacting with ${s.name}, rack focus from foreground to background.`,
  () => `Lifestyle moment: friends or family react warmly, candid laughter, shallow depth of field.`,
  (s) => `Final hero frame: ${s.name} centred with a soft glow, clean negative space for the logo and call to action.`,
];

const LIB_B: ShotFn[] = [
  (s) => `POV shot: hands reach for ${s.name} in ${s.scene}, natural handheld movement.`,
  (s) => `Whip-pan to a smiling local customer showing ${s.name} (${s.desc}) straight to the camera.`,
  (s) => `Slow-motion detail: light catching the texture and finish of ${s.name}.`,
  () => `Over-the-shoulder shot: the customer messages the brand on WhatsApp from a smartphone, relaxed and happy.`,
  (s) => `Group reaction: people nearby notice ${s.name} and smile, natural candid energy.`,
  (s) => `Closing frame: ${s.name} on a clean surface, subtle light sweep, space reserved for logo and contact details.`,
];

const PICKS: Record<number, number[]> = {
  2: [1, 5],
  3: [0, 1, 5],
  4: [0, 1, 2, 5],
  6: [0, 1, 2, 3, 4, 5],
};

function shotList(lib: ShotFn[], secs: number, s: ShotCtx): string {
  const idx = PICKS[secs <= 6 ? 2 : secs <= 10 ? 3 : secs <= 15 ? 4 : 6];
  const n = idx.length;
  const base = Math.floor(secs / n);
  let t = 0;
  return idx
    .map((i, k) => {
      const len = k === n - 1 ? secs - base * (n - 1) : base;
      const line = `${k + 1}. [${t}–${t + len}s] ${lib[i](s)}`;
      t += len;
      return line;
    })
    .join('\n');
}

function voiceOver(c: Ctx, secs: number): string {
  const hook = `${c.opener} ${c.name}.`;
  const what = `${upper1(c.desc)}.`;
  const who = c.fr ? `Pensé pour ${c.audience} ${c.where}.` : `Made for ${c.audience} ${c.where}.`;
  const bene = c.fr ? 'Qualité, style et prix juste, tout simplement.' : 'Quality, style and honest value, made simple.';
  const offer = offerLine(c);
  const cta = ctaLine(c);
  const parts =
    secs <= 6 ? [hook, cta] : secs <= 10 ? [hook, what, cta] : secs <= 15 ? [hook, what, offer || bene, cta] : [hook, what, who, bene, offer, cta];
  return parts.filter(Boolean).join(' ');
}

export function generateVideo(v: Values, lang: Lang): Variant[] {
  const c = buildCtx(v, lang);
  const fr = c.fr;
  const secs = [6, 10, 15, 30].includes(Number(v.duration)) ? Number(v.duration) : 15;
  const ratio = ['9:16', '16:9', '1:1'].includes(v.ratio) ? v.ratio : '9:16';
  const city = c.city || 'a major African city';
  const scene = (SCENES[v.scene] ?? SCENES.street).replace('{city}', city);
  const style = STYLES[v.style] ?? STYLES.cinematic;
  const mood = MOODS[v.mood] ?? MOODS.golden;
  const feel = TONE_FEEL[c.tone];
  const sc: ShotCtx = { scene, name: c.name, desc: c.desc };

  const L = fr
    ? {
        prompt: 'Prompt vidéo (en anglais, à coller dans votre outil)',
        shots: 'Plan de tournage (en anglais)',
        vo: 'Voix off',
        onscreen: 'Texte à l’écran',
        neg: 'Prompt négatif (à éviter)',
        tech: 'Réglages conseillés',
      }
    : {
        prompt: 'Video prompt (paste into your AI video tool)',
        shots: 'Shot list',
        vo: 'Voice-over script',
        onscreen: 'On-screen text',
        neg: 'Negative prompt (avoid)',
        tech: 'Recommended settings',
      };

  const negative =
    'blurry, low resolution, distorted hands or extra fingers, warped faces, uncanny skin, text artifacts, garbled logos, watermark, cartoonish look, stiff stock-photo poses, stereotypes, overexposed highlights';

  const audienceClause = c.hasAudience ? ` Casting and styling should resonate with: ${c.audience}.` : '';

  const buildPrompt = (camera: string, action: string) =>
    `${style}. A ${secs}-second ${ratio} advertising video for "${c.name}" (${c.desc}). ` +
    `Setting: ${scene}. Lighting: ${mood}. Mood: ${feel}. ` +
    `Camera: ${camera}. Action: ${action} ` +
    `Authentic, respectful, contemporary African representation with natural skin texture, realistic hands and believable movement.${audienceClause} ` +
    `The video ends on a clean hero frame of the product with space for the logo. No on-screen text, no watermark.`;

  const tech = fr
    ? `Format ${ratio} · ${secs} s · 24 ips · 1080p minimum · Générez 3 à 4 prises et gardez la plus naturelle · Ajoutez la voix off et le texte à l’écran au montage (CapCut, InShot…).`
    : `Aspect ratio ${ratio} · ${secs} s · 24 fps · 1080p minimum · Generate 3–4 takes and keep the most natural one · Add the voice-over and on-screen text in your editor (CapCut, InShot…).`;

  const onscreen = [c.name, c.offer, c.contact].filter(Boolean).join('\n');
  const vo = voiceOver(c, secs);

  const make = (title: string, camera: string, action: string, lib: ShotFn[]): Variant => ({
    title,
    sections: [
      { label: L.prompt, text: buildPrompt(camera, action) },
      { label: L.shots, text: shotList(lib, secs, sc) },
      { label: L.vo, text: vo },
      { label: L.onscreen, text: onscreen },
      { label: L.neg, text: negative },
      { label: L.tech, text: tech },
    ],
  });

  return [
    make(
      fr ? 'Narratif cinématographique' : 'Cinematic storytelling',
      'smooth push-ins, gentle gimbal movement and a slow macro slider move on the product',
      `a relatable local character discovers and enjoys ${c.name}, with a hero close-up of the product and a warm human reaction.`,
      LIB_A,
    ),
    make(
      fr ? 'Angle POV & lifestyle' : 'POV & lifestyle angle',
      'first-person POV, handheld energy, quick whip-pan transitions and a slow-motion detail shot',
      `hands reach for ${c.name}, a happy customer shows it to camera, and the story closes with a WhatsApp order moment.`,
      LIB_B,
    ),
  ];
}
