import { useEffect, useLayoutEffect, useRef, useState, type RefObject } from 'react';

/* ---------------------------------------------------------------- scales */
export function niceScale(maxVal: number, ticks = 4): { max: number; step: number; divisions: number } {
  if (!isFinite(maxVal) || maxVal <= 0) return { max: ticks, step: 1, divisions: ticks };
  const raw = maxVal / ticks;
  const exp = Math.pow(10, Math.floor(Math.log10(raw)));
  const f = raw / exp;
  const nf = f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10;
  const step = nf * exp;
  const divisions = Math.max(1, Math.ceil(maxVal / step - 1e-9));
  return { max: step * divisions, step, divisions };
}

/* ------------------------------------------------------ smooth line path */
export interface Pt {
  x: number;
  y: number;
}

/** Monotone cubic interpolation: smooth curves that never overshoot the data. */
export function monotonePath(pts: Pt[]): string {
  const n = pts.length;
  if (n === 0) return '';
  if (n === 1) return `M ${pts[0].x} ${pts[0].y}`;
  const dx: number[] = [];
  const m: number[] = [];
  for (let i = 0; i < n - 1; i++) {
    dx.push(pts[i + 1].x - pts[i].x || 1e-6);
    m.push((pts[i + 1].y - pts[i].y) / dx[i]);
  }
  const t: number[] = new Array<number>(n);
  t[0] = m[0];
  t[n - 1] = m[n - 2];
  for (let i = 1; i < n - 1; i++) {
    t[i] = m[i - 1] * m[i] <= 0 ? 0 : (2 * m[i - 1] * m[i]) / (m[i - 1] + m[i]);
  }
  let d = `M ${pts[0].x.toFixed(2)} ${pts[0].y.toFixed(2)}`;
  for (let i = 0; i < n - 1; i++) {
    const h = dx[i] / 3;
    d += ` C ${(pts[i].x + h).toFixed(2)} ${(pts[i].y + t[i] * h).toFixed(2)}, ${(pts[i + 1].x - h).toFixed(2)} ${(pts[i + 1].y - t[i + 1] * h).toFixed(2)}, ${pts[i + 1].x.toFixed(2)} ${pts[i + 1].y.toFixed(2)}`;
  }
  return d;
}

/* --------------------------------------------------------------- sizing */
export function useWidth(ref: RefObject<HTMLElement | null>): number {
  const [w, setW] = useState(0);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    setW(el.getBoundingClientRect().width);
    if (typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver((entries) => {
      const cr = entries[0]?.contentRect;
      if (cr) setW(cr.width);
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [ref]);
  return w;
}

/* ------------------------------------------------------------ animation */
function resample(from: number[], n: number): number[] {
  if (from.length === n) return from;
  if (from.length === 0) return new Array<number>(n).fill(0);
  if (from.length === 1) return new Array<number>(n).fill(from[0]);
  const out: number[] = [];
  for (let i = 0; i < n; i++) {
    const pos = n === 1 ? 0 : (i * (from.length - 1)) / (n - 1);
    const lo = Math.floor(pos);
    const hi = Math.min(from.length - 1, lo + 1);
    out.push(from[lo] + (from[hi] - from[lo]) * (pos - lo));
  }
  return out;
}

const prefersReducedMotion = () => typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

/**
 * Smoothly tweens a numeric array towards `target` (ease-out cubic).
 * When the length changes (e.g. daily → weekly buckets) the previous shape is resampled first,
 * so the curve morphs instead of jumping.
 */
export function useTweenedArray(target: number[], opts: { duration?: number; fromZero?: boolean } = {}): number[] {
  const { duration = 650, fromZero = false } = opts;
  const [value, setValue] = useState<number[]>(() => (fromZero ? target.map(() => 0) : target));
  const current = useRef<number[]>(value);
  const raf = useRef(0);
  const key = target.join('|');

  useEffect(() => {
    const from = resample(current.current, target.length);
    cancelAnimationFrame(raf.current);
    if (prefersReducedMotion() || duration <= 0) {
      current.current = target;
      setValue(target);
      return;
    }
    const start = performance.now();
    const step = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const e = 1 - Math.pow(1 - p, 3);
      const next = target.map((tv, i) => from[i] + (tv - from[i]) * e);
      current.current = next;
      setValue(next);
      if (p < 1) raf.current = requestAnimationFrame(step);
    };
    raf.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, duration]);

  // while the bucket count changes, morph from the resampled previous shape instead of snapping
  return value.length === target.length ? value : resample(value, target.length);
}

export function useTweenedNumber(target: number, opts: { duration?: number; fromZero?: boolean } = {}): number {
  return useTweenedArray([target], opts)[0];
}
