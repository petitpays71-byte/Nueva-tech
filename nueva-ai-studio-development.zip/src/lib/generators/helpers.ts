import type { Lang, Values } from '../../types';
import { marketById } from '../markets';

export type Tone = 'professional' | 'friendly' | 'bold' | 'luxury' | 'fun' | 'inspiring';
export type Goal = 'sales' | 'awareness' | 'leads';

export function shuffle<T>(arr: readonly T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function pick<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export const clean = (s?: string) => (s ?? '').replace(/\s+/g, ' ').trim();
export const stripEnd = (s: string) => s.replace(/[\s.!?…:;,]+$/, '');
export const upper1 = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

export function shorten(s: string, n: number): string {
  if (s.length <= n) return s;
  return s.slice(0, n).replace(/\s+\S*$/, '') + '…';
}

export function hashtag(s: string): string {
  const w = s
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9\s]/g, ' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .map(upper1)
    .join('');
  return w ? `#${w}` : '';
}

const EMOJIS: Record<Tone, string[]> = {
  professional: ['✅', '📌', '💼'],
  friendly: ['😊', '💛', '🙌'],
  bold: ['🔥', '⚡', '🚀'],
  luxury: ['✨', '🖤', '💎'],
  fun: ['😍', '🎉', '🤩'],
  inspiring: ['🌟', '💪', '🌍'],
};

const OPENERS: Record<Lang, Record<Tone, string[]>> = {
  en: {
    professional: ['Introducing', 'Presenting', 'Discover'],
    friendly: ['Hey, meet', 'Say hello to', 'Guess what? Here comes'],
    bold: ['Stop scrolling and meet', 'Big news: say hello to', 'Game changer alert:'],
    luxury: ['Elevate your everyday with', 'Discover the art of', 'Experience'],
    fun: ['Look who just landed:', 'Plot twist: meet', 'Say hello to your new favourite,'],
    inspiring: ['Dream bigger with', 'Your next chapter starts with', 'Built for ambition:'],
  },
  fr: {
    professional: ['Découvrez', 'Nous vous présentons', 'Voici'],
    friendly: ['Coucou, voici', 'Faites connaissance avec', 'Devinez quoi ? Voici'],
    bold: ['Arrêtez de scroller et découvrez', 'Grande nouvelle :', 'Alerte nouveauté :'],
    luxury: ['Sublimez votre quotidien avec', 'Découvrez l’art de', 'Vivez l’expérience'],
    fun: ['Regardez qui vient d’arriver :', 'Coup de théâtre :', 'Dites bonjour à votre nouveau coup de cœur,'],
    inspiring: ['Osez plus grand avec', 'Votre prochain chapitre commence avec', 'Conçu pour les ambitieux :'],
  },
};

export interface Ctx {
  lang: Lang;
  fr: boolean;
  name: string;
  desc: string;
  descShort: string;
  audience: string;
  hasAudience: boolean;
  city: string;
  where: string;
  country: string;
  offer: string;
  contact: string;
  tone: Tone;
  goal: Goal;
  /** random tone-aware opener that flows directly into the product name */
  opener: string;
  /** tone-aware emoji by index */
  e: (i?: number) => string;
  tags: string[];
}

export function buildCtx(v: Values, lang: Lang): Ctx {
  const fr = lang === 'fr';
  const market = marketById(v.market ?? '');
  const tone = (['professional', 'friendly', 'bold', 'luxury', 'fun', 'inspiring'].includes(v.tone) ? v.tone : 'friendly') as Tone;
  const goal = (['sales', 'awareness', 'leads'].includes(v.goal) ? v.goal : 'sales') as Goal;
  const name = clean(v.name);
  const desc = stripEnd(clean(v.desc));
  const audience = clean(v.audience);
  const city = market?.city ?? '';
  const country = market ? market.name[lang] : fr ? 'Afrique' : 'Africa';
  const where = city ? (fr ? `à ${city}` : `in ${city}`) : fr ? 'partout en Afrique' : 'across Africa';
  const emojis = EMOJIS[tone];
  const tags = [hashtag(name), hashtag(country), hashtag(city)].filter(Boolean);

  return {
    lang,
    fr,
    name,
    desc,
    descShort: shorten(desc, 70),
    audience: audience || (fr ? 'des clients comme vous' : 'customers like you'),
    hasAudience: !!audience,
    city,
    where,
    country,
    offer: stripEnd(clean(v.offer)),
    contact: clean(v.contact),
    tone,
    goal,
    opener: pick(OPENERS[lang][tone]),
    e: (i = 0) => emojis[i % emojis.length],
    tags,
  };
}

/** Call to action sentence depending on goal and optional contact. */
export function ctaLine(c: Ctx): string {
  if (c.goal === 'sales') {
    if (c.contact) return c.fr ? `Commandez maintenant sur WhatsApp : ${c.contact}` : `Order now on WhatsApp: ${c.contact}`;
    return c.fr ? 'Commandez dès aujourd’hui : envoyez-nous un message !' : 'Order today: send us a message!';
  }
  if (c.goal === 'leads') {
    if (c.contact) return c.fr ? `Demandez votre devis gratuit : ${c.contact}` : `Request your free quote: ${c.contact}`;
    return c.fr ? 'Demandez votre devis gratuit dès aujourd’hui.' : 'Request your free quote today.';
  }
  return c.fr
    ? 'Suivez-nous pour en savoir plus et partagez avec quelqu’un qui en a besoin.'
    : 'Follow us to learn more and share with someone who needs this.';
}

export function offerLine(c: Ctx): string {
  if (!c.offer) return '';
  return c.fr ? `Offre spéciale : ${c.offer}.` : `Special offer: ${c.offer}.`;
}

/** French typography: non-breaking thin space handling is skipped on purpose to keep copy/paste clean. */
export const colon = (c: Ctx) => (c.fr ? ' :' : ':');
