import type { ReactNode } from 'react';

interface Props {
  x: number;
  y: number;
  containerWidth: number;
  children: ReactNode;
}

/** Floating tooltip positioned inside a `relative` chart container. Flips below the point when there is no room above. */
export function ChartTooltip({ x, y, containerWidth, children }: Props) {
  const half = 90;
  const left = Math.min(Math.max(x, half), Math.max(half, containerWidth - half));
  const below = y < 110;
  return (
    <div
      role="tooltip"
      className="pointer-events-none absolute z-20 min-w-[130px] max-w-[200px] rounded-xl border border-line bg-surface/95 px-3 py-2 text-xs shadow-xl backdrop-blur-md"
      style={{
        left,
        top: below ? y + 16 : y - 12,
        transform: below ? 'translate(-50%, 0)' : 'translate(-50%, -100%)',
        transition: 'left .08s linear, top .08s linear',
      }}
    >
      {children}
    </div>
  );
}
