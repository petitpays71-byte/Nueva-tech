import type {
  AdPlatform,
  Aspect,
  Category,
  Duration,
  Language,
  Length,
  SocialGoal,
  SocialPlatform,
  Tone,
  VideoStyle,
} from "../types";

/* ------------------------------------------------------------------ */
/* Randomness + simulation helpers                                     */
/* ------------------------------------------------------------------ */

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function seedFromString(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function rngFor(seed: unknown): () => number {
  const key = typeof seed === "string" ? seed : JSON.stringify(seed);
  return mulberry32(seedFromString(`${key}|${Date.now()}|${Math.random()}`));
}

function pick<T>(rng: () => number, arr: readonly T[]): T {
  return arr[Math.floor(rng() * arr.length) % arr.length];
}

function fill(template: string, vars: Record<string, string>): string {
  return template.replace(/\{(\w+)\}/g, (_, key: string) => vars[key] ?? "");
}

function cap(text: string): string {
  return text.charAt(0).toUpperCase() + text.slice(1);
}

/**
 * Simulates an AI API call: shows a realistic latency, then produces the
 * content locally. No network request, no API key, fully offline.
 */
export function simulate<T>(
  produce: (rng: () => number) => T,
  delay = 900,
  seed = ""
): Promise<T> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      try {
        const rng = mulberry32(seedFromString(`${seed}|${Date.now()}|${Math.random()}`));
        resolve(produce(rng));
      } catch (err) {
        reject(err instanceof Error ? err : new Error("Generation failed"));
      }
    }, delay);
  });
}

/* ------------------------------------------------------------------ */
/* 1. Advertising text generator                                       */
/* ------------------------------------------------------------------ */

export interface AdTextInput {
  product: string;
  audience: string;
  tone: Tone;
  platform: AdPlatform;
  length: Length;
  benefit: string;
  language: Language;
}

const AD_HOOKS: Record<Language, Record<Tone, string[]>> = {
  en: {
    persuasive: [
      "Stop scrolling — {product} is about to change your daily routine.",
      "The smart choice for {audience}: {product}.",
      "Why pay more for less? {product} delivers premium results at a fair price.",
    ],
    friendly: [
      "A little treat for {audience} 💛 {product} is here!",
      "You deserve this: {product}, made with love.",
      "Good news for {audience} — {product} just landed!",
    ],
    professional: [
      "{product} — professional-grade quality for {audience}.",
      "Trusted by businesses across Africa: {product}.",
      "The standard {audience} rely on: {product}.",
    ],
    energetic: [
      "🔥 {product} is HERE and it's selling fast!",
      "Your new obsession? {product}. You're welcome 😉",
      "Energy boost: {product} just dropped! ⚡",
    ],
    humorous: [
      "Your old routine just called — it's jealous. Meet {product} 😄",
      "Warning: {product} may cause extreme satisfaction.",
      "We put {product} in a lab. The lab wasn't ready.",
    ],
  },
  fr: {
    persuasive: [
      "Stop, ne défilez plus — {product} va changer votre quotidien.",
      "Le choix malin pour {audience} : {product}.",
      "Pourquoi payer plus pour moins ? {product} offre une qualité premium à prix juste.",
    ],
    friendly: [
      "Un petit bonheur pour {audience} 💛 {product} est arrivé !",
      "Vous le méritez : {product}, préparé avec amour.",
      "Bonne nouvelle pour {audience} — {product} vient de sortir !",
    ],
    professional: [
      "{product} — une qualité professionnelle pour {audience}.",
      "La confiance des entreprises africaines : {product}.",
      "La référence que {audience} choisissent : {product}.",
    ],
    energetic: [
      "🔥 {product} EST ARRIVÉ et ça part très vite !",
      "Votre nouvelle obsession ? {product}. De rien 😉",
      "Boost d'énergie : {product} débarque ! ⚡",
    ],
    humorous: [
      "Votre ancienne routine vous a appelé — elle est jalouse. Voici {product} 😄",
      "Attention : {product} peut provoquer une satisfaction extrême.",
      "On a mis {product} dans un labo. Le labo n'était pas prêt.",
    ],
  },
};

const AD_BODIES: Record<Language, string[]> = {
  en: [
    "Designed with {audience} in mind, {product} combines {benefit} with unbeatable value. Every detail is crafted to make your everyday simpler, faster and more enjoyable.",
    "{product} is more than a purchase — it's a daily upgrade. With {benefit}, you get premium quality at a price that truly respects your budget.",
    "Join thousands of happy customers across Africa who already trust {product}. {benefitCap}, honest pricing and results you can see from day one.",
    "Why settle for less? {product} delivers {benefit} with a level of finish and reliability you notice immediately.",
  ],
  fr: [
    "Pensé pour {audience}, {product} allie {benefit} et un rapport qualité-prix imbattable. Chaque détail est conçu pour rendre votre quotidien plus simple, plus rapide et plus agréable.",
    "{product}, c'est plus qu'un achat — c'est un upgrade au quotidien. Avec {benefit}, profitez d'une qualité premium à un prix qui respecte vraiment votre budget.",
    "Rejoignez des milliers de clients satisfaits à travers l'Afrique qui font déjà confiance à {product}. {benefitCap}, des prix honnêtes et des résultats visibles dès le premier jour.",
    "Pourquoi se contenter de moins ? {product} vous offre {benefit} avec une finition et une fiabilité que vous remarquerez tout de suite.",
  ],
};

const AD_CTAS: Record<Language, string[]> = {
  en: [
    "👉 Order now on WhatsApp — delivery across Africa!",
    "🛒 Shop today and get FREE delivery on your first order.",
    "💬 Send us « INFO » to get your {product} within 24h.",
    "🔥 Limited stock — grab yours before it's gone!",
    "✅ Tap the link in bio to order in 30 seconds.",
  ],
  fr: [
    "👉 Commandez maintenant sur WhatsApp — livraison dans toute l'Afrique !",
    "🛒 Achetez aujourd'hui et recevez la livraison OFFERTE sur votre première commande.",
    "💬 Envoyez-nous « INFO » pour recevoir votre {product} sous 24 h.",
    "🔥 Stock limité — obtenez le vôtre avant épuisement !",
    "✅ Cliquez sur le lien en bio pour commander en 30 secondes.",
  ],
};

const AD_TAGS: Record<Language, Record<AdPlatform, string>> = {
  en: {
    facebook: "#FacebookAds #MadeInAfrica #ShopLocal #AfricanBusiness #Promo",
    instagram: "#InstagramAds #MadeInAfrica #AfricanBrand #InstaDaily #NewDrop",
    tiktok: "#TikTokAds #FYP #Viral #TikTokMadeMeBuyIt #AfricanBusiness",
    whatsapp: "📲 Order & info on WhatsApp — link in bio",
    google: "Keywords: {product} · buy {product} online · {product} price · best {product} Africa",
  },
  fr: {
    facebook: "#FacebookAds #MadeInAfrica #CommerceLocal #BusinessAfricain #Promo",
    instagram: "#InstagramAds #MadeInAfrica #MarqueAfricaine #InstaDaily #Nouveauté",
    tiktok: "#TikTokAds #FYP #Viral #TikTokMadeMeBuyIt #BusinessAfricain",
    whatsapp: "📲 Commande & infos sur WhatsApp — lien en bio",
    google:
      "Mots-clés : {product} · acheter {product} en ligne · prix {product} · meilleur {product} Afrique",
  },
};

export function generateAdText(input: AdTextInput): string {
  const rng = rngFor(input);
  const L = input.language;
  const benefit =
    input.benefit ||
    (L === "fr" ? "une qualité premium et des résultats réels" : "premium quality and real results");
  const vars = {
    product: input.product,
    audience: input.audience,
    benefit,
    benefitCap: cap(benefit),
  };
  const hook = fill(pick(rng, AD_HOOKS[L][input.tone]), vars);
  const bodyCount = input.length === "short" ? 1 : input.length === "medium" ? 2 : 3;
  const pool = [...AD_BODIES[L]];
  const bodies: string[] = [];
  while (bodies.length < bodyCount && pool.length > 0) {
    const index = Math.floor(rng() * pool.length);
    bodies.push(fill(pool.splice(index, 1)[0], vars));
  }
  const cta = fill(pick(rng, AD_CTAS[L]), vars);
  const tags = fill(AD_TAGS[L][input.platform], vars);
  return [hook, "", ...bodies, "", cta, "", tags].join("\n");
}

/* ------------------------------------------------------------------ */
/* 2. AI video prompt generator                                        */
/* ------------------------------------------------------------------ */

export interface VideoPromptInput {
  product: string;
  style: VideoStyle;
  duration: Duration;
  aspect: Aspect;
  scene: string;
  language: Language;
  labels: { style: string; duration: string; aspect: string };
}

interface SceneSet {
  hook: string[];
  s1: string[];
  s2: string[];
  cta: string[];
}

const VIDEO_SCENES: Record<Language, Record<VideoStyle, SceneSet>> = {
  en: {
    cinematic: {
      hook: [
        "Slow-motion hero shot of {product} on a dark reflective surface, golden dust particles floating in a beam of light.",
        "The name {product} appears in huge cinematic letters over an African city skyline at dusk.",
      ],
      s1: [
        "Aerial drone shot gliding over an African city at golden hour, then diving down to a hand picking up {product}.",
        "Macro detail of the texture and finish of {product}, rack focus, silky smooth 50 fps.",
      ],
      s2: [
        "A real customer unboxes {product} at home, genuine smile, warm window light — documentary style, no script.",
        "Quick montage of {product} in daily life: on the street, at the market, with friends.",
      ],
      cta: [
        "Packshot of {product} with light streaks and a clean logo reveal.",
        "Slow zoom on {product} with the tagline fading in.",
      ],
    },
    ugc: {
      hook: [
        "Selfie-style clip: a young creator in Dakar holds {product} to the camera, surprised face, natural daylight.",
        "« I can't believe I just found this » — a creator whispers to the camera while showing {product}.",
      ],
      s1: [
        "Fast handheld cuts of {product} in real life — street, market, friends. Authentic, slightly shaky, 100% relatable.",
        "Close-up of the creator's face, honest reaction while using {product}.",
      ],
      s2: [
        "The creator points at the key feature of {product}, quick zoom on the detail, wink to camera.",
        "A text overlay pops in with the price and the offer.",
      ],
      cta: [
        "The creator holds {product} next to the camera, says the call to action and points down to the link.",
        "End frame: {product} packshot with a « Link in bio » sticker.",
      ],
    },
    motion: {
      hook: [
        "3D render of {product} rotating on a dark navy background, electric blue particles swirling around it.",
        "Kinetic typography: the word « NEW » slams onto screen as {product} spins into frame.",
      ],
      s1: [
        "Geometric shapes assemble into the silhouette of {product}, glass and neon materials.",
        "Animated infographic: the features of {product} appear one by one with icons and micro-animations.",
      ],
      s2: [
        "The camera flies through a tunnel of light made of the product's key colors.",
        "Logo animation with a punchy sound-design beat.",
      ],
      cta: [
        "End card: {product} packshot, tagline and URL on an animated gradient background.",
        "{product} logo centered with a glowing pulse and the campaign tagline.",
      ],
    },
    testimonial: {
      hook: [
        "Medium close-up of a real customer in Lagos, looking straight into the lens: « This changed my routine. »",
        "A customer in Nairobi holds up {product}: « I didn't expect to love it this much. »",
      ],
      s1: [
        "B-roll of the customer using {product} at home, warm natural light, documentary style.",
        "A second customer shares their result, quick cut between the two stories.",
      ],
      s2: [
        "Montage of three customers smiling while holding {product}, upbeat and energetic.",
        "Slow zoom on the customer's face as they talk about the key benefit.",
      ],
      cta: [
        "Freeze-frame on the best quote with on-screen text and the call to action.",
        "Final frame: {product} packshot, logo and an « Order now » sticker.",
      ],
    },
    product360: {
      hook: [
        "Clean studio shot: {product} on a rotating turntable, pure dark background, soft rim light.",
        "{product} slowly rotates while a single spotlight carves its silhouette out of the dark.",
      ],
      s1: [
        "360° orbit camera move around {product}, macro details of the texture and finish.",
        "Exploded view: the components of {product} float apart and reassemble.",
      ],
      s2: [
        "Feature callouts appear with icons and short labels while the camera keeps orbiting.",
        "Close-up on the logo engraving with a satisfying rack focus.",
      ],
      cta: [
        "Front-facing packshot of {product} with an animated price tag.",
        "{product} centered, logo and URL fading in.",
      ],
    },
  },
  fr: {
    cinematic: {
      hook: [
        "Plan hero au ralenti de {product} sur une surface sombre et réfléchissante, des particules dorées flottent dans un faisceau de lumière.",
        "Le nom {product} apparaît en lettres cinématiques géantes sur le skyline d'une ville africaine au crépuscule.",
      ],
      s1: [
        "Plan de drone glissant au-dessus d'une ville africaine à l'heure dorée, plongeant vers une main qui saisit {product}.",
        "Plan macro de la texture et de la finition de {product}, mise au point fluide, 50 ips soyeux.",
      ],
      s2: [
        "Un vrai client déballe {product} à la maison, sourire sincère, lumière chaude de fenêtre — style documentaire, sans script.",
        "Montage rapide de {product} dans la vraie vie : dans la rue, au marché, entre amis.",
      ],
      cta: [
        "Packshot de {product} avec des traînées de lumière et un reveal de logo épuré.",
        "Zoom lent sur {product} avec le slogan qui apparaît en fondu.",
      ],
    },
    ugc: {
      hook: [
        "Clip façon selfie : un jeune créateur à Dakar présente {product} face caméra, visage surpris, lumière naturelle.",
        "« Je n'arrive pas à croire que je viens de trouver ça » — un créateur chuchote en montrant {product}.",
      ],
      s1: [
        "Cuts rapides filmés à la main avec {product} dans la vraie vie — rue, marché, amis. Authentique, légèrement tremblé, 100 % relatable.",
        "Gros plan sur le visage du créateur, réaction honnête en utilisant {product}.",
      ],
      s2: [
        "Le créateur pointe la fonctionnalité clé de {product}, zoom rapide sur le détail, clin d'œil à la caméra.",
        "Un texte superposé apparaît avec le prix et l'offre.",
      ],
      cta: [
        "Le créateur tient {product} près de la caméra, dit l'appel à l'action et pointe vers le lien.",
        "Plan final : packshot de {product} avec un sticker « Lien en bio ».",
      ],
    },
    motion: {
      hook: [
        "Rendu 3D de {product} en rotation sur fond bleu nuit, des particules bleu électrique tournoyant autour.",
        "Typographie cinétique : le mot « NOUVEAU » s'écrase à l'écran pendant que {product} pivote vers le cadre.",
      ],
      s1: [
        "Des formes géométriques s'assemblent pour former la silhouette de {product}, matières verre et néon.",
        "Infographie animée : les caractéristiques de {product} apparaissent une par une avec icônes et micro-animations.",
      ],
      s2: [
        "La caméra traverse un tunnel de lumière formé des couleurs clés du produit.",
        "Animation du logo avec un sound design punchy.",
      ],
      cta: [
        "Carton final : packshot de {product}, slogan et URL sur fond dégradé animé.",
        "Logo {product} centré avec une pulsation lumineuse et le slogan de la campagne.",
      ],
    },
    testimonial: {
      hook: [
        "Plan rapproché d'un vrai client à Lagos, droit dans l'objectif : « Ça a changé ma routine. »",
        "Une cliente à Nairobi présente {product} : « Je ne m'attendais pas à l'aimer autant. »",
      ],
      s1: [
        "B-roll de la cliente utilisant {product} à la maison, lumière naturelle chaude, style documentaire.",
        "Une deuxième cliente partage son résultat, cut rapide entre les deux histoires.",
      ],
      s2: [
        "Montage de trois clients souriants avec {product} entre les mains, énergique et rythmé.",
        "Zoom lent sur le visage de la cliente pendant qu'elle parle du bénéfice clé.",
      ],
      cta: [
        "Arrêt sur image sur la meilleure citation avec texte à l'écran et appel à l'action.",
        "Plan final : packshot de {product}, logo et sticker « Commander ».",
      ],
    },
    product360: {
      hook: [
        "Plan studio épuré : {product} sur un turntable rotatif, fond sombre pur, lumière de contour douce.",
        "{product} tourne lentement pendant qu'un seul projecteur sculpte sa silhouette dans l'obscurité.",
      ],
      s1: [
        "Orbite caméra à 360° autour de {product}, détails macro de la texture et de la finition.",
        "Vue éclatée : les composants de {product} flottent, se séparent et se réassemblent.",
      ],
      s2: [
        "Des annotations apparaissent avec icônes et intitulés courts pendant que la caméra poursuit son orbite.",
        "Gros plan sur le gravage du logo avec une mise au point satisfaisante.",
      ],
      cta: [
        "Packshot de face de {product} avec un prix animé.",
        "{product} centré, logo et URL en fondu.",
      ],
    },
  },
};

const CAMERA: Record<Language, string[]> = {
  en: [
    "Slow dolly-in, 35 mm, shallow depth of field",
    "Handheld gimbal following the subject, 24 fps",
    "Aerial drone shot with a sweeping curve over the city",
    "Static tripod, macro close-up, razor-sharp details",
    "Dynamic whip-pan transitions between scenes",
    "360° orbit turntable shot, clean studio look",
  ],
  fr: [
    "Dolly lent, 35 mm, faible profondeur de champ",
    "Gimbal portable suivant le sujet, 24 ips",
    "Plan de drone aérien avec une courbe ample au-dessus de la ville",
    "Trépied fixe, gros plan macro, détails ultra-nets",
    "Transitions en whip-pan dynamiques entre les scènes",
    "Plan tournant 360°, rendu studio propre",
  ],
};

const LIGHTING: Record<Language, string[]> = {
  en: [
    "Golden hour, warm and inviting",
    "Soft studio light with a rim light on the product",
    "High-contrast neon accents on a dark navy background",
    "Natural window light, fresh and clean",
    "Dramatic side light with deep shadows",
  ],
  fr: [
    "Heure dorée, chaleureuse et accueillante",
    "Lumière studio douce avec contre-jour sur le produit",
    "Accents néon contrastés sur fond bleu nuit",
    "Lumière naturelle de fenêtre, fraîche et propre",
    "Lumière latérale dramatique avec des ombres profondes",
  ],
};

const AUDIO: Record<Language, string[]> = {
  en: [
    "Upbeat Afrobeat instrumental, 110 BPM, strong hook",
    "Modern amapiano beat, punchy drums",
    "Inspiring corporate whoosh with subtle bass",
    "Acoustic guitar with hand claps, warm and human",
    "Cinematic trailer drums building to the CTA",
  ],
  fr: [
    "Instrumental afrobeat entraînant, 110 BPM, hook puissant",
    "Beat amapiano moderne, percussions punchy",
    "Whoosh corporate inspirant avec basse subtile",
    "Guitare acoustique et claps, chaleureux et humain",
    "Percussions de trailer cinématique montant vers le CTA",
  ],
};

const SCREEN_TEXT: Record<Language, string[]> = {
  en: [
    "« {product} — available now »",
    "« Order on WhatsApp »",
    "« New in »",
    "« Limited stock »",
    "« Link in bio »",
  ],
  fr: [
    "« {product} — disponible »",
    "« Commander sur WhatsApp »",
    "« Nouveau »",
    "« Stock limité »",
    "« Lien en bio »",
  ],
};

const DURATION_SECONDS: Record<Duration, number> = { s15: 15, s30: 30, s60: 60 };

export function generateVideoPrompt(input: VideoPromptInput): string {
  const rng = rngFor(input);
  const L = input.language;
  const vars = { product: input.product };
  const scenes = VIDEO_SCENES[L][input.style];
  const total = DURATION_SECONDS[input.duration];
  const marks = [
    0,
    Math.round(total * 0.2),
    Math.round(total * 0.55),
    Math.round(total * 0.8),
    total,
  ];
  const fmt = (s: number) => `0:${String(s).padStart(2, "0")}`;
  const seg = (i: number) => `[${fmt(marks[i])}–${fmt(marks[i + 1])}]`;
  const sceneText = [
    pick(rng, scenes.hook),
    pick(rng, scenes.s1),
    pick(rng, scenes.s2),
    pick(rng, scenes.cta),
  ].map((s) => fill(s, vars));

  const H =
    L === "fr"
      ? {
          title: "🎬 PROMPT VIDÉO IA",
          duration: "Durée",
          timeline: "⏱ CHRONOLOGIE",
          camera: "🎥 CAMÉRA",
          lighting: "💡 ÉCLAIRAGE",
          audio: "🔊 AUDIO",
          screen: "📝 TEXTE À L'ÉCRAN",
          negative: "🚫 PROMPT NÉGATIF",
          tip: "💡 CONSEIL",
          custom: "🎯 VOTRE SCÈNE PERSONNALISÉE",
          hook: "ACCROCHE",
          s1: "SCÈNE 1",
          s2: "SCÈNE 2",
          cta: "APPEL À L'ACTION",
          tipText:
            "Copiez ce prompt dans votre générateur de vidéo IA préféré (Sora, Veo, Kling, Runway…).",
          negativeText:
            "floue, basse qualité, visages déformés, filigrane, artefacts de texte, couleurs sursaturées, images tremblantes, personnes dupliquées",
        }
      : {
          title: "🎬 AI VIDEO PROMPT",
          duration: "Duration",
          timeline: "⏱ TIMELINE",
          camera: "🎥 CAMERA",
          lighting: "💡 LIGHTING",
          audio: "🔊 AUDIO",
          screen: "📝 ON-SCREEN TEXT",
          negative: "🚫 NEGATIVE PROMPT",
          tip: "💡 TIP",
          custom: "🎯 YOUR CUSTOM SCENE",
          hook: "HOOK",
          s1: "SCENE 1",
          s2: "SCENE 2",
          cta: "CTA",
          tipText:
            "Paste this prompt into your favorite AI video generator (Sora, Veo, Kling, Runway…).",
          negativeText:
            "blurry, low quality, distorted faces, watermark, text artifacts, oversaturated colors, shaky footage, duplicated people",
        };

  const lines = [
    `${H.title} — ${input.product.toUpperCase()}`,
    `${L === "fr" ? "Style" : "Style"}: ${input.labels.style} · ${H.duration}: ${input.labels.duration} · ${L === "fr" ? "Format" : "Format"}: ${input.labels.aspect}`,
    "",
    H.timeline,
    `${seg(0)} ${H.hook} — ${sceneText[0]}`,
    `${seg(1)} ${H.s1} — ${sceneText[1]}`,
    `${seg(2)} ${H.s2} — ${sceneText[2]}`,
    `${seg(3)} ${H.cta} — ${sceneText[3]}`,
  ];
  if (input.scene) lines.push("", `${H.custom}: ${input.scene}`);
  lines.push(
    "",
    `${H.camera}: ${pick(rng, CAMERA[L])}`,
    `${H.lighting}: ${pick(rng, LIGHTING[L])}`,
    `${H.audio}: ${pick(rng, AUDIO[L])}`,
    `${H.screen}: ${fill(pick(rng, SCREEN_TEXT[L]), vars)}`,
    `${H.negative}: ${H.negativeText}`,
    `${H.tip}: ${H.tipText}`
  );
  return lines.join("\n");
}

/* ------------------------------------------------------------------ */
/* 3. Product description generator                                    */
/* ------------------------------------------------------------------ */

export interface ProductDescriptionInput {
  name: string;
  category: Category;
  features: string;
  price: string;
  language: Language;
  labels: { category: string };
}

const TAGLINES: Record<Language, Record<Category, string[]>> = {
  en: {
    clothing: ["Wear your story.", "Made to be noticed."],
    electronics: ["Power your everyday.", "Tech that keeps up with you."],
    beauty: ["Glow, naturally.", "Your ritual, perfected."],
    food: ["Taste the tradition.", "Freshness, delivered."],
    services: ["Done for you. Done right.", "Your time is precious."],
    other: ["Simply better.", "Quality you can trust."],
  },
  fr: {
    clothing: ["Portez votre histoire.", "Fait pour être remarqué."],
    electronics: ["Boostez votre quotidien.", "La tech qui vous suit partout."],
    beauty: ["L'éclat, naturellement.", "Votre rituel, sublimé."],
    food: ["Le goût de la tradition.", "La fraîcheur, livrée."],
    services: ["Fait pour vous. Fait bien.", "Votre temps est précieux."],
    other: ["Simplement mieux.", "Une qualité de confiance."],
  },
};

const CATEGORY_WORD: Record<Language, Record<Category, string>> = {
  en: {
    clothing: "wardrobe staple",
    electronics: "device",
    beauty: "beauty ritual",
    food: "kitchen must-have",
    services: "trusted partner",
    other: "everyday essential",
  },
  fr: {
    clothing: "incontournable de votre garde-robe",
    electronics: "appareil",
    beauty: "rituel beauté",
    food: "indispensable de cuisine",
    services: "partenaire de confiance",
    other: "essentiel du quotidien",
  },
};

const EXTRA_BULLETS: Record<Language, Record<Category, string[]>> = {
  en: {
    clothing: ["7-day easy returns", "True-to-size African fit"],
    electronics: ["2-year warranty included", "Fast USB-C charging"],
    beauty: ["Suitable for all skin types", "Dermatologist tested"],
    food: ["Fresh, locally sourced", "No artificial preservatives"],
    services: ["Certified professional team", "Fast response, 7 days a week"],
    other: ["Satisfaction guaranteed", "Secure payment"],
  },
  fr: {
    clothing: ["Retours faciles sous 7 jours", "Coupe africaine fidèle à la taille"],
    electronics: ["Garantie 2 ans incluse", "Charge rapide USB-C"],
    beauty: ["Convient à tous les types de peau", "Testé dermatologiquement"],
    food: ["Frais, sourcing local", "Sans conservateurs artificiels"],
    services: ["Équipe professionnelle certifiée", "Réponse rapide, 7 j/7"],
    other: ["Satisfaction garantie", "Paiement sécurisé"],
  },
};

const DESC_TEMPLATES: Record<Language, string[]> = {
  en: [
    "{name} is the {categoryWord} your everyday has been waiting for. {featuresSentence} Designed and finished with care, it delivers {featuresShort} where it matters most.",
    "Discover {name}: {featuresSentence} Every detail counts — from the first touch to the last use, {name} is built to make a difference in your daily routine.",
    "Looking for {featuresShort}? {name} was made for exactly that. {featuresSentence} A product that works as hard as you do, at a price that makes sense.",
  ],
  fr: [
    "{name} est le {categoryWord} que votre quotidien attendait. {featuresSentence} Conçu et fini avec soin, il offre {featuresShort} là où ça compte vraiment.",
    "Découvrez {name} : {featuresSentence} Chaque détail compte — du premier toucher à la dernière utilisation, {name} est pensé pour faire la différence au quotidien.",
    "Vous cherchez {featuresShort} ? {name} est fait pour ça. {featuresSentence} Un produit qui travaille aussi dur que vous, à un prix qui a du sens.",
  ],
};

export function generateProductDescription(input: ProductDescriptionInput): string {
  const rng = rngFor(input);
  const L = input.language;
  const featureList = input.features
    .split(/[,;\n]/)
    .map((f) => f.trim())
    .filter(Boolean);
  const featuresShort =
    featureList.length > 0
      ? featureList.slice(0, 2).join(", ")
      : L === "fr"
        ? "une qualité premium et des résultats réels"
        : "premium quality and real results";
  const featuresSentence =
    featureList.length > 0
      ? L === "fr"
        ? `Livré avec : ${featureList.join(", ")}.`
        : `It comes with ${featureList.join(", ")}.`
      : L === "fr"
        ? "Livré avec une qualité premium, dès la sortie de la boîte."
        : "It comes with premium quality out of the box.";
  const vars = {
    name: input.name,
    categoryWord: CATEGORY_WORD[L][input.category],
    featuresSentence,
    featuresShort,
  };
  const tagline = pick(rng, TAGLINES[L][input.category]);
  const paragraph = fill(pick(rng, DESC_TEMPLATES[L]), vars);
  const bullets = [
    ...featureList.slice(0, 4).map((f) => `• ${cap(f)}`),
    ...EXTRA_BULLETS[L][input.category].map((b) => `• ${b}`),
  ];
  const price = input.price || (L === "fr" ? "Sur demande" : "On request");
  const keywords =
    L === "fr"
      ? `${input.name}, acheter ${input.name} en ligne, prix ${input.name}, meilleure ${input.labels.category} en Afrique`
      : `${input.name}, buy ${input.name} online, ${input.name} price, best ${input.labels.category} in Africa`;
  return [
    `🛍️ ${input.name.toUpperCase()} — ${tagline}`,
    "",
    paragraph,
    "",
    L === "fr" ? "✨ Pourquoi vous allez adorer :" : "✨ Why you'll love it:",
    ...bullets,
    "",
    `💰 ${L === "fr" ? "Prix" : "Price"}: ${price}`,
    `🔎 ${L === "fr" ? "Mots-clés SEO" : "SEO keywords"}: ${keywords}`,
  ].join("\n");
}

/* ------------------------------------------------------------------ */
/* 4. Social media content generator                                   */
/* ------------------------------------------------------------------ */

export interface SocialContentInput {
  platform: SocialPlatform;
  topic: string;
  goal: SocialGoal;
  language: Language;
  labels: { platform: string };
}

const GOAL_LINE: Record<Language, Record<SocialGoal, string>> = {
  en: {
    awareness: "so everyone talks about it",
    sales: "and grab yours today",
    engagement: "and tell me in the comments",
    traffic: "and tap the link in bio",
  },
  fr: {
    awareness: "pour que tout le monde en parle",
    sales: "et attrape le tien aujourd'hui",
    engagement: "et dis-moi ça dans les commentaires",
    traffic: "et clique sur le lien en bio",
  },
};

const TIKTOK_HOOKS: Record<Language, string[]> = {
  en: [
    "POV: you finally found {topic} that actually works 😭",
    "I stopped buying everything else when I discovered {topic}",
    "Tell me you're obsessed without telling me you're obsessed…",
    "Day {day} of using {topic} — here's what happened 👀",
    "This {topic} has no business being this good",
  ],
  fr: [
    "POV : tu viens enfin de trouver {topic} qui marche vraiment 😭",
    "J'ai arrêté d'acheter tout le reste quand j'ai découvert {topic}",
    "Dis-moi que tu es obsédé(e) sans me dire que tu es obsédé(e)…",
    "Jour {day} avec {topic} — voici ce qui s'est passé 👀",
    "Ce {topic} n'a aucune raison d'être aussi bien",
  ],
};

const TIKTOK_CAPTIONS: Record<Language, string[]> = {
  en: [
    "Link in bio before it sells out 🔥 {goalLine}",
    "Who else is running to try this? 👇 {goalLine}",
    "Save this for your next shopping spree 🛍️ {goalLine}",
  ],
  fr: [
    "Lien en bio avant rupture de stock 🔥 {goalLine}",
    "Qui d'autre court essayer ça ? 👇 {goalLine}",
    "Enregistre ça pour ton prochain shopping 🛍️ {goalLine}",
  ],
};

const TIKTOK_IDEA: Record<Language, string> = {
  en: "3 quick scenes: (1) close-up unboxing of {topic}, (2) using {topic} in real life, (3) genuine reaction + call to action. Trending sound, fast cuts, bold text overlays.",
  fr: "3 scènes rapides : (1) déballage de {topic} en gros plan, (2) utilisation de {topic} dans la vraie vie, (3) réaction sincère + appel à l'action. Son tendance, cuts rapides, textes bien visibles.",
};

const FB_POSTS: Record<Language, string[]> = {
  en: [
    "✨ New arrival: {topic}!\n\n{goalLineCap} — quality you can feel, prices you'll love, delivery across Africa.\n\n👉 Order now — link in the comments!",
    "{topic} is finally here 🚀\n\nThe wait is over: {goalLineCap}, and it's even better than expected.\n\n🛒 The first 20 orders get FREE delivery. Who's in?",
  ],
  fr: [
    "✨ Nouveauté : {topic} !\n\n{goalLineCap} — une qualité que vous sentez, des prix que vous aimez, livraison dans toute l'Afrique.\n\n👉 Commandez maintenant — lien dans les commentaires !",
    "{topic} est enfin arrivé(e) 🚀\n\nL'attente est terminée : {goalLineCap}, et c'est encore mieux que prévu.\n\n🛒 Les 20 premières commandes ont la livraison OFFERTE. Qui est partant ?",
  ],
};

const FB_TIPS: Record<Language, string> = {
  en: "Pin this post and drop the link in the first comment to boost organic reach.",
  fr: "Épinglez ce post et mettez le lien dans le premier commentaire pour booster la portée organique.",
};

const WA_STATUS: Record<Language, string[]> = {
  en: [
    "🔥 {topic} is HERE! Who wants one? 👇",
    "New drop 🚨 {topic} — first 20 orders get free delivery!",
    "PSA: {topic} restocked 😍 Order before midnight!",
  ],
  fr: [
    "🔥 {topic} EST ARRIVÉ(E) ! Qui en veut ? 👇",
    "Nouveau drop 🚨 {topic} — les 20 premières commandes ont la livraison offerte !",
    "Info : {topic} réapprovisionné(e) 😍 Commandez avant minuit !",
  ],
};

const WA_BROADCAST: Record<Language, string[]> = {
  en: [
    "Hello! 👋 Great news: {topic} is now available at NUEVA TECHNOLOGY.\n\n✨ {goalLineCap}\n🚚 Delivery across Africa\n💳 Secure payment\n\nTo order, just reply « ORDER » and we'll take care of you in under 2 minutes 😉",
    "Hi there! 😊 {topic} just landed and stocks are limited.\n\n👉 Reply « PRICE » to get the price list\n👉 Reply « ORDER » to reserve yours\n\nWe deliver everywhere in Africa 🚚",
  ],
  fr: [
    "Bonjour ! 👋 Bonne nouvelle : {topic} est disponible chez NUEVA TECHNOLOGY.\n\n✨ {goalLineCap}\n🚚 Livraison dans toute l'Afrique\n💳 Paiement sécurisé\n\nPour commander, répondez juste « COMMANDER » et on s'occupe de vous en moins de 2 minutes 😉",
    "Salut ! 😊 {topic} vient d'arriver et les stocks sont limités.\n\n👉 Répondez « PRIX » pour recevoir la liste des prix\n👉 Répondez « COMMANDER » pour réserver le vôtre\n\nNous livrons partout en Afrique 🚚",
  ],
};

const WA_QUICK_REPLIES: Record<Language, string[]> = {
  en: [
    "1. « What's the price? »",
    "2. « How do I order? »",
    "3. « Do you deliver to my city? »",
  ],
  fr: [
    "1. « Quel est le prix ? »",
    "2. « Comment je commande ? »",
    "3. « Vous livrez dans ma ville ? »",
  ],
};

const HASHTAGS: Record<SocialPlatform, Record<Language, string>> = {
  tiktok: {
    en: "#️⃣ #TikTokAds #FYP #Viral #AfricanBusiness #TikTokMadeMeBuyIt #NewDrop",
    fr: "#️⃣ #TikTokAds #FYP #Viral #BusinessAfricain #TikTokMadeMeBuyIt #Nouveauté",
  },
  facebook: {
    en: "#️⃣ #MadeInAfrica #ShopLocal #AfricanBusiness #FacebookAds #NewArrival",
    fr: "#️⃣ #MadeInAfrica #CommerceLocal #BusinessAfricain #FacebookAds #Nouveauté",
  },
  whatsapp: {
    en: "💡 No hashtags on WhatsApp — keep it short, warm and human.",
    fr: "💡 Pas de hashtags sur WhatsApp — restez court, chaleureux et humain.",
  },
};

export function generateSocialContent(input: SocialContentInput): string {
  const rng = rngFor(input);
  const L = input.language;
  const goalLine = GOAL_LINE[L][input.goal];
  const vars = { topic: input.topic, goalLine, goalLineCap: cap(goalLine) };

  if (input.platform === "tiktok") {
    const hook = fill(pick(rng, TIKTOK_HOOKS[L]), {
      ...vars,
      day: String(3 + Math.floor(rng() * 19)),
    });
    const caption = fill(pick(rng, TIKTOK_CAPTIONS[L]), vars);
    const idea = fill(TIKTOK_IDEA[L], vars);
    return [
      L === "fr" ? `🎵 CONTENU TIKTOK — ${input.topic}` : `🎵 TIKTOK CONTENT — ${input.topic}`,
      "",
      L === "fr" ? `🎣 ACCROCHE (0–3 s) : ${hook}` : `🎣 HOOK (0–3 s): ${hook}`,
      L === "fr" ? `📝 LÉGENDE : ${caption}` : `📝 CAPTION: ${caption}`,
      L === "fr" ? `🎬 IDÉE VIDÉO : ${idea}` : `🎬 VIDEO IDEA: ${idea}`,
      HASHTAGS.tiktok[L],
      L === "fr"
        ? "⏰ Meilleur créneau : 19 h – 21 h, du mardi au jeudi."
        : "⏰ Best time to post: 7–9 pm, Tuesday to Thursday.",
    ].join("\n");
  }

  if (input.platform === "facebook") {
    const post = fill(pick(rng, FB_POSTS[L]), vars);
    return [
      L === "fr" ? `📘 POST FACEBOOK — ${input.topic}` : `📘 FACEBOOK POST — ${input.topic}`,
      "",
      post,
      "",
      HASHTAGS.facebook[L],
      L === "fr" ? `💡 CONSEIL PRO : ${FB_TIPS.fr}` : `💡 PRO TIP: ${FB_TIPS.en}`,
    ].join("\n");
  }

  const status = fill(pick(rng, WA_STATUS[L]), vars);
  const message = fill(pick(rng, WA_BROADCAST[L]), vars);
  const replies = WA_QUICK_REPLIES[L];
  return [
    L === "fr" ? `💬 CONTENU WHATSAPP — ${input.topic}` : `💬 WHATSAPP CONTENT — ${input.topic}`,
    "",
    L === "fr" ? "📲 STATUT :" : "📲 STATUS:",
    status,
    "",
    L === "fr" ? "📨 MESSAGE DE DIFFUSION :" : "📨 BROADCAST MESSAGE:",
    message,
    "",
    L === "fr" ? "⚡ RÉPONSES RAPIDES (pour votre équipe) :" : "⚡ QUICK REPLIES (for your team):",
    ...replies,
    "",
    HASHTAGS.whatsapp[L],
  ].join("\n");
}
