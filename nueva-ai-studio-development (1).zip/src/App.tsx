import { useEffect, useState } from "react";
import { I18nProvider, useI18n } from "./i18n";
import { ToastProvider } from "./components/Toast";
import { Header, MobileNav, useTheme, type Tab } from "./components/Header";
import { StudioView } from "./components/StudioView";
import { AnalyticsDashboard } from "./components/analytics/AnalyticsDashboard";
import { HistoryPanel } from "./components/HistoryPanel";
import { Icon } from "./components/Icon";
import { HISTORY_EVENT, loadHistory } from "./utils/history";

function AppShell() {
  const { t } = useI18n();
  const { theme, setTheme } = useTheme();
  const [tab, setTab] = useState<Tab>("studio");
  const [historyCount, setHistoryCount] = useState(() => loadHistory().length);

  useEffect(() => {
    const handler = () => setHistoryCount(loadHistory().length);
    window.addEventListener(HISTORY_EVENT, handler);
    return () => window.removeEventListener(HISTORY_EVENT, handler);
  }, []);

  return (
    <div className="min-h-screen bg-slate-100 bg-gradient-to-b from-slate-100 to-slate-200 dark:from-navy-950 dark:to-navy-900">
      <Header
        tab={tab}
        onTabChange={setTab}
        historyCount={historyCount}
        theme={theme}
        onThemeToggle={() => setTheme(theme === "dark" ? "light" : "dark")}
      />
      <main className="mx-auto max-w-7xl px-4 pb-28 pt-6 md:px-6 md:pb-16">
        {tab === "studio" && <StudioView />}
        {tab === "analytics" && <AnalyticsDashboard />}
        {tab === "history" && <HistoryPanel />}
      </main>
      <MobileNav tab={tab} onTabChange={setTab} historyCount={historyCount} />
      <footer className="mx-auto max-w-7xl px-4 pb-28 pt-8 text-center text-xs text-slate-400 dark:text-slate-500 md:pb-8">
        <p className="flex items-center justify-center gap-1.5 font-medium">
          <Icon name="zap" className="h-3.5 w-3.5 text-electric-500" />
          NUEVA AI STUDIO — {t("app.company")}
        </p>
        <p className="mt-1">{t("footer.made")}</p>
        <p className="mt-0.5">{t("footer.demo")}</p>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <I18nProvider>
      <ToastProvider>
        <AppShell />
      </ToastProvider>
    </I18nProvider>
  );
}
