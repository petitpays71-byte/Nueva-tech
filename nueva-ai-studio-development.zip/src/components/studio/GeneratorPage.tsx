import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { AlertTriangle, CheckCircle2, Info, Lightbulb, Loader2, RotateCcw, Sparkles, Wand2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import type { HistoryItem, ToolId, Values } from '../../types';
import type { TKey } from '../../i18n/translations';
import { TOOLS, defaultValues, type FieldDef } from '../../lib/tools';
import { GenError, generate } from '../../lib/generators';
import { fmtDateTime, trunc, uid } from '../../lib/format';
import { ModeBadge } from '../ui/ModeBadge';
import { ResultCard } from './ResultCard';
import { cn } from '../../utils/cn';

type Status = 'idle' | 'loading' | 'error';

function Field({ def, value, error, onChange }: { def: FieldDef; value: string; error?: string; onChange: (v: string) => void }) {
  const { t, lang } = useApp();
  const id = `field-${def.key}`;
  const common = {
    id,
    'aria-invalid': error ? true : undefined,
    'aria-describedby': error ? `${id}-err` : undefined,
  } as const;

  return (
    <div className={cn(def.span === 1 ? '' : 'sm:col-span-2')}>
      <label htmlFor={id} className="label">
        {def.label[lang]}
        {def.required && <span className="ml-0.5 text-brand">*</span>}
      </label>
      {def.type === 'select' ? (
        <select {...common} className="input" value={value} onChange={(e) => onChange(e.target.value)}>
          {def.options?.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label[lang]}
            </option>
          ))}
        </select>
      ) : def.type === 'textarea' ? (
        <textarea
          {...common}
          className="input resize-y"
          rows={def.rows ?? 3}
          maxLength={def.maxLength}
          value={value}
          placeholder={def.placeholder?.[lang]}
          onChange={(e) => onChange(e.target.value)}
        />
      ) : (
        <input
          {...common}
          className="input"
          type="text"
          maxLength={def.maxLength}
          value={value}
          placeholder={def.placeholder?.[lang]}
          autoComplete="off"
          onChange={(e) => onChange(e.target.value)}
        />
      )}
      {error && (
        <p id={`${id}-err`} className="mt-1 flex items-center gap-1 text-xs font-medium text-rose-500">
          <AlertTriangle size={12} /> {t('gen.required')}
        </p>
      )}
      {def.maxLength && def.type === 'textarea' && value.length > def.maxLength * 0.8 && (
        <p className="mt-1 text-right text-[10px] text-muted tabular-nums">
          {value.length}/{def.maxLength}
        </p>
      )}
    </div>
  );
}

export function GeneratorPage({ tool }: { tool: ToolId }) {
  const { t, lang, drafts, setDraft, latest, setLatest, addHistory, proxyUrl, aiConfigured, notify, navigate } = useApp();
  const def = TOOLS[tool];
  const Icon = def.icon;

  const values: Values = drafts[tool] ?? defaultValues(tool, lang);
  const result: HistoryItem | null = latest[tool] ?? null;

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<Status>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const resultsRef = useRef<HTMLElement>(null);
  const scrollNext = useRef(false);

  const visible = useMemo(() => def.fields.filter((f) => !f.showIf || f.showIf(values)), [def.fields, values]);

  useEffect(() => {
    if (scrollNext.current && result && window.innerWidth < 1024) {
      scrollNext.current = false;
      resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [result]);

  const setValue = (key: string, v: string) => {
    setDraft(tool, { ...values, [key]: v });
    if (errors[key]) setErrors((e) => ({ ...e, [key]: '' }));
  };

  const mapError = (e: unknown): string => {
    if (e instanceof GenError) {
      if (e.code === 'http') return t('gen.err.http', { status: e.status ?? '' });
      return t(`gen.err.${e.code}` as TKey);
    }
    return t('gen.err.local');
  };

  const run = async (forceDemo = false) => {
    const errs: Record<string, string> = {};
    visible.forEach((f) => {
      if (f.required && !(values[f.key] ?? '').trim()) errs[f.key] = 'required';
    });
    if (Object.keys(errs).length) {
      setErrors(errs);
      const first = Object.keys(errs)[0];
      const el = document.getElementById(`field-${first}`);
      el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el?.focus({ preventScroll: true });
      return;
    }

    setErrors({});
    setStatus('loading');
    setErrorMsg('');

    const payload: Values = { outLang: values.outLang || lang };
    visible.forEach((f) => {
      payload[f.key] = (values[f.key] ?? '').trim();
    });

    try {
      const out = await generate(tool, payload, proxyUrl, forceDemo);
      const item: HistoryItem = {
        id: uid(),
        tool,
        createdAt: Date.now(),
        lang: payload.outLang === 'fr' ? 'fr' : 'en',
        mode: out.mode,
        summary: trunc(`${payload.name} · ${payload.desc}`, 90),
        inputs: payload,
        variants: out.variants,
        favorite: false,
      };
      addHistory(item);
      scrollNext.current = true;
      setLatest(tool, item);
      setStatus('idle');
      notify(t('gen.saved'));
    } catch (e) {
      setStatus('error');
      setErrorMsg(mapError(e));
    }
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (status !== 'loading') void run();
  };

  const fillExample = () => {
    setDraft(tool, { ...defaultValues(tool, lang), ...def.examples[lang] });
    setErrors({});
    notify(t('gen.exampleFilled'), 'info');
  };

  const reset = () => {
    setDraft(tool, defaultValues(tool, lang));
    setErrors({});
    setStatus('idle');
    setErrorMsg('');
    setLatest(tool, null);
  };

  const loading = status === 'loading';

  return (
    <div className="space-y-5">
      {/* header */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex min-w-0 items-start gap-3.5">
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white" style={{ background: 'linear-gradient(135deg,#1b66ff,#22b8ee)', boxShadow: 'var(--glow)' }}>
            <Icon size={22} />
          </span>
          <div className="min-w-0">
            <h2 className="font-display text-xl leading-tight font-bold tracking-tight text-ink sm:text-2xl">{t(`tool.${tool}.name` as TKey)}</h2>
            <p className="mt-1 max-w-2xl text-sm text-muted">{t(`tool.${tool}.desc` as TKey)}</p>
          </div>
        </div>
        <ModeBadge className="sm:mt-1" />
      </div>

      {/* mode banner */}
      <div
        className={cn(
          'flex items-start gap-2.5 rounded-xl border px-3.5 py-2.5 text-xs leading-relaxed sm:text-[13px]',
          aiConfigured ? 'border-emerald-500/30 bg-emerald-500/8 text-emerald-600 dark:text-emerald-300' : 'border-amber-500/30 bg-amber-500/8 text-amber-700 dark:text-amber-300',
        )}
      >
        <Info size={15} className="mt-0.5 shrink-0" />
        <span>{aiConfigured ? t('gen.aiBanner') : t('gen.demoBanner')}</span>
      </div>
      {tool === 'video' && (
        <div className="flex items-start gap-2.5 rounded-xl border border-brand/30 bg-brand/8 px-3.5 py-2.5 text-xs leading-relaxed text-brand sm:text-[13px]">
          <Info size={15} className="mt-0.5 shrink-0" />
          <span>{t('gen.videoNote')}</span>
        </div>
      )}

      <div className="grid items-start gap-5 lg:grid-cols-12">
        {/* ------------- form ------------- */}
        <form onSubmit={onSubmit} noValidate className="card p-4 sm:p-5 lg:col-span-5">
          <div className="mb-4 flex items-center justify-between gap-2">
            <h3 className="font-display text-base font-bold text-ink">{t('gen.brief')}</h3>
            <button type="button" className="btn btn-ghost btn-sm" onClick={fillExample}>
              <Wand2 size={14} /> {t('common.example')}
            </button>
          </div>

          <div className="grid gap-3.5 sm:grid-cols-2">
            {visible.map((f) => (
              <Field key={f.key} def={f} value={values[f.key] ?? ''} error={errors[f.key]} onChange={(v) => setValue(f.key, v)} />
            ))}
          </div>

          {Object.values(errors).some(Boolean) && (
            <p className="mt-4 flex items-center gap-2 rounded-lg bg-rose-500/10 px-3 py-2 text-xs font-semibold text-rose-500" role="alert">
              <AlertTriangle size={14} /> {t('gen.fixErrors')}
            </p>
          )}

          <div className="mt-5 flex gap-2">
            <button type="submit" className="btn btn-primary flex-1 !py-3" disabled={loading}>
              {loading ? <Loader2 size={17} className="animate-spin" /> : <Sparkles size={17} />}
              {loading ? t('common.generating') : t('common.generate')}
            </button>
            <button type="button" className="btn btn-ghost" onClick={reset} disabled={loading} aria-label={t('common.reset')}>
              <RotateCcw size={16} />
              <span className="hidden sm:inline">{t('common.reset')}</span>
            </button>
          </div>

          <p className="mt-4 flex items-start gap-2 text-xs leading-relaxed text-muted">
            <Lightbulb size={14} className="mt-0.5 shrink-0 text-brand" />
            <span>
              <strong className="text-ink">{t('gen.tipTitle')}:</strong> {t(`gen.tip.${tool}` as TKey)}
            </span>
          </p>
        </form>

        {/* ------------- results ------------- */}
        <section ref={resultsRef} className="scroll-mt-20 space-y-4 lg:col-span-7" aria-live="polite" aria-busy={loading}>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="font-display text-base font-bold text-ink">{t('gen.results')}</h3>
            {result && !loading && (
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-500">
                  <CheckCircle2 size={14} /> {t('gen.saved')}
                </span>
                <span className="text-xs text-muted">{t('gen.generatedAt', { time: fmtDateTime(result.createdAt, lang) })}</span>
                <span className={cn('rounded-full px-2 py-0.5 text-[10px] font-bold uppercase', result.mode === 'ai' ? 'bg-emerald-500/15 text-emerald-500' : 'bg-amber-500/15 text-amber-500')}>
                  {result.mode === 'ai' ? t('mode.ai') : t('mode.demo')}
                </span>
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => void run()}>
                  <RotateCcw size={13} /> {t('common.regenerate')}
                </button>
              </div>
            )}
          </div>

          {loading && (
            <div className="space-y-4" role="status">
              <div className="card flex items-center gap-3 p-4">
                <Loader2 className="animate-spin text-brand" size={22} />
                <div>
                  <div className="text-sm font-bold text-ink">{t('gen.loadingTitle')}</div>
                  <div className="text-xs text-muted">{t('gen.loadingBody')}</div>
                </div>
              </div>
              {[0, 1].map((i) => (
                <div key={i} className="card space-y-3 p-4">
                  <div className="skeleton h-5 w-1/3" />
                  <div className="skeleton h-4 w-full" />
                  <div className="skeleton h-4 w-11/12" />
                  <div className="skeleton h-4 w-3/4" />
                </div>
              ))}
            </div>
          )}

          {!loading && status === 'error' && (
            <div className="card border-rose-500/40 p-5" role="alert">
              <div className="flex items-start gap-3">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-rose-500/12 text-rose-500">
                  <AlertTriangle size={20} />
                </span>
                <div className="min-w-0">
                  <div className="text-sm font-bold text-ink">{t('gen.errorTitle')}</div>
                  <p className="mt-1 text-sm text-muted">{errorMsg}</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button type="button" className="btn btn-primary btn-sm" onClick={() => void run()}>
                      <RotateCcw size={13} /> {t('common.retry')}
                    </button>
                    {aiConfigured && (
                      <button type="button" className="btn btn-ghost btn-sm" onClick={() => void run(true)}>
                        {t('gen.useDemo')}
                      </button>
                    )}
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => navigate('settings')}>
                      {t('nav.settings')}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {!loading && status !== 'error' && !result && (
            <div className="card grid place-items-center border-dashed px-6 py-14 text-center">
              <span className="mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-brand/12 text-brand">
                <Icon size={26} />
              </span>
              <div className="font-display text-base font-bold text-ink">{t('gen.emptyTitle')}</div>
              <p className="mt-1.5 max-w-sm text-sm text-muted">{t('gen.emptyBody')}</p>
            </div>
          )}

          {!loading && status !== 'error' && result && (
            <div className="space-y-4">
              {result.variants.map((v, i) => (
                <ResultCard key={`${result.id}-${i}`} variant={v} index={i} />
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
