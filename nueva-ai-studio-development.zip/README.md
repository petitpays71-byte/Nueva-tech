# NUEVA AI STUDIO — by NUEVA TECHNOLOGY

AI advertising studio for African entrepreneurs (French / English), with a live analytics dashboard.

## Run it

```bash
npm install
npm run dev        # development server (http://localhost:5173)
npm run build      # production build → dist/index.html (single file, works offline)
npm run preview    # preview the production build
```

No account, no paid service and no API key is needed. The app runs in a clearly labelled **Demo mode**
(smart templates generated locally on the device).

## Features

| Area | What it does |
| --- | --- |
| Ad text generator | 3 creative angles: headline, ad text, call to action, short WhatsApp/SMS version |
| Video prompt generator | Realistic AI-video prompts (EN), shot list, voice-over (FR/EN), on-screen text, negative prompt |
| Product descriptions | Clothing, electronics, beauty, food, home, other — SEO title, copy, bullets, specs, keywords |
| Social content | TikTok (hook + timed script), Facebook posts, WhatsApp broadcast/status/auto-reply |
| Copy buttons | Per section and “Copy all” per option (with legacy-WebView fallback) |
| History | Saved in `localStorage`, searchable, favourites, reuse brief, export JSON, delete / clear |
| Analytics dashboard | KPI cards with trends, line / bar / donut charts, sortable + filterable table, date-range and segment filters, CSV export |
| Theme & language | Dark/light mode and FR/EN switch, both persisted |

## Connecting a real AI model (optional, secure)

Never put an API key in the browser. Instead run a tiny proxy on your own server that holds the key, then paste
its URL in **Settings → AI connection** (or set `VITE_AI_PROXY_URL` at build time).

The app sends `POST` with JSON:

```json
{ "tool": "ads", "language": "fr", "inputs": { "name": "…", "desc": "…" }, "prompt": "…ready-made LLM prompt…" }
```

and accepts either `{ "text": "…" }` or
`{ "variants": [{ "title": "…", "sections": [{ "label": "…", "text": "…" }] }] }`.

If the endpoint fails, the user sees a clear error with **Retry** and **Use demo mode instead**.

## Project structure

```
src/
  App.tsx                    router + providers
  context/AppContext.tsx     language, theme, hash routing, history, toasts
  i18n/translations.ts       FR / EN dictionary
  lib/
    tools.ts                 form definitions for the 4 generators
    generators/              demo engine (ads, video, product, social) + secure proxy client
    analytics/               seeded sample data, aggregation, filters
  components/
    layout/                  responsive shell (sidebar on desktop, bottom nav on mobile)
    studio/                  generator page + result cards
    dashboard/               filters, KPI cards, data table, dashboard page
    charts/                  SVG line / bar / donut / sparkline (no chart library)
    history/  settings/  ui/
```
