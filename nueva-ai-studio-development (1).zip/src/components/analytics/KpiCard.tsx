import { cn } from "../../utils/cn";
import { Icon } from "../Icon";

export function KpiCard({
  title,
  value,
  delta,
  icon,
  hint,
  index = 0,
}: {
  title: string;
  value: string;
  /** Percentage change vs the previous period (e.g. 12.4 means +12.4%). */
  delta: number;
  icon: string;
  hint: string;
  index?: number;
}) {
  const up = delta >= 0;
  return (
    <div
      className="card animate-fade-up p-4 sm:p-5"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-medium uppercase tracking-wider text-slate-500 dark:text-slate-400">
          {title}
        </span>
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-electric-500/10 text-electric-500 dark:text-electric-300">
          <Icon name={icon} className="h-4 w-4" />
        </span>
      </div>
      <p className="mt-2 text-2xl font-bold tracking-tight sm:text-3xl">{value}</p>
      <p
        className={cn(
          "mt-1 flex items-center gap-1 text-xs font-medium",
          up ? "text-emerald-500" : "text-rose-500"
        )}
      >
        <Icon name={up ? "trendUp" : "trendDown"} className="h-3.5 w-3.5" />
        {up ? "+" : "−"}
        {Math.abs(delta).toFixed(1)}%
        <span className="font-normal text-slate-400 dark:text-slate-500">{hint}</span>
      </p>
    </div>
  );
}
