import type { Lang, Values, Variant } from '../../types';
import { buildCtx, colon, ctaLine, offerLine, shorten, upper1, type Ctx } from './helpers';

/* -------------------------------------------------------------------------- */
/*  TikTok                                                                     */
/* -------------------------------------------------------------------------- */
function tiktok(c: Ctx): Variant[] {
  const fr = c.fr;
  const cta = ctaLine(c);
  const L = fr
    ? { hook: 'Accroche (3 premières secondes)', script: 'Script minuté', caption: 'Légende', tags: 'Hashtags' }
    : { hook: 'Hook (first 3 seconds)', script: 'Timed script', caption: 'Caption', tags: 'Hashtags' };

  const tags = [
    ...c.tags,
    '#TikTokAfrica',
    fr ? '#pourtoi' : '#foryou',
    '#fyp',
    fr ? '#entrepreneurafricain' : '#africanentrepreneur',
    fr ? '#petitesentreprises' : '#smallbusiness',
  ].join(' ');

  const angles = fr
    ? [
        {
          title: 'POV',
          hook: `POV : tu viens de découvrir ${c.name} 👀`,
          script: [
            `0–3 s | Accroche : gros plan sur ${c.name}, texte à l’écran « POV ».`,
            `3–8 s | Montrez le bénéfice clé : ${c.descShort}.`,
            `8–13 s | Réactions rapides ou cas d’usage (${c.audience}) ${c.where}.`,
            `13–15 s | Appel à l’action : ${cta}`,
          ],
        },
        {
          title: 'Avant / après',
          hook: `Avant / après ${c.name}… attends la fin 😳`,
          script: [
            '0–3 s | Écran partagé « avant » : montrez le problème du quotidien.',
            `3–8 s | Révélation : ${c.name}, ${c.descShort}.`,
            '8–13 s | Résultat « après » avec un client souriant.',
            `13–15 s | Appel à l’action : ${cta}`,
          ],
        },
        {
          title: 'Dans les coulisses',
          hook: `Dans les coulisses de ${c.name} : l’étape 3 va te surprendre`,
          script: [
            '0–3 s | Accroche en voix off sur un time-lapse de la préparation.',
            '3–8 s | Montrez les mains, les outils et les étapes 1 à 2.',
            `8–13 s | Étape 3 : révélation du produit fini, ${c.name}.`,
            `13–15 s | Appel à l’action : ${cta}`,
          ],
        },
      ]
    : [
        {
          title: 'POV',
          hook: `POV: you just discovered ${c.name} 👀`,
          script: [
            `0–3s | Hook: close-up of ${c.name} with on-screen text "POV".`,
            `3–8s | Show the key benefit: ${c.descShort}.`,
            `8–13s | Quick reactions or a use case (${c.audience}) ${c.where}.`,
            `13–15s | Call to action: ${cta}`,
          ],
        },
        {
          title: 'Before / after',
          hook: `Before vs after ${c.name}… wait for it 😳`,
          script: [
            '0–3s | Split-screen "before": show the everyday problem.',
            `3–8s | The reveal: ${c.name}, ${c.descShort}.`,
            '8–13s | The "after" result with a happy customer.',
            `13–15s | Call to action: ${cta}`,
          ],
        },
        {
          title: 'Behind the scenes',
          hook: `Behind the scenes at ${c.name}: step 3 will surprise you`,
          script: [
            '0–3s | Hook line as voice-over on a time-lapse of preparation.',
            '3–8s | Show hands, tools and steps 1–2.',
            `8–13s | Step 3: reveal the finished product, ${c.name}.`,
            `13–15s | Call to action: ${cta}`,
          ],
        },
      ];

  return angles.map((a, i) => ({
    title: a.title,
    sections: [
      { label: L.hook, text: a.hook },
      { label: L.script, text: a.script.join('\n') },
      { label: L.caption, text: `${a.hook} ${c.e(i)} ${upper1(c.descShort)}. ${cta}` },
      { label: L.tags, text: tags },
    ],
  }));
}

/* -------------------------------------------------------------------------- */
/*  Facebook                                                                   */
/* -------------------------------------------------------------------------- */
function facebook(c: Ctx): Variant[] {
  const fr = c.fr;
  const cta = ctaLine(c);
  const offer = offerLine(c);
  const sep = colon(c);
  const L = fr
    ? { post: 'Publication', tags: 'Hashtags', visual: 'Visuel conseillé' }
    : { post: 'Post', tags: 'Hashtags', visual: 'Suggested visual' };
  const tags = [...c.tags, fr ? '#entrepreneuriat' : '#entrepreneurship', fr ? '#boninplan' : '#shoplocal'].slice(0, 5).join(' ');

  const story = fr
    ? [
        `${c.e(0)} ${c.opener} ${c.name} !`,
        `${upper1(c.desc)}. Nous l’avons créé pour ${c.audience} ${c.where} : des personnes qui veulent de la qualité sans stress.`,
        offer,
        cta,
      ]
    : [
        `${c.e(0)} ${c.opener} ${c.name}!`,
        `${upper1(c.desc)}. We created it for ${c.audience} ${c.where}: people who want quality without the stress.`,
        offer,
        cta,
      ];

  const promo = fr
    ? [
        `${c.e(1)} ${c.offer ? `${c.offer} !` : 'Nouveau en stock !'} ${c.name}`,
        `${upper1(c.desc)}.`,
        `✔ Une qualité en laquelle vous pouvez avoir confiance\n✔ Un service rapide et chaleureux ${c.where}\n✔ Commande facile par message`,
        cta,
      ]
    : [
        `${c.e(1)} ${c.offer ? `${c.offer}!` : 'New in stock!'} ${c.name}`,
        `${upper1(c.desc)}.`,
        `✔ Quality you can trust\n✔ Fast, friendly service ${c.where}\n✔ Easy ordering by message`,
        cta,
      ];

  const question = fr
    ? [
        `${c.e(2)} Petite question pour ${c.audience} ${c.where} : qu’est-ce qui compte le plus quand on achète ${c.descShort} ?`,
        'A) La qualité   B) Le prix   C) La livraison rapide',
        `Répondez en commentaire 👇 et découvrez ${c.name}${sep} ${c.desc}.`,
        cta,
      ]
    : [
        `${c.e(2)} Quick question for ${c.audience} ${c.where}: what matters most when you buy ${c.descShort}?`,
        'A) Quality   B) Price   C) Fast delivery',
        `Tell us in the comments 👇 and discover ${c.name}${sep} ${c.desc}.`,
        cta,
      ];

  const visuals = fr
    ? [
        'Une photo lumineuse du produit avec une vraie personne ; ajoutez le nom en surimpression.',
        'Un visuel simple avec l’offre en grand et le produit au centre (format 1:1).',
        'Un carrousel ou une image avec les options A / B / C bien lisibles.',
      ]
    : [
        'A bright photo of the product with a real person; add the name as a text overlay.',
        'A clean visual with the offer in large type and the product centred (1:1 format).',
        'A carousel or image showing options A / B / C clearly.',
      ];

  const titles = fr ? ['Publication « histoire »', 'Publication promo', 'Question d’engagement'] : ['Story post', 'Promo post', 'Engagement question'];
  const posts = [story, promo, question];

  return posts.map((p, i) => ({
    title: titles[i],
    sections: [
      { label: L.post, text: p.filter(Boolean).join('\n\n') },
      { label: L.tags, text: tags },
      { label: L.visual, text: visuals[i] },
    ],
  }));
}

/* -------------------------------------------------------------------------- */
/*  WhatsApp                                                                   */
/* -------------------------------------------------------------------------- */
function whatsapp(c: Ctx): Variant[] {
  const fr = c.fr;
  const cta = ctaLine(c);
  const sep = colon(c);
  const contactBit = c.contact ? (fr ? `Écrivez-nous : ${c.contact}` : `Message us: ${c.contact}`) : fr ? 'Écrivez-nous !' : 'Message us!';

  const broadcast = fr
    ? `${c.e(0)} *${c.name}*\n\n${upper1(c.desc)}.\n\n${c.offer ? `🎁 ${c.offer}\n\n` : ''}${cta}\n\nRépondez *CATALOGUE* pour recevoir notre liste complète.`
    : `${c.e(0)} *${c.name}*\n\n${upper1(c.desc)}.\n\n${c.offer ? `🎁 ${c.offer}\n\n` : ''}${cta}\n\nReply *CATALOGUE* to receive our full list.`;

  const promo = fr
    ? `${c.e(1)} *${c.offer || 'Offre spéciale'}* | ${c.name}\n\n${upper1(c.desc)}.\n\n⏰ Dans la limite des stocks disponibles.\n${cta}`
    : `${c.e(1)} *${c.offer || 'Special offer'}* | ${c.name}\n\n${upper1(c.desc)}.\n\n⏰ While stocks last.\n${cta}`;

  const followUp = fr
    ? `Bonjour ! 👋 C’est ${c.name}. Vous vous êtes intéressé(e) à ${c.descShort}. Souhaitez-vous que nous vous en réservions un(e) ? Répondez simplement *OUI* et nous nous occupons du reste ${c.e(2)}`
    : `Hello! 👋 This is ${c.name}. You showed interest in ${c.descShort}. Would you like us to reserve one for you? Simply reply *YES* and we will take care of the rest ${c.e(2)}`;

  const autoReply = fr
    ? `Merci pour votre intérêt ! 😊 ${c.name}${sep} ${c.desc}. Prix : [indiquez votre prix]. Livraison ${c.where} : [précisez délai et frais]. Souhaitez-vous que je vous en réserve un(e) ?`
    : `Thank you for your interest! 😊 ${c.name}${sep} ${c.desc}. Price: [add your price]. Delivery ${c.where}: [add timing and fees]. Shall I reserve one for you?`;

  const status = (i: number) =>
    `${c.e(i)} ${c.name} — ${shorten(c.descShort, 60)}. ${c.offer ? `${c.offer}. ` : ''}${contactBit}`;

  const L = fr
    ? { msg: 'Message de diffusion', status: 'Texte de statut (court)', follow: 'Message de relance', reply: 'Réponse automatique « C’est combien ? »' }
    : { msg: 'Broadcast message', status: 'Status text (short)', follow: 'Follow-up message', reply: 'Auto-reply: “How much?”' };

  return [
    {
      title: fr ? 'Annonce / catalogue' : 'Announcement / catalogue',
      sections: [
        { label: L.msg, text: broadcast },
        { label: L.status, text: status(0) },
      ],
    },
    {
      title: fr ? 'Promotion' : 'Promotion',
      sections: [
        { label: L.msg, text: promo },
        { label: L.status, text: status(1) },
      ],
    },
    {
      title: fr ? 'Relance client' : 'Customer follow-up',
      sections: [
        { label: L.follow, text: followUp },
        { label: L.reply, text: autoReply },
      ],
    },
  ];
}

export function generateSocial(v: Values, lang: Lang): Variant[] {
  const c = buildCtx(v, lang);
  switch (v.platform) {
    case 'facebook':
      return facebook(c);
    case 'whatsapp':
      return whatsapp(c);
    default:
      return tiktok(c);
  }
}
