import type { L10n, MarketId, PlatformId, ContentType } from '../types';

export interface Market {
  id: MarketId;
  code: string;
  city: string;
  name: L10n;
}

export const MARKETS: Market[] = [
  { id: 'sn', code: 'SN', city: 'Dakar', name: { en: 'Senegal', fr: 'Sénégal' } },
  { id: 'ci', code: 'CI', city: 'Abidjan', name: { en: "Côte d'Ivoire", fr: "Côte d'Ivoire" } },
  { id: 'ng', code: 'NG', city: 'Lagos', name: { en: 'Nigeria', fr: 'Nigéria' } },
  { id: 'gh', code: 'GH', city: 'Accra', name: { en: 'Ghana', fr: 'Ghana' } },
  { id: 'ke', code: 'KE', city: 'Nairobi', name: { en: 'Kenya', fr: 'Kenya' } },
  { id: 'cm', code: 'CM', city: 'Douala', name: { en: 'Cameroon', fr: 'Cameroun' } },
  { id: 'za', code: 'ZA', city: 'Johannesburg', name: { en: 'South Africa', fr: 'Afrique du Sud' } },
  { id: 'ma', code: 'MA', city: 'Casablanca', name: { en: 'Morocco', fr: 'Maroc' } },
];

export const marketById = (id: string): Market | undefined => MARKETS.find((m) => m.id === id);

export const CONTENT_TYPES: ContentType[] = ['ads', 'video', 'product', 'social'];
export const PLATFORMS: PlatformId[] = ['tiktok', 'facebook', 'whatsapp'];

/** Brand-consistent palette (electric blue family + cyan + violet + mint) */
export const TYPE_COLORS: Record<ContentType, string> = {
  ads: '#2f7bff',
  video: '#22d3ee',
  product: '#8b7bff',
  social: '#34d9a5',
};

export const PLATFORM_COLORS: Record<PlatformId, string> = {
  tiktok: '#22d3ee',
  facebook: '#2f7bff',
  whatsapp: '#34d9a5',
};
