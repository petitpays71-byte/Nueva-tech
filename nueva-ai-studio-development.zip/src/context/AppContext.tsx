import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { CheckCircle2, Info, XCircle } from 'lucide-react';
import type { AppSettings, HistoryItem, Lang, RouteId, Theme, ToolId, Values } from '../types';
import { translate, type TKey } from '../i18n/translations';
import { removeStorage, useLocalStorage } from '../lib/storage';

const ROUTES: RouteId[] = ['dashboard', 'ads', 'video', 'product', 'social', 'history', 'settings'];
const HISTORY_LIMIT = 100;

function parseHash(): RouteId {
  const h = window.location.hash.replace(/^#\/?/, '');
  return (ROUTES.includes(h as RouteId) ? h : 'dashboard') as RouteId;
}

const initialLang = (): Lang => (typeof navigator !== 'undefined' && navigator.language?.toLowerCase().startsWith('fr') ? 'fr' : 'en');

const envProxy = (): string => {
  const env = (import.meta as unknown as { env?: Record<string, string | undefined> }).env;
  return env?.VITE_AI_PROXY_URL?.trim() ?? '';
};

type ToastKind = 'success' | 'error' | 'info';
interface ToastItem {
  id: number;
  msg: string;
  kind: ToastKind;
}

interface AppContextValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  theme: Theme;
  setTheme: (t: Theme) => void;
  toggleTheme: () => void;
  t: (key: TKey, vars?: Record<string, string | number>) => string;

  route: RouteId;
  navigate: (r: RouteId) => void;

  history: HistoryItem[];
  addHistory: (item: HistoryItem) => void;
  toggleFavorite: (id: string) => void;
  removeHistory: (id: string) => void;
  clearHistory: () => void;

  settings: AppSettings;
  setSettings: (s: AppSettings) => void;
  proxyUrl: string;
  aiConfigured: boolean;

  drafts: Partial<Record<ToolId, Values>>;
  setDraft: (tool: ToolId, values: Values) => void;
  latest: Partial<Record<ToolId, HistoryItem | null>>;
  setLatest: (tool: ToolId, item: HistoryItem | null) => void;
  reuse: (item: HistoryItem) => void;

  notify: (msg: string, kind?: ToastKind) => void;
  eraseAll: () => void;
}

const Ctx = createContext<AppContextValue | null>(null);

export function useApp(): AppContextValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useApp must be used inside <AppProvider>');
  return v;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useLocalStorage<Lang>('nueva.lang', initialLang());
  const [theme, setTheme] = useLocalStorage<Theme>('nueva.theme', 'dark');
  const [history, setHistory] = useLocalStorage<HistoryItem[]>('nueva.history', []);
  const [settings, setSettingsState] = useLocalStorage<AppSettings>('nueva.settings', { proxyUrl: '' });
  const [route, setRoute] = useState<RouteId>(parseHash);
  const [drafts, setDrafts] = useState<Partial<Record<ToolId, Values>>>({});
  const [latest, setLatestState] = useState<Partial<Record<ToolId, HistoryItem | null>>>({});
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const toastId = useRef(0);

  /* ---- theme + language side effects ---- */
  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'dark' ? '#050b1f' : '#f2f6fd');
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  /* ---- hash routing (keeps the Android back button useful) ---- */
  useEffect(() => {
    const onHash = () => {
      setRoute(parseHash());
      window.scrollTo({ top: 0 });
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  const navigate = useCallback((r: RouteId) => {
    if (window.location.hash !== `#/${r}`) window.location.hash = `/${r}`;
    else window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const setLang = useCallback(
    (l: Lang) => {
      setLangState(l);
      // output language follows the interface language for drafts already in progress
      setDrafts((d) => {
        const next: Partial<Record<ToolId, Values>> = {};
        (Object.keys(d) as ToolId[]).forEach((k) => {
          next[k] = { ...(d[k] as Values), outLang: l };
        });
        return next;
      });
    },
    [setLangState],
  );

  const t = useCallback((key: TKey, vars?: Record<string, string | number>) => translate(lang, key, vars), [lang]);

  const notify = useCallback((msg: string, kind: ToastKind = 'success') => {
    const id = ++toastId.current;
    setToasts((x) => [...x.slice(-2), { id, msg, kind }]);
    window.setTimeout(() => setToasts((x) => x.filter((i) => i.id !== id)), 2600);
  }, []);

  /* ---- history ---- */
  const addHistory = useCallback(
    (item: HistoryItem) => setHistory((h) => [item, ...h].slice(0, HISTORY_LIMIT)),
    [setHistory],
  );
  const toggleFavorite = useCallback(
    (id: string) => setHistory((h) => h.map((i) => (i.id === id ? { ...i, favorite: !i.favorite } : i))),
    [setHistory],
  );
  const removeHistory = useCallback((id: string) => setHistory((h) => h.filter((i) => i.id !== id)), [setHistory]);
  const clearHistory = useCallback(() => setHistory([]), [setHistory]);

  const setDraft = useCallback((tool: ToolId, values: Values) => setDrafts((d) => ({ ...d, [tool]: values })), []);
  const setLatest = useCallback((tool: ToolId, item: HistoryItem | null) => setLatestState((l) => ({ ...l, [tool]: item })), []);

  const reuse = useCallback(
    (item: HistoryItem) => {
      setDrafts((d) => ({ ...d, [item.tool]: { ...item.inputs } }));
      setLatestState((l) => ({ ...l, [item.tool]: item }));
      navigate(item.tool);
    },
    [navigate],
  );

  const setSettings = useCallback((s: AppSettings) => setSettingsState(s), [setSettingsState]);

  const eraseAll = useCallback(() => {
    setHistory([]);
    setSettingsState({ proxyUrl: '' });
    setDrafts({});
    setLatestState({});
    removeStorage('nueva.history');
    removeStorage('nueva.settings');
  }, [setHistory, setSettingsState]);

  const proxyUrl = settings.proxyUrl || envProxy();

  const value = useMemo<AppContextValue>(
    () => ({
      lang,
      setLang,
      theme,
      setTheme,
      toggleTheme: () => setTheme(theme === 'dark' ? 'light' : 'dark'),
      t,
      route,
      navigate,
      history,
      addHistory,
      toggleFavorite,
      removeHistory,
      clearHistory,
      settings,
      setSettings,
      proxyUrl,
      aiConfigured: !!proxyUrl,
      drafts,
      setDraft,
      latest,
      setLatest,
      reuse,
      notify,
      eraseAll,
    }),
    [lang, setLang, theme, setTheme, t, route, navigate, history, addHistory, toggleFavorite, removeHistory, clearHistory, settings, setSettings, proxyUrl, drafts, setDraft, latest, setLatest, reuse, notify, eraseAll],
  );

  return (
    <Ctx.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-24 z-[100] lg:bottom-8" aria-live="polite">
        {toasts.map((x, i) => (
          <div
            key={x.id}
            style={{ animation: 'toast-in .28s ease both', bottom: `${i * 56}px` }}
            className="pointer-events-auto absolute left-1/2 flex max-w-[92vw] items-center gap-2 rounded-xl border border-line bg-surface px-4 py-2.5 text-sm font-medium text-ink shadow-xl"
          >
            {x.kind === 'success' && <CheckCircle2 size={16} className="shrink-0 text-emerald-500" />}
            {x.kind === 'error' && <XCircle size={16} className="shrink-0 text-rose-500" />}
            {x.kind === 'info' && <Info size={16} className="shrink-0 text-brand" />}
            <span>{x.msg}</span>
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}
