import type { Lang } from '../types';

const DAY_MS = 86_400_000;

export const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36);

export function fmtCompact(n: number, lang: Lang): string {
  return new Intl.NumberFormat(lang, {
    notation: 'compact',
    maximumFractionDigits: Math.abs(n) < 1000 ? 0 : 1,
  }).format(n);
}

export function fmtInt(n: number, lang: Lang): string {
  return new Intl.NumberFormat(lang, { maximumFractionDigits: 0 }).format(n);
}

export function fmtCurrency(n: number, lang: Lang, compact = true): string {
  return new Intl.NumberFormat(lang, {
    style: 'currency',
    currency: 'USD',
    notation: compact ? 'compact' : 'standard',
    maximumFractionDigits: compact ? 1 : 0,
  }).format(n);
}

export function fmtPercent(n: number, lang: Lang, digits = 1): string {
  return new Intl.NumberFormat(lang, { style: 'percent', maximumFractionDigits: digits, minimumFractionDigits: digits }).format(n);
}

export function fmtSigned(n: number, lang: Lang, digits = 1): string {
  const s = new Intl.NumberFormat(lang, { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(Math.abs(n));
  return `${n >= 0 ? '+' : '−'}${s}%`;
}

/* ---------------- Day helpers (UTC day numbers built from local date) ---------------- */
export function todayDay(): number {
  const d = new Date();
  return Math.round(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / DAY_MS);
}

export function dayToISO(day: number): string {
  return new Date(day * DAY_MS).toISOString().slice(0, 10);
}

export function isoToDay(iso: string): number {
  const [y, m, d] = iso.split('-').map(Number);
  return Math.round(Date.UTC(y, (m || 1) - 1, d || 1) / DAY_MS);
}

export function dayOfWeek(day: number): number {
  return new Date(day * DAY_MS).getUTCDay();
}

export function fmtDay(day: number, lang: Lang, withYear = false): string {
  return new Intl.DateTimeFormat(lang, {
    day: 'numeric',
    month: 'short',
    year: withYear ? 'numeric' : undefined,
    timeZone: 'UTC',
  }).format(new Date(day * DAY_MS));
}

export function fmtDateTime(ts: number, lang: Lang): string {
  return new Intl.DateTimeFormat(lang, {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(ts));
}

export function relativeTime(ts: number, lang: Lang): string {
  const diff = Math.round((ts - Date.now()) / 1000);
  const rtf = new Intl.RelativeTimeFormat(lang, { numeric: 'auto' });
  const abs = Math.abs(diff);
  if (abs < 60) return rtf.format(Math.round(diff), 'second');
  if (abs < 3600) return rtf.format(Math.round(diff / 60), 'minute');
  if (abs < 86400) return rtf.format(Math.round(diff / 3600), 'hour');
  if (abs < 86400 * 30) return rtf.format(Math.round(diff / 86400), 'day');
  return fmtDateTime(ts, lang);
}

export function trunc(s: string, n: number): string {
  if (s.length <= n) return s;
  return s.slice(0, n).replace(/\s+\S*$/, '') + '…';
}

export function downloadFile(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 500);
}
