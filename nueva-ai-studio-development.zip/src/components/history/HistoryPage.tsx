import { useMemo, useState } from 'react';
import { ChevronDown, Download, History as HistoryIcon, RotateCcw, Search, Star, Trash2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import type { ToolId } from '../../types';
import type { TKey } from '../../i18n/translations';
import { TOOLS, TOOL_ORDER } from '../../lib/tools';
import { downloadFile, relativeTime } from '../../lib/format';
import { ResultCard } from '../studio/ResultCard';
import { cn } from '../../utils/cn';

type Filter = 'all' | 'fav' | ToolId;

export function HistoryPage() {
  const { t, lang, history, toggleFavorite, removeHistory, clearHistory, reuse, navigate, notify } = useApp();
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [open, setOpen] = useState<string | null>(null);
  const [confirm, setConfirm] = useState(false);

  const items = useMemo(() => {
    const s = q.trim().toLowerCase();
    return history.filter((h) => {
      if (filter === 'fav' && !h.favorite) return false;
      if (filter !== 'all' && filter !== 'fav' && h.tool !== filter) return false;
      if (!s) return true;
      const hay = `${h.summary} ${h.variants.map((v) => v.title + ' ' + v.sections.map((x) => x.text).join(' ')).join(' ')}`.toLowerCase();
      return hay.includes(s);
    });
  }, [history, q, filter]);

  if (history.length === 0) {
    return (
      <div className="mx-auto max-w-xl">
        <div className="card grid place-items-center px-6 py-16 text-center">
          <span className="mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-brand/12 text-brand">
            <HistoryIcon size={30} />
          </span>
          <h2 className="font-display text-xl font-bold text-ink">{t('hist.empty')}</h2>
          <p className="mt-2 max-w-sm text-sm text-muted">{t('hist.emptyBody')}</p>
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            {TOOL_ORDER.map((id) => {
              const Icon = TOOLS[id].icon;
              return (
                <button key={id} type="button" className="btn btn-ghost btn-sm" onClick={() => navigate(id)}>
                  <Icon size={14} /> {t(`nav.${id}` as TKey)}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold tracking-tight text-ink sm:text-2xl">{t('hist.title')}</h2>
          <p className="mt-1 text-sm text-muted">
            {t('hist.subtitle')} · <span className="font-semibold">{t('hist.count', { n: history.length })}</span>
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            className="btn btn-ghost btn-sm"
            onClick={() => downloadFile('nueva-history.json', JSON.stringify(history, null, 2), 'application/json')}
          >
            <Download size={14} /> {t('hist.exportJson')}
          </button>
          {confirm ? (
            <div className="flex items-center gap-2 rounded-xl border border-rose-500/40 bg-rose-500/10 px-2 py-1">
              <span className="text-xs font-semibold text-rose-500">{t('hist.confirm')}</span>
              <button
                type="button"
                className="btn btn-danger btn-sm"
                onClick={() => {
                  clearHistory();
                  setConfirm(false);
                  notify(t('hist.cleared'));
                }}
              >
                {t('hist.confirmYes')}
              </button>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => setConfirm(false)}>
                {t('common.cancel')}
              </button>
            </div>
          ) : (
            <button type="button" className="btn btn-danger btn-sm" onClick={() => setConfirm(true)}>
              <Trash2 size={14} /> {t('hist.clearAll')}
            </button>
          )}
        </div>
      </div>

      <div className="card space-y-3 p-3 sm:p-4">
        <div className="relative">
          <Search size={15} className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-muted" />
          <input className="input !pl-9" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('hist.search')} aria-label={t('hist.search')} />
        </div>
        <div className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1">
          <button type="button" className="chip" data-active={filter === 'all'} onClick={() => setFilter('all')}>
            {t('common.all')}
          </button>
          <button type="button" className="chip" data-active={filter === 'fav'} onClick={() => setFilter('fav')}>
            <Star size={12} /> {t('hist.favorites')}
          </button>
          {TOOL_ORDER.map((id) => {
            const Icon = TOOLS[id].icon;
            return (
              <button key={id} type="button" className="chip" data-active={filter === id} onClick={() => setFilter(id)}>
                <Icon size={12} /> {t(`nav.s.${id}` as TKey)}
              </button>
            );
          })}
        </div>
      </div>

      {items.length === 0 ? (
        <div className="card px-6 py-12 text-center text-sm text-muted">{t('hist.noMatch')}</div>
      ) : (
        <ul className="space-y-3">
          {items.map((h) => {
            const Icon = TOOLS[h.tool].icon;
            const isOpen = open === h.id;
            return (
              <li key={h.id} className="card animate-fade-up overflow-hidden">
                <div className="flex items-center gap-3 p-3 sm:p-4">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand/12 text-brand">
                    <Icon size={20} />
                  </span>
                  <button type="button" className="min-w-0 flex-1 cursor-pointer text-left" onClick={() => setOpen(isOpen ? null : h.id)} aria-expanded={isOpen}>
                    <div className="truncate text-sm font-bold text-ink">{h.summary}</div>
                    <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-muted">
                      <span>{t(`nav.${h.tool}` as TKey)}</span>
                      <span>· {relativeTime(h.createdAt, lang)}</span>
                      <span className="uppercase">· {h.lang}</span>
                      <span className={cn('rounded-full px-1.5 py-0.5 text-[10px] font-bold uppercase', h.mode === 'ai' ? 'bg-emerald-500/15 text-emerald-500' : 'bg-amber-500/15 text-amber-500')}>
                        {h.mode === 'ai' ? t('mode.ai') : t('mode.demo')}
                      </span>
                    </div>
                  </button>
                  <div className="flex shrink-0 items-center gap-1">
                    <button
                      type="button"
                      onClick={() => toggleFavorite(h.id)}
                      aria-label={t('common.favorite')}
                      aria-pressed={h.favorite}
                      className={cn('grid h-9 w-9 cursor-pointer place-items-center rounded-lg transition hover:bg-surface2', h.favorite ? 'text-amber-400' : 'text-muted')}
                    >
                      <Star size={17} fill={h.favorite ? 'currentColor' : 'none'} />
                    </button>
                    <button
                      type="button"
                      onClick={() => reuse(h)}
                      aria-label={t('common.reuse')}
                      title={t('common.reuse')}
                      className="grid h-9 w-9 cursor-pointer place-items-center rounded-lg text-muted transition hover:bg-surface2 hover:text-brand"
                    >
                      <RotateCcw size={16} />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        removeHistory(h.id);
                        notify(t('hist.deleted'), 'info');
                      }}
                      aria-label={t('common.delete')}
                      title={t('common.delete')}
                      className="grid h-9 w-9 cursor-pointer place-items-center rounded-lg text-muted transition hover:bg-rose-500/10 hover:text-rose-500"
                    >
                      <Trash2 size={16} />
                    </button>
                    <button
                      type="button"
                      onClick={() => setOpen(isOpen ? null : h.id)}
                      aria-label={isOpen ? t('hist.hide') : t('hist.show')}
                      className="grid h-9 w-9 cursor-pointer place-items-center rounded-lg text-muted transition hover:bg-surface2"
                    >
                      <ChevronDown size={18} className={cn('transition-transform', isOpen && 'rotate-180')} />
                    </button>
                  </div>
                </div>
                {isOpen && (
                  <div className="space-y-3 border-t border-line bg-bg/40 p-3 sm:p-4">
                    {h.variants.map((v, i) => (
                      <ResultCard key={i} variant={v} index={i} animate={false} />
                    ))}
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
