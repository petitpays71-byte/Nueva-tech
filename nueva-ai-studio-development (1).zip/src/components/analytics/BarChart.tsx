import { formatCurrency } from "../../utils/format";

export interface BarItem {
  label: string;
  value: number;
}

export function BarChart({ data, locale }: { data: BarItem[]; locale: string }) {
  if (data.length === 0) {
    return <div className="flex h-56 items-center justify-center text-sm text-slate-500">—</div>;
  }
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <div>
      <div className="flex h-56 items-end gap-3 sm:gap-4">
        {data.map((d, i) => {
          const pct = (d.value / max) * 100;
          return (
            <div key={d.label} className="group relative flex h-full flex-1 flex-col justify-end">
              <span
                className="pointer-events-none absolute left-1/2 z-10 -translate-x-1/2 whitespace-nowrap rounded-md bg-navy-900 px-2 py-1 text-[11px] font-medium text-white opacity-0 shadow-md transition-opacity duration-200 group-hover:opacity-100 dark:bg-electric-500"
                style={{ bottom: `calc(${pct}% + 8px)` }}
              >
                {formatCurrency(d.value, locale)}
              </span>
              <div
                className="animate-grow w-full rounded-t-lg bg-gradient-to-t from-electric-600 via-electric-500 to-electric-300 shadow-[0_0_24px_-8px_rgba(56,189,248,0.8)] transition-[filter] duration-300 group-hover:brightness-110"
                style={{ height: `${pct}%`, animationDelay: `${i * 80}ms` }}
              />
            </div>
          );
        })}
      </div>
      <div className="mt-2 flex gap-3 sm:gap-4">
        {data.map((d) => (
          <div
            key={d.label}
            className="flex-1 truncate text-center text-[10px] text-slate-500 dark:text-slate-400 sm:text-xs"
          >
            {d.label}
          </div>
        ))}
      </div>
    </div>
  );
}
