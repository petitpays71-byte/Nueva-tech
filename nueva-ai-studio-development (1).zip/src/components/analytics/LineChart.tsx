import { useState } from "react";
import { formatCompact, formatCurrency } from "../../utils/format";

export interface LinePoint {
  label: string;
  revenue: number;
  spend: number;
}

const W = 640;
const H = 260;
const LEFT = 48;
const RIGHT = 10;
const TOP = 12;
const BOTTOM = 28;

export function LineChart({
  data,
  locale,
  labels,
}: {
  data: LinePoint[];
  locale: string;
  labels: { revenue: string; spend: string };
}) {
  const [hover, setHover] = useState<number | null>(null);

  if (data.length === 0) {
    return (
      <div className="flex h-56 items-center justify-center text-sm text-slate-500">—</div>
    );
  }

  const max = Math.max(...data.flatMap((d) => [d.revenue, d.spend]), 1) * 1.12;
  const x = (i: number) =>
    data.length === 1
      ? LEFT + (W - LEFT - RIGHT) / 2
      : LEFT + (i * (W - LEFT - RIGHT)) / (data.length - 1);
  const y = (v: number) => H - BOTTOM - (v / max) * (H - BOTTOM - TOP);
  const path = (key: "revenue" | "spend") =>
    data.map((d, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(d[key]).toFixed(1)}`).join(" ");
  const area = `${path("revenue")} L${x(data.length - 1).toFixed(1)},${H - BOTTOM} L${x(0).toFixed(1)},${H - BOTTOM} Z`;
  const ticks = [0, 0.33, 0.66, 1].map((f) => ({
    v: max * f,
    y: H - BOTTOM - f * (H - BOTTOM - TOP),
  }));
  const labelEvery = Math.ceil(data.length / 7);
  const animKey = data.map((d) => d.label).join("|");

  const hoverX = hover !== null ? x(hover) : 0;
  const hoverY = hover !== null ? y(data[hover].revenue) : 0;
  const tooltipBelow = hoverY < 80;

  return (
    <div>
      <div className="mb-2 flex items-center gap-4 text-xs">
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-electric-400" />
          {labels.revenue}
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-slate-400" />
          {labels.spend}
        </span>
      </div>
      <div className="relative">
        <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img">
          <defs>
            <linearGradient id="nuevaArea" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#38bdf8" stopOpacity="0" />
            </linearGradient>
          </defs>
          {ticks.map((tk, i) => (
            <g key={i}>
              <line
                x1={LEFT - 4}
                x2={W - RIGHT}
                y1={tk.y}
                y2={tk.y}
                className="stroke-slate-200 dark:stroke-navy-700"
                strokeDasharray="4 6"
                strokeWidth={1}
              />
              <text
                x={LEFT - 8}
                y={tk.y + 3}
                textAnchor="end"
                className="fill-slate-400"
                fontSize="9"
              >
                {formatCompact(tk.v, locale)}
              </text>
            </g>
          ))}
          <path d={area} fill="url(#nuevaArea)" />
          <path
            key={`spend-${animKey}`}
            d={path("spend")}
            pathLength={1}
            fill="none"
            stroke="#94a3b8"
            strokeWidth={2}
            strokeLinecap="round"
            className="draw-line"
            style={{ animationDelay: ".15s" }}
          />
          <path
            key={`revenue-${animKey}`}
            d={path("revenue")}
            pathLength={1}
            fill="none"
            stroke="#38bdf8"
            strokeWidth={2.5}
            strokeLinecap="round"
            className="draw-line"
          />
          {data.map((d, i) =>
            i % labelEvery === 0 ? (
              <text
                key={i}
                x={x(i)}
                y={H - 8}
                textAnchor="middle"
                className="fill-slate-400"
                fontSize="9"
              >
                {d.label}
              </text>
            ) : null
          )}
          {hover !== null && (
            <line
              x1={hoverX}
              x2={hoverX}
              y1={TOP}
              y2={H - BOTTOM}
              className="stroke-electric-400/50"
              strokeWidth={1}
              strokeDasharray="3 3"
            />
          )}
          {hover !== null && (
            <circle
              cx={hoverX}
              cy={hoverY}
              r={4.5}
              fill="#38bdf8"
              stroke="#ffffff"
              strokeWidth={1.5}
            />
          )}
          {data.map((d, i) => (
            <circle
              key={i}
              cx={x(i)}
              cy={y(d.revenue)}
              r={14}
              fill="transparent"
              onMouseEnter={() => setHover(i)}
              onMouseLeave={() => setHover(null)}
              onClick={() => setHover(hover === i ? null : i)}
            />
          ))}
        </svg>
        {hover !== null && (
          <div
            className="pointer-events-none absolute z-10 whitespace-nowrap rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs shadow-lg dark:border-navy-700 dark:bg-navy-800"
            style={{
              left: `${(hoverX / W) * 100}%`,
              top: `${(hoverY / H) * 100}%`,
              transform: tooltipBelow
                ? "translate(-50%, 16px)"
                : "translate(-50%, calc(-100% - 12px))",
            }}
          >
            <p className="font-semibold">{data[hover].label}</p>
            <p className="mt-0.5 flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-electric-400" />
              {labels.revenue}:{" "}
              <span className="font-medium">{formatCurrency(data[hover].revenue, locale)}</span>
            </p>
            <p className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-slate-400" />
              {labels.spend}:{" "}
              <span className="font-medium">{formatCurrency(data[hover].spend, locale)}</span>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
