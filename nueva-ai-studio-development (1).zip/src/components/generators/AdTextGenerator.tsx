import { useState } from "react";
import { useI18n } from "../../i18n";
import { useGenerator } from "../../hooks/useGenerator";
import { generateAdText } from "../../utils/demo";
import type { AdPlatform, Length, Tone } from "../../types";
import {
  Button,
  Field,
  GeneratorCard,
  GeneratorResult,
  Select,
  TextInput,
} from "../ui";
import { Icon } from "../Icon";

const TONES: Tone[] = ["persuasive", "friendly", "professional", "energetic", "humorous"];
const PLATFORMS: AdPlatform[] = ["tiktok", "facebook", "instagram", "whatsapp", "google"];
const LENGTHS: Length[] = ["short", "medium", "long"];

export function AdTextGenerator() {
  const { t, lang } = useI18n();
  const [product, setProduct] = useState("");
  const [audience, setAudience] = useState("");
  const [tone, setTone] = useState<Tone>("persuasive");
  const [platform, setPlatform] = useState<AdPlatform>("tiktok");
  const [length, setLength] = useState<Length>("medium");
  const [benefit, setBenefit] = useState("");
  const gen = useGenerator(lang, "adText", t("studio.adText.title"));

  const handleGenerate = () => {
    if (!product.trim()) {
      gen.setError("studio.errors.emptyProduct");
      return;
    }
    gen.generate(
      JSON.stringify([product, audience, tone, platform, length, benefit, lang]),
      () =>
        generateAdText({
          product: product.trim(),
          audience: audience.trim() || t("studio.adText.defaultAudience"),
          tone,
          platform,
          length,
          benefit: benefit.trim(),
          language: lang,
        })
    );
  };

  return (
    <GeneratorCard
      icon="megaphone"
      title={t("studio.adText.title")}
      desc={t("studio.adText.desc")}
    >
      <div className="space-y-3">
        <Field label={t("studio.adText.product")}>
          <TextInput
            value={product}
            onChange={(e) => setProduct(e.target.value)}
            placeholder={t("studio.adText.productPh")}
          />
        </Field>
        <Field label={`${t("studio.adText.audience")} (${t("common.optional")})`}>
          <TextInput
            value={audience}
            onChange={(e) => setAudience(e.target.value)}
            placeholder={t("studio.adText.audiencePh")}
          />
        </Field>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Select
            label={t("studio.adText.tone")}
            value={tone}
            onChange={(v) => setTone(v as Tone)}
            options={TONES.map((k) => ({ value: k, label: t(`studio.tones.${k}`) }))}
          />
          <Select
            label={t("studio.adText.platform")}
            value={platform}
            onChange={(v) => setPlatform(v as AdPlatform)}
            options={PLATFORMS.map((k) => ({ value: k, label: t(`studio.adPlatforms.${k}`) }))}
          />
          <Select
            label={t("studio.adText.length")}
            value={length}
            onChange={(v) => setLength(v as Length)}
            options={LENGTHS.map((k) => ({ value: k, label: t(`studio.lengths.${k}`) }))}
          />
        </div>
        <Field label={`${t("studio.adText.benefit")} (${t("common.optional")})`}>
          <TextInput
            value={benefit}
            onChange={(e) => setBenefit(e.target.value)}
            placeholder={t("studio.adText.benefitPh")}
          />
        </Field>
      </div>
      <div className="mt-auto space-y-2 pt-4">
        <Button onClick={handleGenerate} loading={gen.loading} className="w-full">
          <Icon name="sparkles" className="h-4 w-4" />
          {gen.result ? t("common.regenerate") : t("common.generate")}
        </Button>
        {gen.error && (
          <p className="flex items-center gap-1.5 text-sm text-rose-500">
            <Icon name="alert" className="h-4 w-4 shrink-0" />
            {t(gen.error)}
          </p>
        )}
        <GeneratorResult
          title={t("studio.adText.resultTitle")}
          result={gen.result}
          loading={gen.loading}
          onRegenerate={handleGenerate}
        />
      </div>
    </GeneratorCard>
  );
}
