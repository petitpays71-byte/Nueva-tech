import { useMemo, useState } from "react";
import { useI18n } from "../../i18n";
import { cn } from "../../utils/cn";
import { formatCompact, formatCurrency, formatPercent } from "../../utils/format";
import type { Campaign } from "../../data/sampleData";
import { Card, inputClass } from "../ui";
import { Icon } from "../Icon";

type SortKey =
  | "name"
  | "category"
  | "region"
  | "channel"
  | "impressions"
  | "clicks"
  | "ctr"
  | "conversions"
  | "revenue"
  | "spend"
  | "roas";

interface Row extends Campaign {
  ctr: number;
  roas: number;
}

const PAGE_SIZE = 8;
const TEXT_SORT_KEYS: SortKey[] = ["name", "category", "region", "channel"];

export function DataTable({ rows, locale }: { rows: Campaign[]; locale: string }) {
  const { t } = useI18n();
  const [sort, setSort] = useState<{ key: SortKey; dir: "asc" | "desc" }>({
    key: "revenue",
    dir: "desc",
  });
  const [page, setPage] = useState(1);
  const [query, setQuery] = useState("");

  const enriched = useMemo<Row[]>(
    () =>
      rows.map((r) => ({
        ...r,
        ctr: r.impressions > 0 ? r.clicks / r.impressions : 0,
        roas: r.spend > 0 ? r.revenue / r.spend : 0,
      })),
    [rows]
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return enriched;
    return enriched.filter((r) =>
      [
        r.name,
        t(`analytics.categories.${r.category}`),
        t(`analytics.regions.${r.region}`),
        t(`analytics.channels.${r.channel}`),
      ]
        .join(" ")
        .toLowerCase()
        .includes(q)
    );
  }, [enriched, query, t]);

  const sorted = useMemo(() => {
    const dir = sort.dir === "asc" ? 1 : -1;
    return [...filtered].sort((a, b) => {
      const va = a[sort.key];
      const vb = b[sort.key];
      if (typeof va === "number" && typeof vb === "number") return (va - vb) * dir;
      return String(va).localeCompare(String(vb)) * dir;
    });
  }, [filtered, sort]);

  const pages = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
  const currentPage = Math.min(page, pages);
  const pageRows = sorted.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const toggleSort = (key: SortKey) => {
    setSort((s) =>
      s.key === key
        ? { key, dir: s.dir === "asc" ? "desc" : "asc" }
        : { key, dir: TEXT_SORT_KEYS.includes(key) ? "asc" : "desc" }
    );
    setPage(1);
  };

  const columns: {
    key: SortKey;
    label: string;
    numeric?: boolean;
    format: (r: Row) => string;
  }[] = [
    { key: "name", label: t("analytics.columns.campaign"), format: (r) => r.name },
    {
      key: "category",
      label: t("analytics.columns.category"),
      format: (r) => t(`analytics.categories.${r.category}`),
    },
    {
      key: "region",
      label: t("analytics.columns.region"),
      format: (r) => t(`analytics.regions.${r.region}`),
    },
    {
      key: "channel",
      label: t("analytics.columns.channel"),
      format: (r) => t(`analytics.channels.${r.channel}`),
    },
    {
      key: "impressions",
      label: t("analytics.columns.impressions"),
      numeric: true,
      format: (r) => formatCompact(r.impressions, locale),
    },
    {
      key: "clicks",
      label: t("analytics.columns.clicks"),
      numeric: true,
      format: (r) => formatCompact(r.clicks, locale),
    },
    {
      key: "ctr",
      label: t("analytics.columns.ctr"),
      numeric: true,
      format: (r) => formatPercent(r.ctr, locale),
    },
    {
      key: "conversions",
      label: t("analytics.columns.conversions"),
      numeric: true,
      format: (r) => formatCompact(r.conversions, locale),
    },
    {
      key: "revenue",
      label: t("analytics.columns.revenue"),
      numeric: true,
      format: (r) => formatCurrency(r.revenue, locale),
    },
    {
      key: "spend",
      label: t("analytics.columns.spend"),
      numeric: true,
      format: (r) => formatCurrency(r.spend, locale),
    },
    {
      key: "roas",
      label: t("analytics.columns.roas"),
      numeric: true,
      format: (r) => `${r.roas.toFixed(2)}×`,
    },
  ];

  return (
    <Card className="p-4 sm:p-5">
      <div className="mb-4 flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="font-semibold">{t("analytics.table")}</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">{t("analytics.tableSub")}</p>
        </div>
        <div className="relative sm:w-64">
          <Icon
            name="search"
            className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
          />
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setPage(1);
            }}
            placeholder={t("common.search")}
            className={cn(inputClass, "pl-9")}
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[920px] text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-left dark:border-navy-700">
              {columns.map((col) => (
                <th
                  key={col.key}
                  className={cn(
                    "whitespace-nowrap px-3 py-2 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400",
                    col.numeric ? "text-right" : "text-left"
                  )}
                >
                  <button
                    type="button"
                    onClick={() => toggleSort(col.key)}
                    className={cn(
                      "inline-flex items-center gap-1 transition hover:text-electric-500",
                      col.numeric && "flex-row-reverse"
                    )}
                  >
                    {col.label}
                    <span
                      className={cn(
                        "text-[10px]",
                        sort.key === col.key ? "text-electric-500" : "text-slate-300 dark:text-slate-600"
                      )}
                    >
                      {sort.key === col.key ? (sort.dir === "asc" ? "▲" : "▼") : "▵"}
                    </span>
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageRows.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length}
                  className="px-3 py-10 text-center text-sm text-slate-500 dark:text-slate-400"
                >
                  {t("analytics.empty")}
                </td>
              </tr>
            ) : (
              pageRows.map((row, i) => (
                <tr
                  key={row.id}
                  className={cn(
                    "border-b border-slate-100 transition hover:bg-electric-500/5 dark:border-navy-800/60",
                    i % 2 === 1 && "bg-slate-50/60 dark:bg-navy-900/40"
                  )}
                >
                  {columns.map((col) => (
                    <td
                      key={col.key}
                      className={cn(
                        "whitespace-nowrap px-3 py-2.5",
                        col.numeric ? "text-right font-medium" : "",
                        col.key === "name" && "font-medium text-slate-700 dark:text-slate-200"
                      )}
                    >
                      {col.format(row)}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-4 flex flex-col items-center justify-between gap-3 sm:flex-row">
        <p className="text-xs text-slate-500 dark:text-slate-400">
          {t("analytics.showing", { count: sorted.length })}
        </p>
        <div className="flex items-center gap-1">
          <button
            type="button"
            disabled={currentPage <= 1}
            onClick={() => setPage(currentPage - 1)}
            aria-label="Previous page"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-300 text-slate-600 transition hover:border-electric-400 hover:text-electric-500 disabled:cursor-not-allowed disabled:opacity-40 dark:border-navy-700 dark:text-slate-300"
          >
            <Icon name="chevL" className="h-4 w-4" />
          </button>
          <span className="px-2 text-xs text-slate-500 dark:text-slate-400">
            {t("analytics.pageInfo", { page: currentPage, pages })}
          </span>
          <button
            type="button"
            disabled={currentPage >= pages}
            onClick={() => setPage(currentPage + 1)}
            aria-label="Next page"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-300 text-slate-600 transition hover:border-electric-400 hover:text-electric-500 disabled:cursor-not-allowed disabled:opacity-40 dark:border-navy-700 dark:text-slate-300"
          >
            <Icon name="chevR" className="h-4 w-4" />
          </button>
        </div>
      </div>
    </Card>
  );
}
