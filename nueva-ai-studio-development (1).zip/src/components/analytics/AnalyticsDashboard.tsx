import { useMemo, useState } from "react";
import { useI18n } from "../../i18n";
import { getCampaigns, getDailyMetrics, type Campaign } from "../../data/sampleData";
import type { Category, Channel, Region } from "../../types";
import { formatCompact, formatCurrency, formatDateLabel, formatPercent } from "../../utils/format";
import { Card, Field, SegmentedControl, Select } from "../ui";
import { Icon } from "../Icon";
import { KpiCard } from "./KpiCard";
import { LineChart, type LinePoint } from "./LineChart";
import { BarChart, type BarItem } from "./BarChart";
import { DonutChart, type DonutItem } from "./DonutChart";
import { DataTable } from "./DataTable";

const DONUT_COLORS = ["#38bdf8", "#818cf8", "#34d399", "#fbbf24", "#f472b6", "#94a3b8"];

type SegmentRow = { region: Region; channel: Channel; category: Category };

function matchesSegments(
  row: SegmentRow,
  region: Region | "all",
  channel: Channel | "all",
  category: Category | "all"
): boolean {
  return (
    (region === "all" || row.region === region) &&
    (channel === "all" || row.channel === channel) &&
    (category === "all" || row.category === category)
  );
}

interface Totals {
  impressions: number;
  clicks: number;
  conversions: number;
  revenue: number;
  spend: number;
}

function sum(rows: { impressions: number; clicks: number; conversions: number; revenue: number; spend: number }[]): Totals {
  return rows.reduce<Totals>(
    (acc, r) => ({
      impressions: acc.impressions + r.impressions,
      clicks: acc.clicks + r.clicks,
      conversions: acc.conversions + r.conversions,
      revenue: acc.revenue + r.revenue,
      spend: acc.spend + r.spend,
    }),
    { impressions: 0, clicks: 0, conversions: 0, revenue: 0, spend: 0 }
  );
}

function shiftDays(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().slice(0, 10);
}

export function AnalyticsDashboard() {
  const { t, locale } = useI18n();
  const [range, setRange] = useState(30);
  const [region, setRegion] = useState<Region | "all">("all");
  const [channel, setChannel] = useState<Channel | "all">("all");
  const [category, setCategory] = useState<Category | "all">("all");

  const daily = useMemo(() => getDailyMetrics(), []);
  const campaigns = useMemo(() => getCampaigns(), []);

  const cutoff = useMemo(() => shiftDays(range), [range]);
  const prevCutoff = useMemo(() => shiftDays(range * 2), [range]);

  const curRows = useMemo(
    () =>
      daily.filter(
        (d) => d.date >= cutoff && matchesSegments(d, region, channel, category)
      ),
    [daily, cutoff, region, channel, category]
  );
  const prevRows = useMemo(
    () =>
      daily.filter(
        (d) =>
          d.date >= prevCutoff && d.date < cutoff && matchesSegments(d, region, channel, category)
      ),
    [daily, cutoff, prevCutoff, region, channel, category]
  );

  const cur = sum(curRows);
  const prev = sum(prevRows);
  const delta = (v: number, p: number) => (p === 0 ? (v > 0 ? 100 : 0) : ((v - p) / p) * 100);
  const ctr = cur.impressions > 0 ? cur.clicks / cur.impressions : 0;
  const prevCtr = prev.impressions > 0 ? prev.clicks / prev.impressions : 0;
  const roas = cur.spend > 0 ? cur.revenue / cur.spend : 0;
  const prevRoas = prev.spend > 0 ? prev.revenue / prev.spend : 0;

  const lineData = useMemo<LinePoint[]>(() => {
    const map = new Map<string, { revenue: number; spend: number }>();
    for (const r of curRows) {
      const e = map.get(r.date) ?? { revenue: 0, spend: 0 };
      e.revenue += r.revenue;
      e.spend += r.spend;
      map.set(r.date, e);
    }
    return [...map.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([date, v]) => ({
        label: formatDateLabel(date, locale),
        revenue: v.revenue,
        spend: v.spend,
      }));
  }, [curRows, locale]);

  const barData = useMemo<BarItem[]>(() => {
    const map = new Map<Channel, number>();
    for (const r of curRows) map.set(r.channel, (map.get(r.channel) ?? 0) + r.revenue);
    return [...map.entries()]
      .map(([ch, value]) => ({ label: t(`analytics.channels.${ch}`), value }))
      .sort((a, b) => b.value - a.value);
  }, [curRows, t]);

  const donutData = useMemo<DonutItem[]>(() => {
    const map = new Map<Category, number>();
    for (const r of curRows) map.set(r.category, (map.get(r.category) ?? 0) + r.revenue);
    return [...map.entries()]
      .map(([cat, value], i) => ({
        label: t(`analytics.categories.${cat}`),
        value,
        color: DONUT_COLORS[i % DONUT_COLORS.length],
      }))
      .sort((a, b) => b.value - a.value);
  }, [curRows, t]);

  const tableRows = useMemo<Campaign[]>(
    () =>
      campaigns.filter(
        (c) => c.startDate >= cutoff && matchesSegments(c, region, channel, category)
      ),
    [campaigns, cutoff, region, channel, category]
  );

  const regionOptions = (Object.keys({
    all: 1,
    west: 1,
    east: 1,
    north: 1,
    south: 1,
  }) as (Region | "all")[]).map((k) => ({ value: k, label: t(`analytics.regions.${k}`) }));
  const channelOptions = (["all", "tiktok", "facebook", "whatsapp", "instagram"] as const).map(
    (k) => ({ value: k, label: t(`analytics.channels.${k}`) })
  );
  const categoryOptions = (
    ["all", "clothing", "electronics", "beauty", "food", "services", "other"] as const
  ).map((k) => ({ value: k, label: t(`analytics.categories.${k}`) }));

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{t("analytics.title")}</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{t("analytics.subtitle")}</p>
      </div>

      {/* Live filters */}
      <Card className="p-4">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          <Field label={t("analytics.dateRange")}>
            <SegmentedControl
              ariaLabel={t("analytics.dateRange")}
              options={[
                { value: "7", label: t("analytics.last7") },
                { value: "30", label: t("analytics.last30") },
                { value: "90", label: t("analytics.last90") },
              ]}
              value={String(range)}
              onChange={(v) => setRange(Number(v))}
            />
          </Field>
          <Select
            label={t("analytics.region")}
            value={region}
            onChange={(v) => setRegion(v as Region | "all")}
            options={regionOptions}
          />
          <Select
            label={t("analytics.channel")}
            value={channel}
            onChange={(v) => setChannel(v as Channel | "all")}
            options={channelOptions}
          />
          <Select
            label={t("analytics.category")}
            value={category}
            onChange={(v) => setCategory(v as Category | "all")}
            options={categoryOptions}
          />
        </div>
      </Card>

      {/* KPI cards */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <KpiCard
          title={t("analytics.kpi.revenue")}
          value={formatCurrency(cur.revenue, locale)}
          delta={delta(cur.revenue, prev.revenue)}
          icon="trendUp"
          hint={t("analytics.kpi.vsPrevious")}
          index={0}
        />
        <KpiCard
          title={t("analytics.kpi.impressions")}
          value={formatCompact(cur.impressions, locale)}
          delta={delta(cur.impressions, prev.impressions)}
          icon="eye"
          hint={t("analytics.kpi.vsPrevious")}
          index={1}
        />
        <KpiCard
          title={t("analytics.kpi.clicks")}
          value={formatCompact(cur.clicks, locale)}
          delta={delta(cur.clicks, prev.clicks)}
          icon="cursor"
          hint={t("analytics.kpi.vsPrevious")}
          index={2}
        />
        <KpiCard
          title={t("analytics.kpi.conversions")}
          value={formatCompact(cur.conversions, locale)}
          delta={delta(cur.conversions, prev.conversions)}
          icon="cart"
          hint={t("analytics.kpi.vsPrevious")}
          index={3}
        />
        <KpiCard
          title={t("analytics.kpi.ctr")}
          value={formatPercent(ctr, locale)}
          delta={delta(ctr, prevCtr)}
          icon="target"
          hint={t("analytics.kpi.vsPrevious")}
          index={4}
        />
        <KpiCard
          title={t("analytics.kpi.roas")}
          value={`${roas.toFixed(2)}×`}
          delta={delta(roas, prevRoas)}
          icon="chart"
          hint={t("analytics.kpi.vsPrevious")}
          index={5}
        />
      </div>

      {/* Charts */}
      <div className="grid gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <div className="mb-4">
            <h2 className="font-semibold">{t("analytics.charts.revenueTrend")}</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {t("analytics.charts.revenueTrendSub")}
            </p>
          </div>
          <LineChart
            data={lineData}
            locale={locale}
            labels={{
              revenue: t("analytics.kpi.revenue"),
              spend: t("analytics.columns.spend"),
            }}
          />
        </Card>
        <Card>
          <div className="mb-4">
            <h2 className="font-semibold">{t("analytics.charts.byCategory")}</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {t("analytics.charts.byCategorySub")}
            </p>
          </div>
          <DonutChart data={donutData} locale={locale} centerLabel={t("analytics.kpi.revenue")} />
        </Card>
      </div>

      <Card>
        <div className="mb-4 flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-electric-500/10 text-electric-500">
            <Icon name="chart" className="h-4 w-4" />
          </span>
          <div>
            <h2 className="font-semibold">{t("analytics.charts.byChannel")}</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {t("analytics.charts.byChannelSub")}
            </p>
          </div>
        </div>
        <BarChart data={barData} locale={locale} />
      </Card>

      {/* Table */}
      <DataTable rows={tableRows} locale={locale} />
    </div>
  );
}
