import { useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, ChevronsUpDown, Download, Search } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import type { Row, StatusId } from '../../types';
import type { TKey } from '../../i18n/translations';
import { TYPE_COLORS, marketById } from '../../lib/markets';
import { PRODUCT_NAMES } from '../../lib/analytics/data';
import { downloadFile, fmtCompact, fmtCurrency, fmtDay, fmtInt, fmtPercent } from '../../lib/format';
import { cn } from '../../utils/cn';

type SortKey = 'title' | 'type' | 'platform' | 'market' | 'day' | 'impressions' | 'clicks' | 'ctr' | 'conversions' | 'revenue' | 'status';

interface ViewRow {
  r: Row;
  title: string;
  type: string;
  platform: string;
  market: string;
  ctr: number;
}

interface Col {
  key: SortKey;
  label: TKey;
  cls: string;
  numeric?: boolean;
}

const COLS: Col[] = [
  { key: 'title', label: 'col.title', cls: '' },
  { key: 'type', label: 'col.type', cls: 'hidden md:table-cell' },
  { key: 'platform', label: 'col.platform', cls: 'hidden md:table-cell' },
  { key: 'market', label: 'col.market', cls: 'hidden xl:table-cell' },
  { key: 'day', label: 'col.date', cls: 'hidden sm:table-cell' },
  { key: 'impressions', label: 'col.impressions', cls: '', numeric: true },
  { key: 'clicks', label: 'col.clicks', cls: 'hidden xl:table-cell', numeric: true },
  { key: 'ctr', label: 'col.ctr', cls: 'hidden md:table-cell', numeric: true },
  { key: 'conversions', label: 'col.conversions', cls: 'hidden lg:table-cell', numeric: true },
  { key: 'revenue', label: 'col.revenue', cls: '', numeric: true },
  { key: 'status', label: 'col.status', cls: 'hidden sm:table-cell' },
];

const STATUS_STYLE: Record<StatusId, string> = {
  live: 'bg-emerald-500/12 text-emerald-500',
  completed: 'bg-brand/12 text-brand',
  paused: 'bg-amber-500/14 text-amber-500',
};

const PAGE_SIZE = 8;

export function DataTable({ rows }: { rows: Row[] }) {
  const { t, lang } = useApp();
  const [sortKey, setSortKey] = useState<SortKey>('day');
  const [dir, setDir] = useState<'asc' | 'desc'>('desc');
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState<'all' | StatusId>('all');
  const [page, setPage] = useState(1);

  const view = useMemo<ViewRow[]>(() => {
    const q = query.trim().toLowerCase();
    const mapped = rows.map((r) => {
      const product = PRODUCT_NAMES[r.product][lang];
      const platform = t(`p.${r.platform}` as TKey);
      const typeLabel = t(`type.${r.type}Short` as TKey);
      const title = r.type === 'social' ? `${platform} · ${product}` : `${typeLabel} · ${product}`;
      return { r, title, type: typeLabel, platform, market: marketById(r.market)?.name[lang] ?? r.market, ctr: r.impressions ? r.clicks / r.impressions : 0 };
    });
    const filtered = mapped.filter((v) => {
      if (status !== 'all' && v.r.status !== status) return false;
      if (!q) return true;
      return `${v.title} ${v.r.id} ${v.type} ${v.platform} ${v.market}`.toLowerCase().includes(q);
    });
    const sign = dir === 'asc' ? 1 : -1;
    const val = (v: ViewRow): string | number => {
      switch (sortKey) {
        case 'title':
          return v.title;
        case 'type':
          return v.type;
        case 'platform':
          return v.platform;
        case 'market':
          return v.market;
        case 'ctr':
          return v.ctr;
        case 'status':
          return v.r.status;
        default:
          return v.r[sortKey];
      }
    };
    return filtered.sort((a, b) => {
      const x = val(a);
      const y = val(b);
      const c = typeof x === 'number' && typeof y === 'number' ? x - y : String(x).localeCompare(String(y), lang);
      return c * sign || b.r.day - a.r.day;
    });
  }, [rows, query, status, sortKey, dir, lang, t]);

  const pageCount = Math.max(1, Math.ceil(view.length / PAGE_SIZE));
  const current = Math.min(page, pageCount);
  const slice = view.slice((current - 1) * PAGE_SIZE, current * PAGE_SIZE);
  const from = view.length ? (current - 1) * PAGE_SIZE + 1 : 0;
  const to = Math.min(view.length, current * PAGE_SIZE);

  const toggleSort = (k: SortKey) => {
    if (k === sortKey) setDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else {
      setSortKey(k);
      setDir(k === 'title' || k === 'type' || k === 'platform' || k === 'market' || k === 'status' ? 'asc' : 'desc');
    }
    setPage(1);
  };

  const exportCsv = () => {
    const head = ['ID', t('col.title'), t('col.type'), t('col.platform'), t('col.market'), t('col.date'), t('col.impressions'), t('col.clicks'), t('col.ctr'), t('col.conversions'), t('col.revenue'), t('col.status')];
    const esc = (s: string | number) => `"${String(s).replace(/"/g, '""')}"`;
    const lines = view.map((v) =>
      [v.r.id, v.title, v.type, v.platform, v.market, new Date(v.r.day * 86400000).toISOString().slice(0, 10), v.r.impressions, v.r.clicks, (v.ctr * 100).toFixed(2) + '%', v.r.conversions, v.r.revenue, t(`st.${v.r.status}` as TKey)]
        .map(esc)
        .join(','),
    );
    downloadFile('nueva-content-performance.csv', '\ufeff' + [head.map(esc).join(','), ...lines].join('\n'), 'text/csv;charset=utf-8');
  };

  const sortCol = COLS.find((c) => c.key === sortKey);

  return (
    <section className="card overflow-hidden">
      <div className="flex flex-col gap-3 border-b border-line p-4 sm:p-5">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <h3 className="font-display text-base font-bold text-ink">{t('tbl.title')}</h3>
            <p className="mt-0.5 text-xs text-muted">{t('tbl.subtitle')}</p>
          </div>
          <button type="button" className="btn btn-ghost btn-sm" onClick={exportCsv} disabled={!view.length}>
            <Download size={14} /> {t('tbl.exportCsv')}
          </button>
        </div>
        <div className="grid gap-2 sm:grid-cols-[1fr_auto_auto]">
          <div className="relative">
            <Search size={15} className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-muted" />
            <input
              className="input !pl-9"
              type="search"
              value={query}
              placeholder={t('tbl.search')}
              aria-label={t('tbl.search')}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(1);
              }}
            />
          </div>
          <select
            className="input sm:w-44"
            value={status}
            aria-label={t('col.status')}
            onChange={(e) => {
              setStatus(e.target.value as 'all' | StatusId);
              setPage(1);
            }}
          >
            <option value="all">{t('tbl.allStatus')}</option>
            {(['live', 'completed', 'paused'] as StatusId[]).map((s) => (
              <option key={s} value={s}>
                {t(`st.${s}` as TKey)}
              </option>
            ))}
          </select>
          {/* mobile sort control (headers are hidden on small screens) */}
          <div className="flex gap-2 md:hidden">
            <select className="input min-w-0 flex-1" value={sortKey} aria-label={t('tbl.sortedBy', { col: sortCol ? t(sortCol.label) : '' })} onChange={(e) => { setSortKey(e.target.value as SortKey); setPage(1); }}>
              {COLS.map((c) => (
                <option key={c.key} value={c.key}>
                  {t(c.label)}
                </option>
              ))}
            </select>
            <button type="button" className="btn btn-ghost !px-3" onClick={() => setDir((d) => (d === 'asc' ? 'desc' : 'asc'))} aria-label="Toggle sort direction">
              {dir === 'asc' ? <ArrowUp size={16} /> : <ArrowDown size={16} />}
            </button>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[320px] border-collapse text-left text-sm">
          <thead>
            <tr className="border-b border-line bg-surface2/60 text-[11px] tracking-wide text-muted uppercase">
              {COLS.map((c) => {
                const activeCol = c.key === sortKey;
                return (
                  <th
                    key={c.key}
                    scope="col"
                    aria-sort={activeCol ? (dir === 'asc' ? 'ascending' : 'descending') : 'none'}
                    className={cn('px-4 py-2.5 font-semibold whitespace-nowrap', c.numeric && 'text-right', c.cls)}
                  >
                    <button
                      type="button"
                      onClick={() => toggleSort(c.key)}
                      className={cn('inline-flex cursor-pointer items-center gap-1 uppercase transition hover:text-ink', activeCol && 'text-brand', c.numeric && 'flex-row-reverse')}
                    >
                      {t(c.label)}
                      {activeCol ? dir === 'asc' ? <ArrowUp size={12} /> : <ArrowDown size={12} /> : <ChevronsUpDown size={12} className="opacity-50" />}
                    </button>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {slice.map((v, i) => (
              <tr key={v.r.id} className="animate-fade-up border-b border-line/70 transition hover:bg-brand/5" style={{ animationDelay: `${i * 25}ms` }}>
                <td className="max-w-[210px] px-4 py-3">
                  <div className="flex items-center gap-2.5">
                    <span className="h-8 w-1 shrink-0 rounded-full" style={{ background: TYPE_COLORS[v.r.type] }} />
                    <div className="min-w-0">
                      <div className="truncate font-semibold text-ink">{v.title}</div>
                      <div className="truncate text-[11px] text-muted">
                        <span className="md:hidden">{v.platform} · </span>
                        {v.r.id}
                        <span className="xl:hidden"> · {marketById(v.r.market)?.code}</span>
                        <span className={cn('ml-1.5 rounded-full px-1.5 py-0.5 font-bold sm:hidden', STATUS_STYLE[v.r.status])}>{t(`st.${v.r.status}` as TKey)}</span>
                      </div>
                    </div>
                  </div>
                </td>
                <td className="hidden px-4 py-3 text-muted md:table-cell">{v.type}</td>
                <td className="hidden px-4 py-3 text-muted md:table-cell">{v.platform}</td>
                <td className="hidden px-4 py-3 text-muted xl:table-cell">{v.market}</td>
                <td className="hidden px-4 py-3 whitespace-nowrap text-muted sm:table-cell">{fmtDay(v.r.day, lang, true)}</td>
                <td className="px-4 py-3 text-right font-semibold text-ink tabular-nums">{fmtCompact(v.r.impressions, lang)}</td>
                <td className="hidden px-4 py-3 text-right text-muted tabular-nums xl:table-cell">{fmtInt(v.r.clicks, lang)}</td>
                <td className="hidden px-4 py-3 text-right text-muted tabular-nums md:table-cell">{fmtPercent(v.ctr, lang)}</td>
                <td className="hidden px-4 py-3 text-right text-muted tabular-nums lg:table-cell">{fmtInt(v.r.conversions, lang)}</td>
                <td className="px-4 py-3 text-right font-semibold text-ink tabular-nums">{fmtCurrency(v.r.revenue, lang, false)}</td>
                <td className="hidden px-4 py-3 sm:table-cell">
                  <span className={cn('inline-flex rounded-full px-2.5 py-1 text-[11px] font-bold', STATUS_STYLE[v.r.status])}>{t(`st.${v.r.status}` as TKey)}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {slice.length === 0 && <div className="px-4 py-12 text-center text-sm text-muted">{t('tbl.empty')}</div>}
      </div>

      <div className="flex flex-col items-center justify-between gap-3 p-4 text-xs text-muted sm:flex-row">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <span className="font-medium">{t('tbl.showing', { from, to, total: view.length })}</span>
          {sortCol && <span className="hidden sm:inline">· {t('tbl.sortedBy', { col: t(sortCol.label) })}</span>}
        </div>
        <div className="flex items-center gap-2">
          <button type="button" className="btn btn-ghost btn-sm" disabled={current <= 1} onClick={() => setPage(current - 1)}>
            <ChevronLeft size={14} /> <span className="hidden sm:inline">{t('tbl.prev')}</span>
          </button>
          <span className="min-w-[88px] text-center font-semibold text-ink tabular-nums">{t('tbl.page', { p: current, n: pageCount })}</span>
          <button type="button" className="btn btn-ghost btn-sm" disabled={current >= pageCount} onClick={() => setPage(current + 1)}>
            <span className="hidden sm:inline">{t('tbl.next')}</span> <ChevronRight size={14} />
          </button>
        </div>
      </div>
    </section>
  );
}
