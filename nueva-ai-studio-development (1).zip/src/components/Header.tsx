import { useEffect, useState } from "react";
import { useI18n } from "../i18n";
import { cn } from "../utils/cn";
import { Badge, SegmentedControl } from "./ui";
import { Icon } from "./Icon";

export type Tab = "studio" | "analytics" | "history";

const THEME_KEY = "nueva_theme";

export function useTheme() {
  const [theme, setTheme] = useState<"dark" | "light">(() =>
    typeof localStorage !== "undefined" && localStorage.getItem(THEME_KEY) === "light"
      ? "light"
      : "dark"
  );
  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    localStorage.setItem(THEME_KEY, theme);
  }, [theme]);
  return { theme, setTheme };
}

function buildTabs(t: (k: string) => string) {
  return [
    { key: "studio" as Tab, label: t("nav.studio"), icon: "sparkles" },
    { key: "analytics" as Tab, label: t("nav.analytics"), icon: "chart" },
    { key: "history" as Tab, label: t("nav.history"), icon: "clock" },
  ];
}

function HistoryCountBadge({ count }: { count: number }) {
  if (count <= 0) return null;
  return (
    <span className="flex h-4 min-w-4 items-center justify-center rounded-full bg-electric-500 px-1 text-[10px] font-bold text-white">
      {count > 99 ? "99+" : count}
    </span>
  );
}

export function Header({
  tab,
  onTabChange,
  historyCount,
  theme,
  onThemeToggle,
}: {
  tab: Tab;
  onTabChange: (tab: Tab) => void;
  historyCount: number;
  theme: "dark" | "light";
  onThemeToggle: () => void;
}) {
  const { t, lang, setLang } = useI18n();
  const tabs = buildTabs(t);

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-white/70 backdrop-blur-xl dark:border-navy-700/60 dark:bg-navy-950/70">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 md:gap-4 md:px-6">
        <button
          type="button"
          onClick={() => onTabChange("studio")}
          className="flex items-center gap-2.5"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-electric-400 to-blue-600 shadow-lg shadow-electric-500/30">
            <Icon name="zap" className="h-5 w-5 text-white" />
          </span>
          <span className="leading-tight">
            <span className="block text-sm font-extrabold tracking-tight sm:text-base">
              NUEVA <span className="text-electric-500">AI STUDIO</span>
            </span>
            <span className="hidden text-[10px] font-medium uppercase tracking-widest text-slate-400 sm:block">
              {t("app.company")}
            </span>
          </span>
        </button>

        <nav className="ml-2 hidden items-center gap-1 md:flex">
          {tabs.map((tb) => (
            <button
              key={tb.key}
              type="button"
              onClick={() => onTabChange(tb.key)}
              className={cn(
                "relative flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-semibold transition",
                tab === tb.key
                  ? "bg-electric-500/10 text-electric-600 dark:text-electric-300"
                  : "text-slate-500 hover:bg-slate-100 hover:text-slate-700 dark:text-slate-400 dark:hover:bg-navy-800"
              )}
            >
              <Icon name={tb.icon} className="h-4 w-4" />
              {tb.label}
              {tb.key === "history" && <HistoryCountBadge count={historyCount} />}
            </button>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <span className="hidden lg:inline-flex">
            <Badge tone="electric">
              <Icon name="info" className="h-3 w-3" />
              {t("header.demoBadge")}
            </Badge>
          </span>
          <SegmentedControl
            ariaLabel={t("header.language")}
            options={[
              { value: "fr", label: "FR" },
              { value: "en", label: "EN" },
            ]}
            value={lang}
            onChange={(v) => setLang(v as "fr" | "en")}
          />
          <button
            type="button"
            onClick={onThemeToggle}
            aria-label={t("header.switchTheme")}
            title={t("header.switchTheme")}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-300 text-slate-600 transition hover:border-electric-400 hover:text-electric-500 dark:border-navy-700 dark:text-slate-300"
          >
            <Icon name={theme === "dark" ? "sun" : "moon"} className="h-5 w-5" />
          </button>
        </div>
      </div>
    </header>
  );
}

export function MobileNav({
  tab,
  onTabChange,
  historyCount,
}: {
  tab: Tab;
  onTabChange: (tab: Tab) => void;
  historyCount: number;
}) {
  const { t } = useI18n();
  const tabs = buildTabs(t);
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-200/70 bg-white/85 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl dark:border-navy-700/60 dark:bg-navy-950/85 md:hidden">
      <div className="mx-auto flex max-w-7xl items-stretch justify-around px-4">
        {tabs.map((tb) => (
          <button
            key={tb.key}
            type="button"
            onClick={() => onTabChange(tb.key)}
            className={cn(
              "relative flex flex-1 flex-col items-center gap-1 py-2.5 text-[11px] font-semibold",
              tab === tb.key ? "text-electric-500" : "text-slate-500 dark:text-slate-400"
            )}
          >
            <span className="relative">
              <Icon name={tb.icon} className="h-5 w-5" />
              {tb.key === "history" && (
                <span className="absolute -right-2 -top-1">
                  <HistoryCountBadge count={historyCount} />
                </span>
              )}
            </span>
            {tb.label}
          </button>
        ))}
      </div>
    </nav>
  );
}
