import type { Lang, Values, Variant } from '../../types';
import { buildCtx, colon, ctaLine, offerLine, pick, upper1 } from './helpers';

/** Advertising text generator (demo mode): three distinct creative angles. */
export function generateAds(v: Values, lang: Lang): Variant[] {
  const c = buildCtx(v, lang);
  const fr = c.fr;
  const cta = ctaLine(c);
  const offer = offerLine(c);
  const sep = colon(c);

  const L = fr
    ? {
        headline: 'Titre',
        body: 'Texte publicitaire',
        cta: 'Appel à l’action',
        short: 'Version courte (statut WhatsApp / SMS)',
      }
    : { headline: 'Headline', body: 'Ad text', cta: 'Call to action', short: 'Short version (WhatsApp status / SMS)' };

  const shortOf = (i: number) =>
    [`${c.e(i)} ${c.name} — ${c.descShort}.`, c.offer ? `${c.offer}.` : '', cta].filter(Boolean).join(' ');

  /* ---- Angle 1: benefit-led ---- */
  const goalSentence = fr
    ? {
        sales: 'Une qualité en laquelle vous pouvez avoir confiance, livrée avec soin.',
        awareness: `Soyez parmi les premiers ${c.where} à le découvrir.`,
        leads: 'Dites-nous ce qu’il vous faut, nous vous proposons la solution adaptée.',
      }[c.goal]
    : {
        sales: 'Quality you can trust, delivered with care.',
        awareness: `Be among the first ${c.where} to discover it.`,
        leads: 'Tell us what you need and we will tailor the right solution.',
      }[c.goal];

  const v1Headline = fr
    ? pick([`${c.opener} ${c.name}.`, `${c.name}${sep} conçu pour ${c.audience}.`, `${c.name}${sep} la qualité qui se voit, le prix qui plaît.`])
    : pick([`${c.opener} ${c.name}.`, `${c.name}${sep} made for ${c.audience}.`, `${c.name}${sep} quality you can feel, value you will love.`]);

  const v1Body = [
    `${c.e(0)} ${c.name}${sep} ${c.desc}.`,
    fr
      ? `Pensé pour ${c.audience} ${c.where}, il allie qualité, style et prix juste.`
      : `Designed for ${c.audience} ${c.where}, it brings together quality, style and honest value.`,
    goalSentence,
    offer,
  ]
    .filter(Boolean)
    .join(' ');

  /* ---- Angle 2: problem → solution ---- */
  const v2Headline = fr
    ? pick(['Marre de vous contenter du minimum ?', 'Vous cherchez encore la bonne solution ?', 'Pourquoi faire des compromis sur la qualité ?'])
    : pick(['Tired of settling for less?', 'Still searching for the right one?', 'Why compromise on quality?']);

  const v2Body = [
    fr ? `${c.e(1)} ${upper1(c.audience)} ${c.where} méritent mieux.` : `${c.e(1)} ${upper1(c.audience)} ${c.where} deserve better.`,
    fr ? `C’est pourquoi nous avons créé ${c.name}${sep} ${c.desc}.` : `That is why we created ${c.name}${sep} ${c.desc}.`,
    fr ? 'Simple, fiable et pensé pour votre quotidien.' : 'Simple, reliable and made to fit your daily life.',
    offer,
  ]
    .filter(Boolean)
    .join(' ');

  /* ---- Angle 3: offer & urgency ---- */
  const v3Headline = c.offer
    ? fr
      ? `${c.offer}${sep} uniquement avec ${c.name} !`
      : `${c.offer}${sep} only with ${c.name}!`
    : fr
      ? `N’attendez plus${sep} ${c.name} est là.`
      : `Do not wait${sep} ${c.name} is here.`;

  const v3Body = [
    `${c.e(2)} ${c.name}${sep} ${c.desc}.`,
    offer,
    fr ? 'Les produits populaires partent vite : assurez-vous le vôtre dès aujourd’hui.' : 'Popular products go fast, so secure yours today.',
  ]
    .filter(Boolean)
    .join(' ');

  const make = (title: string, headline: string, body: string, i: number): Variant => ({
    title,
    sections: [
      { label: L.headline, text: headline },
      { label: L.body, text: body },
      { label: L.cta, text: cta },
      { label: L.short, text: shortOf(i) },
    ],
  });

  return [
    make(fr ? 'Axé bénéfices' : 'Benefit-led', v1Headline, v1Body, 0),
    make(fr ? 'Problème → solution' : 'Problem → solution', v2Headline, v2Body, 1),
    make(fr ? 'Offre & urgence' : 'Offer & urgency', v3Headline, v3Body, 2),
  ];
}
